<?php
/**
 * seleccionperfil.php
 * ----------------
 * Permite seleccionar un perfil dentro de la familia ya autenticada.
 * - Requiere $_SESSION['id_familia'] (familia iniciada).
 * - Lista perfiles habilitados (si existe columna 'estado') y verifica contraseña del perfil seleccionado.
 * - Al completar la verificación guarda en sesión: $_SESSION['perfil_id'], $_SESSION['perfil_nombre'], $_SESSION['perfil_rol']
 */
$idInterfaz = 4; // UIseleccionarUnPerfil
session_start();
include("conexion.php");

// Verificar que haya sesión activa de usuario
if (!isset($_SESSION["id_familia"])) {
    header("Location: login.php");
    exit();
}

$idFamilia = $_SESSION["id_familia"];

// Obtener los perfiles de la familia logueada (tabla Perfil)
// Comprobar existencia de la columna 'estado' usando procedimiento almacenado
$estadoExists = false;
$check = $conexion->prepare("CALL sp_check_estado_column_in_Perfil()");
if ($check) {
    $check->execute();
    $resCheck = $check->get_result();
    if ($resCheck) {
        $r = $resCheck->fetch_assoc();
        if ($r && isset($r['c']) && (int)$r['c'] > 0) {
            $estadoExists = true;
        }
    }
    $check->close();
}

// Obtener perfiles vía procedimiento almacenado y filtrar por estado en PHP si es necesario
$perfiles = [];
$stmtPf = $conexion->prepare("CALL sp_get_perfiles_familia(?)");
if ($stmtPf) {
    $stmtPf->bind_param('i', $idFamilia);
    $stmtPf->execute();
    $resPf = $stmtPf->get_result();
    if ($resPf) {
        while ($row = $resPf->fetch_assoc()) {
            if ($estadoExists) {
                if (isset($row['estado']) && $row['estado'] === 'Habilitado') $perfiles[] = $row;
            } else {
                $perfiles[] = $row;
            }
        }
    }
    $stmtPf->close();
}

// Procesar selección de perfil (se envía desde el modal)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $perfil_id = isset($_POST["perfil_id"]) ? (int)$_POST["perfil_id"] : null;
    $password = $_POST["password"] ?? '';

    if ($perfil_id && $password !== '') {
        $stmt2 = $conexion->prepare("CALL sp_get_perfil_por_id(?)");
        if ($stmt2) {
            $stmt2->bind_param("i", $perfil_id);
            $stmt2->execute();
            $perfilRes = $stmt2->get_result();
            $perfil = $perfilRes ? $perfilRes->fetch_assoc() : null;
            $stmt2->close();
        } else {
            $perfil = null;
        }

        if ($perfil && password_verify($password, $perfil["contraseña_perfil"])) {
            // Guardar datos del perfil en sesión (usar mismas claves que el resto de la app)
            $_SESSION["perfil_id"] = $perfil["id_perfil"];
            $_SESSION["perfil_nombre"] = $perfil["nombre_perfil"];
            $_SESSION["perfil_rol"] = $perfil["rol"];
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(true, 'Perfil correcto.'); redirigirAInterfazDentroDeCuenta(5); });</script>";
        } else {
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Contraseña incorrecta.'); });</script>";
        }
    } else {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Complete la contraseña.'); });</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¿Quién eres? | FamCash</title>
    <link rel="stylesheet" href="css/perfiles.css">
</head>
<body>

    <h1>¿Quién eres?</h1>

    <div style="position: fixed; top: 20px; right: 20px;">
        <button onclick="location.href='logout.php'" style="background:#e74c3c;color:#fff;padding:10px 16px;border:none;border-radius:8px;font-weight:600;cursor:pointer;transition:0.3s;">Cerrar sesión de cuenta</button>
    </div>

    <div class="contenedor-perfiles">
        <?php foreach ($perfiles as $perfil): ?>
            <div class="perfil" onclick="seleccionarUnPerfil(<?php echo (int)$perfil['id_perfil']; ?>)">
                <img src="img/img.png" alt="<?php echo htmlspecialchars($perfil['nombre_perfil']); ?>">
                <p><?php echo htmlspecialchars($perfil['nombre_perfil']); ?></p>
                <?php
                // Mostrar el rol solamente para administradores (aceptamos 'Administrador' o 'Admin')
                $rolLower = isset($perfil['rol']) ? strtolower(trim($perfil['rol'])) : '';
                if ($rolLower === 'administrador' || $rolLower === 'admin') :
                ?>
                    <span class="rol">(<?php echo htmlspecialchars($perfil['rol']); ?>)</span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Modal para ingresar contraseña -->
    <div id="modal" class="modal" style="display:none; position:fixed; inset:0; align-items:center; justify-content:center; background: rgba(0,0,0,0.4);">
        <form method="POST" class="modal-contenido" style="background:#fff;padding:20px;border-radius:8px;min-width:300px;" onsubmit="return llenarContraseñaPerfil();">
            <h3>Ingrese su contraseña</h3>
            <input type="hidden" name="perfil_id" id="perfil_id">
            <input type="password" name="password" id="password" placeholder="Contraseña" required style="width:90%;padding:8px;margin:8px 0;">
            <div style="display:flex;gap:8px;justify-content:flex-end;">
                <button type="button" onclick="cerrarModal()">Cancelar</button>
                <button type="submit">Aceptar</button>
            </div>
        </form>
    </div>

<script src="js/seleccionperfil.js"></script>

</body>
</html>
