<?php
session_start();
include("conexion.php");

// Validar sesión activa
if (!isset($_SESSION["idUsuario"])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION["idUsuario"];

// Obtener perfiles del usuario logueado
$query = "SELECT * FROM perfiles WHERE idUsuario = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

$perfiles = [];
while ($row = $result->fetch_assoc()) {
    $perfiles[] = $row;
}

// Validar contraseña del perfil seleccionado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $perfil_id = $_POST["perfil_id"];
    $password = $_POST["password"];

    $stmt = $conexion->prepare("SELECT * FROM perfiles WHERE idPerfil = ?");
    $stmt->bind_param("i", $perfil_id);
    $stmt->execute();
    $perfil = $stmt->get_result()->fetch_assoc();

    if ($perfil && password_verify($password, $perfil["contrasenaEncriptada"])) {
        $_SESSION["perfil_id"] = $perfil["idPerfil"];
        $_SESSION["perfil_nombre"] = $perfil["nombrePerfil"];
        $_SESSION["perfil_rol"] = $perfil["rol"];
        header("Location: entrada_diaria.php");
        exit;
    } else {
        $error = "Contraseña incorrecta.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¿Quién eres? | FamCash</title>
    <link rel="stylesheet" href="css/perfiles.css">
</head>
<body>

    <h1>¿Quién eres?</h1>

    <div class="contenedor-perfiles">
        <?php foreach ($perfiles as $perfil): ?>
            <div class="perfil" onclick="mostrarModal('<?php echo $perfil['idPerfil']; ?>')">
                <img src="img/img.png" alt="<?php echo htmlspecialchars($perfil['nombrePerfil']); ?>">
                <p><?php echo htmlspecialchars($perfil['nombrePerfil']); ?></p>
                <span class="rol">(<?php echo htmlspecialchars($perfil['rol']); ?>)</span>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Modal de contraseña -->
    <div id="modal" class="modal">
        <form method="POST" class="modal-contenido">
            <h3>Ingrese su contraseña</h3>
            <input type="hidden" name="perfil_id" id="perfil_id">
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Aceptar</button>
            <button type="button" onclick="cerrarModal()">Cancelar</button>
        </form>
    </div>

    <?php if (isset($error)): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>

    <script>
        const modal = document.getElementById("modal");
        const perfilInput = document.getElementById("perfil_id");

        function mostrarModal(id) {
            perfilInput.value = id;
            modal.style.display = "flex";
        }

        function cerrarModal() {
            modal.style.display = "none";
        }
    </script>

</body>
</html>
