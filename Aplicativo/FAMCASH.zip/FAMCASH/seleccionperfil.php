<?php
$idInterfaz = 4; // UIseleccionarUnPerfil
session_start();
include("conexion.php");

// Verificar que haya sesión activa de usuario
if (!isset($_SESSION["idUsuario"])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION["idUsuario"];

// Obtener los perfiles del usuario logueado
$query = "SELECT * FROM perfiles WHERE idUsuario = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();
$perfiles = [];
while ($row = $result->fetch_assoc()) {
    $perfiles[] = $row;
}

// Procesar selección de perfil (se envía desde el modal)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $perfil_id = isset($_POST["perfil_id"]) ? (int)$_POST["perfil_id"] : null;
    $password = $_POST["password"] ?? '';

    if ($perfil_id && $password !== '') {
        $stmt2 = $conexion->prepare("SELECT * FROM perfiles WHERE idPerfil = ? LIMIT 1");
        $stmt2->bind_param("i", $perfil_id);
        $stmt2->execute();
        $perfil = $stmt2->get_result()->fetch_assoc();

        if ($perfil && password_verify($password, $perfil["contrasenaEncriptada"])) {
            $_SESSION["perfil_id"] = $perfil["idPerfil"];
            $_SESSION["perfil_nombre"] = $perfil["nombrePerfil"];
            $_SESSION["perfil_rol"] = $perfil["rol"];
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(true, 'Perfil correcto.'); redirigirAInterfazDentroDeCuenta(5); });</script>";
        } else {
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Contraseña incorrecta.'); });</script>";
        }
    } else {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Complete la contraseña.'); });</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¿Quién eres? | FamCash</title>
    <link rel="stylesheet" href="css/perfiles.css">
</head>
<body>

    <h1>¿Quién eres?</h1>

    <div class="contenedor-perfiles">
        <?php foreach ($perfiles as $perfil): ?>
            <div class="perfil" onclick="seleccionarUnPerfil(<?php echo (int)$perfil['idPerfil']; ?>)">
                <img src="img/img.png" alt="<?php echo htmlspecialchars($perfil['nombrePerfil']); ?>">
                <p><?php echo htmlspecialchars($perfil['nombrePerfil']); ?></p>
                <span class="rol">(<?php echo htmlspecialchars($perfil['rol']); ?>)</span>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Modal para ingresar contraseña -->
    <div id="modal" class="modal" style="display:none; position:fixed; inset:0; align-items:center; justify-content:center; background: rgba(0,0,0,0.4);">
        <form method="POST" class="modal-contenido" style="background:#fff;padding:20px;border-radius:8px;min-width:300px;" onsubmit="return llenarContraseñaPerfil();">
            <h3>Ingrese su contraseña</h3>
            <input type="hidden" name="perfil_id" id="perfil_id">
            <input type="password" name="password" id="password" placeholder="Contraseña" required style="width:90%;padding:8px;margin:8px 0;">
            <div style="display:flex;gap:8px;justify-content:flex-end;">
                <button type="button" onclick="cerrarModal()">Cancelar</button>
                <button type="submit">Aceptar</button>
            </div>
        </form>
    </div>

<script>
/* ===========================================
   Métodos definidos en el Diccionario (UI-04)
   =========================================== */

/**
 * seleccionarPerfil(idPerfil)
 * - almacena el id y muestra la ventana de contraseña
 */
function seleccionarUnPerfil(idPerfil) {
    // Guardar el id en el input hidden del modal
    document.getElementById('perfil_id').value = idPerfil;
    // Delegar la apertura a la función del diccionario
    mostrarVentanaContraseña();
}

/**
 * mostrarVentanaContraseña()
 * - según el diccionario: muestra la ventana/campo para ingresar la contraseña del perfil
 */
function mostrarVentanaContraseña() {
    const modal = document.getElementById('modal');
    // limpiar input de contraseña por seguridad
    const passInput = document.getElementById('password');
    passInput.value = '';
    // mostrar modal (estilo inline para compatibilidad con tu CSS)
    modal.style.display = 'flex';
    // focus directo en el campo contraseña
    passInput.focus();
}

/**
 * llenarContraseñaPerfil()
 * - valida que el campo no esté vacío antes de enviar al backend
 */
function llenarContraseñaPerfil() {
    const pass = document.getElementById('password').value.trim();
    if (pass === '') {
        mostrarMensaje(false, 'Ingrese la contraseña del perfil.');
        return false;
    }
    return true; // permite el envío del formulario
}

/**
 * redirigirAInterfazDentroDeCuenta(idInterfaz)
 * - redirige a entrada_diaria.php si la verificación fue correcta
 */
function redirigirAInterfazDentroDeCuenta(idInterfaz) {
    if (idInterfaz === 5) { // UIEntradaDiaria
        setTimeout(function() {
            window.location.href = 'entrada_diaria.php';
        }, 900);
    } else {
        mostrarMensaje(false, 'Interfaz de destino no válida.');
    }
}

/**
 * mostrarMensaje(comprobante, mensaje)
 * - muestra mensajes (puedes sustituir por modal más bonito)
 */
function mostrarMensaje(comprobante, mensaje) {
    alert((comprobante ? '✅ ' : '⚠️ ') + mensaje);
}

/* Función auxiliar para cerrar modal (útil y no conflictiva) */
function cerrarModal() {
    document.getElementById('modal').style.display = 'none';
}
</script>

</body>
</html>
