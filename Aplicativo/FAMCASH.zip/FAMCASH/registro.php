<?php
/**
 * registro.php - VERSIÓN CON Perfil_Concepto CORREGIDA
 */
$idInterfaz = 2;
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre_registro = trim($_POST["nombre_registro"] ?? '');
    $contrasena_registro = $_POST["contrasena_registro"] ?? '';
    $repetir_contrasena_registro = $_POST["repetir_contrasena_registro"] ?? '';
    $nombre_perfil = trim($_POST["nombre_perfil"] ?? '');
    $contrasena_perfil = $_POST["contrasena_perfil"] ?? '';
    $repetir_contrasena_perfil = $_POST["repetir_contrasena_perfil"] ?? '';

    // Validaciones (igual que antes)
    // Verificar aceptación de términos
    $accepted = isset($_POST['accept_terms']) && ($_POST['accept_terms'] === 'on' || $_POST['accept_terms'] === '1');
    if (!$accepted) {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Debe aceptar los Términos y condiciones para registrarse.'); });</script>";
    } elseif ($nombre_registro === '' || $contrasena_registro === '' || $repetir_contrasena_registro === '' ||
        $nombre_perfil === '' || $contrasena_perfil === '' || $repetir_contrasena_perfil === '') {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Complete todos los campos.'); });</script>";
    } 
    elseif (strlen($contrasena_registro) < 6 || strlen($contrasena_perfil) < 6) {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Las contraseñas deben tener al menos 6 caracteres.'); });</script>";
    }
    elseif (!preg_match('/[0-9]/', $contrasena_registro) || !preg_match('/[0-9]/', $contrasena_perfil)) {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Las contraseñas deben contener al menos un número.'); });</script>";
    }
    elseif ($contrasena_registro !== $repetir_contrasena_registro || $contrasena_perfil !== $repetir_contrasena_perfil) {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Las contraseñas no coinciden.'); });</script>";
    } else {
        // Encriptar contraseñas
        $hashUsuario = password_hash($contrasena_registro, PASSWORD_DEFAULT);
        $hashPerfil = password_hash($contrasena_perfil, PASSWORD_DEFAULT);

        // Verificar si la familia ya existe
        $verificar = $conexion->prepare("SELECT id_familia FROM Familia WHERE nombre_familia = ? LIMIT 1");
        $verificar->bind_param("s", $nombre_registro);
        $verificar->execute();
        $resultado = $verificar->get_result();

        if ($resultado && $resultado->num_rows > 0) {
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'La familia ya existe.'); });</script>";
        } else {
            // Insertar en tabla Familia
            $stmt = $conexion->prepare("INSERT INTO Familia (nombre_familia, contraseña_familia) VALUES (?, ?)");
            $stmt->bind_param("ss", $nombre_registro, $hashUsuario);

            if ($stmt->execute()) {
                $id_familia = $stmt->insert_id;

                // CORRECCIÓN: Verificar que el nombre del perfil no exista en esta familia
                $verificar->close();
                
                $verificarPerfil = $conexion->prepare("SELECT id_perfil FROM Perfil WHERE id_familia_Familia = ? AND nombre_perfil = ? LIMIT 1");
                if (!$verificarPerfil) {
                    echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error en la consulta: " . $conexion->error . "'); });</script>";
                    exit;
                }
                
                $verificarPerfil->bind_param("is", $id_familia, $nombre_perfil);
                $verificarPerfil->execute();
                $resultadoPerfil = $verificarPerfil->get_result();

                if ($resultadoPerfil && $resultadoPerfil->num_rows > 0) {
                    echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'El nombre de perfil \\'$nombre_perfil\\' ya existe en esta familia.'); });</script>";
                    $verificarPerfil->close();
                } else {
                    $verificarPerfil->close();
                    
                    // Insertar en tabla Perfil
                    $stmt2 = $conexion->prepare("INSERT INTO Perfil (id_perfil, id_familia_Familia, nombre_perfil, contraseña_perfil, rol, estado) VALUES (NULL, ?, ?, ?, ?, 'Habilitado')");
                    if (!$stmt2) {
                        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error al preparar inserción de perfil: " . $conexion->error . "'); });</script>";
                        exit;
                    }
                    
                    $rol = "Admin";
                    $stmt2->bind_param("isss", $id_familia, $nombre_perfil, $hashPerfil, $rol);

                    if ($stmt2->execute()) {
                        $id_perfil = $stmt2->insert_id;

                        // NUEVA LÓGICA CORREGIDA: Insertar conceptos y relacionarlos con el perfil
                        $defaultConcepts = [
                            ['Sueldo', 'Ingreso'],
                            ['Venta', 'Ingreso'],
                            ['Otros ingresos', 'Ingreso'],
                            ['Alimentos', 'Egreso'],
                            ['Transporte', 'Egreso'],
                            ['Vivienda', 'Egreso'],
                            ['Servicios', 'Egreso'],
                            ['Salud', 'Egreso']
                        ];

                        // Preparar statements
                        $stmtInsertConcept = $conexion->prepare("INSERT IGNORE INTO Concepto (nombre_concepto, tipo) VALUES (?, ?)");
                        $stmtGetConceptId = $conexion->prepare("SELECT id_concepto FROM Concepto WHERE nombre_concepto = ? AND tipo = ? LIMIT 1");
                        
                        // CORRECCIÓN: Ahora incluye id_familia_Familia en Perfil_Concepto
                        $stmtInsertPerfilConcepto = $conexion->prepare("INSERT INTO Perfil_Concepto (id_perfil_Perfil, id_familia_Familia, id_concepto_Concepto, alias_concepto, activo) VALUES (?, ?, ?, ?, 1)");
                        
                        foreach ($defaultConcepts as $dc) {
                            $nombreConcept = $dc[0];
                            $tipoConcept = $dc[1];
                            
                            // 1. Insertar concepto (si no existe)
                            $stmtInsertConcept->bind_param('ss', $nombreConcept, $tipoConcept);
                            $stmtInsertConcept->execute();
                            
                            // 2. Obtener el ID del concepto
                            $stmtGetConceptId->bind_param('ss', $nombreConcept, $tipoConcept);
                            $stmtGetConceptId->execute();
                            $resultConcept = $stmtGetConceptId->get_result();
                            
                            if ($resultConcept && $row = $resultConcept->fetch_assoc()) {
                                $id_concepto = $row['id_concepto'];
                                
                                // 3. Insertar en Perfil_Concepto con id_familia_Familia y alias igual al nombre original
                                $stmtInsertPerfilConcepto->bind_param('iiis', $id_perfil, $id_familia, $id_concepto, $nombreConcept);
                                if (!$stmtInsertPerfilConcepto->execute()) {
                                    // Si hay error, solo registrar pero no detener el proceso
                                    error_log("Error insertando en Perfil_Concepto: " . $stmtInsertPerfilConcepto->error);
                                }
                            }
                        }
                        
                        // Liberar statements
                        $stmtInsertConcept->close();
                        $stmtGetConceptId->close();
                        $stmtInsertPerfilConcepto->close();

                        // Todo ok
                        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(true, 'Registro exitoso. Redirigiendo...'); redirigirAInterfazDentroDeCuenta(3, {$id_familia}); });</script>";
                    } else {
                        // Manejar error de duplicado específico
                        if ($conexion->errno == 1062) {
                            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'El nombre de perfil \\'$nombre_perfil\\' ya existe en esta familia.'); });</script>";
                        } else {
                            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error al crear el perfil: " . $conexion->error . "'); });</script>";
                        }
                    }
                    $stmt2->close();
                }
            } else {
                echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error al crear la familia.'); });</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - FamCash</title>
    <link rel="stylesheet" href="css/registro.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" class="logo-link">
                <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
                <h1>SOLVE-IT</h1>
            </a>
        </div>
    </header>
    
    <main>
        <form action="registro.php" method="post" onsubmit="return llenarRegistroPerfil();">
            <div class="contenedor">
                <section class="columna izquierda">
                    <h2>Registra tu cuenta</h2>
                    <input type="text" name="nombre_registro" placeholder="Nombre de cuenta" required>
                    <input type="password" name="contrasena_registro" placeholder="Contraseña (mín. 6 caracteres, incluir número)" required>
                    <input type="password" name="repetir_contrasena_registro" placeholder="Repita contraseña" required>
                    <img src="img/fam_happy.png" alt="Icono Familia" class="icono">
                </section>

                <section class="columna derecha">
                    <h2>Crea tu perfil</h2>
                    <input type="text" name="nombre_perfil" placeholder="Nombre de perfil" required>
                    <input type="password" name="contrasena_perfil" placeholder="Contraseña (mín. 6 caracteres, incluir número)" required>
                    <input type="password" name="repetir_contrasena_perfil" placeholder="Repita contraseña" required>
                    <img src="img/money.png" alt="Icono Perfil" class="icono">
                </section>
            </div>

            <div class="terminos" style="text-align: center;">
                <label style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:16px">
                    <input type="checkbox" name="accept_terms" id="accept_terms">
                    <span>Acepto los <a href="#" onclick="event.preventDefault(); alert('Al aceptar, usted reconoce que los miembros de la familia podrán ver los gastos registrados en esta cuenta.');">Términos y condiciones</a> </span>
                </label>
            </div>

            <div class="boton-registrar">
                <button type="submit">Registrar</button>
            </div>
        </form>
    </main>

    <footer>
        <p>© 2025 FamCash. Todos los derechos reservados.</p>
    </footer>

<script src="js/registro.js"></script>
</body>
</html>