<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre_registro = $_POST["nombre_registro"];
    $contrasena_registro = $_POST["contrasena_registro"];
    $repetir_contrasena_registro = $_POST["repetir_contrasena_registro"];
    $nombre_perfil = $_POST["nombre_perfil"];
    $contrasena_perfil = $_POST["contrasena_perfil"];
    $repetir_contrasena_perfil = $_POST["repetir_contrasena_perfil"];

    // Validar contraseñas
    if ($contrasena_registro !== $repetir_contrasena_registro || 
        $contrasena_perfil !== $repetir_contrasena_perfil) {
        echo "<script>alert('Las contraseñas no coinciden');</script>";
    } else {
        // Encriptar contraseñas
        $hashUsuario = password_hash($contrasena_registro, PASSWORD_DEFAULT);
        $hashPerfil = password_hash($contrasena_perfil, PASSWORD_DEFAULT);

        // Verificar si el usuario ya existe
        $verificar = $conexion->prepare("SELECT * FROM usuarios WHERE nombreUsuario = ?");
        $verificar->bind_param("s", $nombre_registro);
        $verificar->execute();
        $resultado = $verificar->get_result();

        if ($resultado->num_rows > 0) {
            echo "<script>alert('El usuario ya existe');</script>";
        } else {
            // Insertar en tabla usuarios
            $stmt = $conexion->prepare("INSERT INTO usuarios (nombreUsuario, contrasenaEncriptada, nombre) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nombre_registro, $hashUsuario, $nombre_registro);
            $stmt->execute();

            // Obtener ID del usuario recién creado
            $idUsuario = $stmt->insert_id;

            // Insertar en tabla perfiles
            $stmt2 = $conexion->prepare("INSERT INTO perfiles (idUsuario, nombrePerfil, contrasenaEncriptada, rol) VALUES (?, ?, ?, ?)");
            // El perfil creado en el registro inicial será Administrador
            $rol = "Administrador";
            $stmt2->bind_param("isss", $idUsuario, $nombre_perfil, $hashPerfil, $rol);
            $stmt2->execute();

            echo "<script>alert('Registro exitoso'); window.location='login.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - FamCash</title>
    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" class="logo-link">
                <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
                <h1>SOLVE-IT</h1>
            </a>
        </div>
    </header>

    <main>
        <form action="registro.php" method="post">
            <div class="contenedor">
                <section class="columna izquierda">
                    <h2>Registra tu cuenta</h2>
                    <input type="text" name="nombre_registro" placeholder="Nombre de cuenta" required>
                    <input type="password" name="contrasena_registro" placeholder="Contraseña" required>
                    <input type="password" name="repetir_contrasena_registro" placeholder="Repita contraseña" required>
                    <img src="img/fam_happy.png" alt="Icono Familia" class="icono">
                </section>

                <section class="columna derecha">
                    <h2>Crea tu perfil</h2>
                    <input type="text" name="nombre_perfil" placeholder="Nombre de perfil" required>
                    <input type="password" name="contrasena_perfil" placeholder="Contraseña" required>
                    <input type="password" name="repetir_contrasena_perfil" placeholder="Repita contraseña" required>
                    <img src="img/money.png" alt="Icono Perfil" class="icono">
                </section>
            </div>

            <div class="boton-registrar">
                <button type="submit">Registrar</button>
            </div>
        </form>
    </main>

    <footer>
        <p>© 2025 FamCash. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
