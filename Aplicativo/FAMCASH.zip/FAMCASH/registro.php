<?php
$idInterfaz = 2; // UIRegistro
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre_registro = trim($_POST["nombre_registro"] ?? '');
    $contrasena_registro = $_POST["contrasena_registro"] ?? '';
    $repetir_contrasena_registro = $_POST["repetir_contrasena_registro"] ?? '';
    $nombre_perfil = trim($_POST["nombre_perfil"] ?? '');
    $contrasena_perfil = $_POST["contrasena_perfil"] ?? '';
    $repetir_contrasena_perfil = $_POST["repetir_contrasena_perfil"] ?? '';

    // Validar campos vacíos
    if ($nombre_registro === '' || $contrasena_registro === '' || $repetir_contrasena_registro === '' ||
        $nombre_perfil === '' || $contrasena_perfil === '' || $repetir_contrasena_perfil === '') {
        // Enviar señal a JS para mostrar mensaje al cargar la página
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Complete todos los campos.'); });</script>";
    } elseif ($contrasena_registro !== $repetir_contrasena_registro || $contrasena_perfil !== $repetir_contrasena_perfil) {
        echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Las contraseñas no coinciden.'); });</script>";
    } else {
        // Encriptar contraseñas
        $hashUsuario = password_hash($contrasena_registro, PASSWORD_DEFAULT);
        $hashPerfil = password_hash($contrasena_perfil, PASSWORD_DEFAULT);

        // Verificar si el usuario ya existe (por nombreUsuario)
        $verificar = $conexion->prepare("SELECT idUsuario FROM usuarios WHERE nombreUsuario = ? LIMIT 1");
        $verificar->bind_param("s", $nombre_registro);
        $verificar->execute();
        $resultado = $verificar->get_result();

        if ($resultado && $resultado->num_rows > 0) {
            echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'El usuario ya existe.'); });</script>";
        } else {
            // Insertar en tabla usuarios
            $stmt = $conexion->prepare("INSERT INTO usuarios (nombreUsuario, contrasenaEncriptada, nombre) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nombre_registro, $hashUsuario, $nombre_registro);

            if ($stmt->execute()) {
                $idUsuario = $stmt->insert_id;

                // Insertar en tabla perfiles (primer perfil Administrador)
                $stmt2 = $conexion->prepare("INSERT INTO perfiles (idUsuario, nombrePerfil, contrasenaEncriptada, rol) VALUES (?, ?, ?, ?)");
                $rol = "Administrador";
                $stmt2->bind_param("isss", $idUsuario, $nombre_perfil, $hashPerfil, $rol);

                if ($stmt2->execute()) {
                    // Todo ok: mostrar mensaje y redirigir (se hará en onload dentro de la página)
                    echo "<script>window.addEventListener('load', function(){ mostrarMensaje(true, 'Registro exitoso. Redirigiendo...'); redirigirAInterfazDentroDeCuenta(3, {$idUsuario}); });</script>";
                } else {
                    echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error al crear el perfil.'); });</script>";
                }
            } else {
                echo "<script>window.addEventListener('load', function(){ mostrarMensaje(false, 'Error al crear el usuario.'); });</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - FamCash</title>
    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" class="logo-link">
                <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
                <h1>SOLVE-IT</h1>
            </a>
        </div>
    </header>

    <main>
        <!-- Mantengo exactamente tu estructura y nombres de inputs para que el style funcione -->
        <form action="registro.php" method="post" onsubmit="return llenarRegistroPerfil();">
            <div class="contenedor">
                <section class="columna izquierda">
                    <h2>Registra tu cuenta</h2>
                    <input type="text" name="nombre_registro" placeholder="Nombre de cuenta" required>
                    <input type="password" name="contrasena_registro" placeholder="Contraseña" required>
                    <input type="password" name="repetir_contrasena_registro" placeholder="Repita contraseña" required>
                    <img src="img/fam_happy.png" alt="Icono Familia" class="icono">
                </section>

                <section class="columna derecha">
                    <h2>Crea tu perfil</h2>
                    <input type="text" name="nombre_perfil" placeholder="Nombre de perfil" required>
                    <input type="password" name="contrasena_perfil" placeholder="Contraseña" required>
                    <input type="password" name="repetir_contrasena_perfil" placeholder="Repita contraseña" required>
                    <img src="img/money.png" alt="Icono Perfil" class="icono">
                </section>
            </div>

            <div class="boton-registrar">
                <button type="submit">Registrar</button>
            </div>
        </form>
    </main>

    <footer>
        <p>© 2025 FamCash. Todos los derechos reservados.</p>
    </footer>

<script>
/* ================================
   Funciones del Diccionario (UI-02)
   ================================ */

function llenarRegistroPerfil() {
    const nombre = document.querySelector('[name="nombre_registro"]').value.trim();
    const contrasena = document.querySelector('[name="contrasena_registro"]').value;
    const repetir = document.querySelector('[name="repetir_contrasena_registro"]').value;
    const nombrePerfil = document.querySelector('[name="nombre_perfil"]').value.trim();
    const contrasenaPerfil = document.querySelector('[name="contrasena_perfil"]').value;
    const repetirPerfil = document.querySelector('[name="repetir_contrasena_perfil"]').value;

    if (!nombre || !contrasena || !repetir || !nombrePerfil || !contrasenaPerfil || !repetirPerfil) {
        mostrarMensaje(false, "Por favor, complete todos los campos.");
        return false;
    }
    if (contrasena !== repetir || contrasenaPerfil !== repetirPerfil) {
        mostrarMensaje(false, "Las contraseñas no coinciden.");
        return false;
    }
    return true; // permite enviar el formulario
}

function redirigirAInterfazDentroDeCuenta(idInterfaz, idPerfil) {
    // idInterfaz 3 = UIIniciarSesión (según diccionario)
    if (idInterfaz === 3) {
        // dejamos pequeña pausa para que el usuario vea el mensaje de éxito
        setTimeout(function() {
            window.location.href = "login.php";
        }, 900);
    } else {
        // fallback: redirigir a página principal si id desconocido
        setTimeout(function() {
            window.location.href = "index.php";
        }, 900);
    }
}

function mostrarMensaje(comprobante, mensaje) {
    // Puedes reemplazar por un modal bonito si lo prefieres
    // comprobante = true => exito, false => error
    if (typeof Swal !== 'undefined') {
        // si tienes SweetAlert cargado en tu proyecto, úsalo
        Swal.fire({
            icon: comprobante ? 'success' : 'error',
            title: comprobante ? 'Éxito' : 'Atención',
            text: mensaje
        });
    } else {
        alert((comprobante ? "✅ " : "⚠️ ") + mensaje);
    }
}
</script>
</body>
</html>
