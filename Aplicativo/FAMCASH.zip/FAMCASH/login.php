<?php
/**
 * login.php
 * ----------------
 * Lógica y vista para iniciar sesión en una cuenta (familia).
 * - POST: recibe nombre de familia y contraseña, valida y crea las variables de sesión:
 *   $_SESSION['id_familia'], $_SESSION['nombre_familia']
 * - Almacena $idInterfaz = 3 para el diccionario de interfaces.
 */
$idInterfaz = 3; // UIIniciarSesión
session_start();
include("conexion.php");

$mensaje = "";
$exito = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = trim($_POST["nombre"] ?? '');
    $contrasena = $_POST["contrasena"] ?? '';

    if ($nombre === '' || $contrasena === '') {
        $mensaje = "Complete todos los campos.";
    } else {
        $stmt = $conexion->prepare("SELECT id_familia, contraseña_familia FROM Familia WHERE nombre_familia = ?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();

            if (password_verify($contrasena, $usuario["contraseña_familia"])) {
                $_SESSION["id_familia"] = $usuario["id_familia"];
                $_SESSION["nombre_familia"] = $nombre;
                $mensaje = "Inicio de sesión exitoso.";
                $exito = true;
            } else {
                $mensaje = "Contraseña incorrecta.";
            }
        } else {
            $mensaje = "Usuario no encontrado.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - FamCash</title>
    <link rel="stylesheet" href="css/style3.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php" class="logo-link">
                <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
                <h1>SOLVE-IT</h1>
            </a>
        </div>
    </header>

    <main>
        <div class="contenedor">
            <!-- Columna izquierda -->
            <section class="columna izquierda">
                <h1 class="titulo">FamCash</h1>
                <h3 class="subtitulo">El arte de ahorrar</h3>
                <p class="descripcion">
                    <strong>Tu dinero más claro:</strong> Registra ingresos, controla gastos 
                    y alcanza metas de ahorro junto a tu familia.
                </p>
                <img src="img/fam_happy.png" alt="Icono Familia" class="icono">
            </section>

            <!-- Columna derecha -->
            <section class="columna derecha">
                <h2>Iniciar Sesión</h2>
                <form action="login.php" method="post" onsubmit="return iniciarSesion();">
                    <input type="text" name="nombre" placeholder="Nombre de cuenta" required>
                    <input type="password" name="contrasena" placeholder="Contraseña" required>
                    <button type="submit">Ingresar</button>
                </form>
                <p class="registro-texto">
                    ¿Eres un usuario nuevo? 
                    <a href="#" onclick="ingresarARegistro(2)">Regístrate</a>
                </p>
            </section>
        </div>
    </main>

    <footer>
        <p>© 2025 FamCash. Todos los derechos reservados.</p>
    </footer>

<script>
/* ===============================
   Métodos definidos en el Diccionario (UI-03)
   =============================== */

// 1️⃣ iniciarSesion()
function iniciarSesion() {
    const nombre = document.querySelector('[name="nombre"]').value.trim();
    const contrasena = document.querySelector('[name="contrasena"]').value.trim();

    if (!nombre || !contrasena) {
        mostrarMensaje(false, "Por favor, complete todos los campos.");
        return false;
    }
    return true;
}

// 2️⃣ redirigirAInterfazDentroDeCuenta(idInterfaz)
function redirigirAInterfazDentroDeCuenta(idInterfaz) {
    if (idInterfaz === 4) {
        window.location.href = "seleccionperfil.php";
    } else {
        mostrarMensaje(false, "No se pudo determinar la interfaz destino.");
    }
}

// 3️⃣ ingresarARegistro(idInterfazRegistro)
function ingresarARegistro(idInterfazRegistro) {
    if (idInterfazRegistro === 2) {
        window.location.href = "registro.php";
    } else {
        mostrarMensaje(false, "No se pudo redirigir a la interfaz de registro.");
    }
}

// 4️⃣ mostrarMensaje(comprobante, mensaje)
function mostrarMensaje(comprobante, mensaje) {
    alert((comprobante ? "✅ " : "⚠️ ") + mensaje);
}
</script>

<?php if ($mensaje !== ""): ?>
<script>
// Espera un poco para que las funciones JS estén disponibles
setTimeout(() => {
    mostrarMensaje(<?= $exito ? 'true' : 'false' ?>, "<?= $mensaje ?>");
    <?php if ($exito): ?>
    redirigirAInterfazDentroDeCuenta(4);
    <?php endif; ?>
}, 200);
</script>
<?php endif; ?>
</body>
</html>
