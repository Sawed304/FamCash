<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['perfil_id'])) {
    echo "no_session";
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$fecha = $_POST['fecha'] ?? date('Y-m-d');
$montos = (isset($_POST['monto']) && is_array($_POST['monto'])) ? $_POST['monto'] : [];

try {
    $conexion->begin_transaction();

    // Preparar consultas
    $checkStmt = $conexion->prepare("SELECT idTransaccion FROM transacciones WHERE idPerfil = ? AND idConcepto = ? AND fecha = ?");
    $updateStmt = $conexion->prepare("UPDATE transacciones SET monto = ?, hora = NOW() WHERE idTransaccion = ?");
    $insertStmt = $conexion->prepare("INSERT INTO transacciones (idPerfil, idConcepto, monto, fecha, hora) VALUES (?, ?, ?, ?, NOW())");
    $deleteStmt = $conexion->prepare("DELETE FROM transacciones WHERE idTransaccion = ?");

    // Control interno para evitar duplicados
    $conceptosProcesados = [];

    foreach ($montos as $idConcepto => $valorRaw) {
        $clave = strtolower(trim(is_string($idConcepto) ? $idConcepto : "id_$idConcepto"));
        if (isset($conceptosProcesados[$clave])) continue;
        $conceptosProcesados[$clave] = true;

        $monto = floatval(str_replace(',', '.', $valorRaw));

        // 🔹 Caso 1: Nuevo concepto (por ejemplo "new_1")
        if (is_string($idConcepto) && strpos($idConcepto, 'new_') === 0) {
            $nombre = trim($_POST['new_nombre'][$idConcepto] ?? '');
            $tipo = trim($_POST['new_tipo'][$idConcepto] ?? '');

            if ($nombre === '' || $tipo === '') continue;

            // Verificar si ya existe concepto con el mismo nombre y tipo
            $checkConcept = $conexion->prepare("
                SELECT idConcepto FROM conceptos 
                WHERE idPerfil = ? AND LOWER(nombre) = LOWER(?) AND tipo = ? AND estado = 'Habilitado'
            ");
            $checkConcept->bind_param('iss', $idPerfil, $nombre, $tipo);
            $checkConcept->execute();
            $resConcept = $checkConcept->get_result();
            if ($resConcept->num_rows > 0) {
                $newConceptId = $resConcept->fetch_assoc()['idConcepto'];
            } else {
                // Insertar nuevo concepto si no existe
                $insertConcept = $conexion->prepare("INSERT INTO conceptos (idPerfil, nombre, tipo, estado) VALUES (?, ?, ?, 'Habilitado')");
                $insertConcept->bind_param('iss', $idPerfil, $nombre, $tipo);
                $insertConcept->execute();
                $newConceptId = $conexion->insert_id;
            }

            // Insertar transacción si monto != 0
            if ($monto != 0) {
                $insertStmt->bind_param("iids", $idPerfil, $newConceptId, $monto, $fecha);
                $insertStmt->execute();
            }
            continue;
        }

        // 🔹 Caso 2: Concepto existente
        $idNum = (int)$idConcepto;
        $checkStmt->bind_param("iis", $idPerfil, $idNum, $fecha);
        $checkStmt->execute();
        $res = $checkStmt->get_result();

        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $idTrans = $row['idTransaccion'];

            if ($monto == 0) {
                // Eliminar transacción
                $deleteStmt->bind_param("i", $idTrans);
                $deleteStmt->execute();
            } else {
                // Actualizar monto existente
                $updateStmt->bind_param("di", $monto, $idTrans);
                $updateStmt->execute();
            }
        } elseif ($monto != 0) {
            // Nueva transacción para concepto existente
            $insertStmt->bind_param("iids", $idPerfil, $idNum, $monto, $fecha);
            $insertStmt->execute();
        }
    }

    $conexion->commit();
    echo "ok";
} catch (Exception $e) {
    $conexion->rollback();
    echo "error: " . $e->getMessage();
}
?>
