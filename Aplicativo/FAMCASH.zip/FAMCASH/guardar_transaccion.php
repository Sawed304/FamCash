
<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['perfil_id'])) {
    echo "no_session";
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$fecha = isset($_POST['fecha']) ? $_POST['fecha'] : date('Y-m-d');

// asegurarse de tener un array de montos
$montos = isset($_POST['monto']) && is_array($_POST['monto']) ? $_POST['monto'] : [];

try {
    $conexion->begin_transaction();

    // preparar consultas
    $checkStmt = $conexion->prepare("SELECT idTransaccion FROM transacciones WHERE idPerfil = ? AND idConcepto = ? AND fecha = ?");
    $updateStmt = $conexion->prepare("UPDATE transacciones SET monto = ?, hora = NOW() WHERE idTransaccion = ?");
    $insertStmt = $conexion->prepare("INSERT INTO transacciones (idPerfil, idConcepto, monto, fecha, hora) VALUES (?, ?, ?, ?, NOW())");
    $deleteStmt = $conexion->prepare("DELETE FROM transacciones WHERE idTransaccion = ?");

    foreach ($montos as $idConcepto => $valorRaw) {
        // normalizar número (por si viene con coma)
        $monto = floatval(str_replace(',', '.', $valorRaw));

        // Si el concepto es nuevo (key empieza con 'new_'), crear concepto primero
        if (is_string($idConcepto) && strpos($idConcepto, 'new_') === 0) {
            // se espera que el nombre y tipo se envíen como new_nombre[new_x] y new_tipo[new_x]
            $nombreKey = "new_nombre[" . $idConcepto . "]";
            $tipoKey = "new_tipo[" . $idConcepto . "]";

            $nombre = isset($_POST['new_nombre']) && is_array($_POST['new_nombre']) && isset($_POST['new_nombre'][$idConcepto]) ? $_POST['new_nombre'][$idConcepto] : null;
            $tipo = isset($_POST['new_type']) ? null : null; // placeholder, we'll try alternative retrieval below

            // mejor intento de recuperar nombre y tipo desde $_POST raw
            // PHP convierte keys de FormData como new_nombre[new_1] -> $_POST['new_nombre']['new_1']
            $nombre = isset($_POST['new_nombre']) && is_array($_POST['new_nombre']) && isset($_POST['new_nombre'][$idConcepto]) ? $_POST['new_nombre'][$idConcepto] : null;
            $tipo = isset($_POST['new_tipo']) && is_array($_POST['new_tipo']) && isset($_POST['new_tipo'][$idConcepto]) ? $_POST['new_tipo'][$idConcepto] : null;

            if ($nombre === null || $tipo === null) {
                // si faltan datos, ignorar
                continue;
            }

            // insertar nuevo concepto y obtener id
            $insertConceptStmt = $conexion->prepare("INSERT INTO conceptos (idPerfil, nombre, tipo, estado) VALUES (?, ?, ?, 'Habilitado')");
            $insertConceptStmt->bind_param('iss', $idPerfil, $nombre, $tipo);
            $insertConceptStmt->execute();
            $newConceptId = $conexion->insert_id;

            // si monto != 0 insertar transacción
            if ($monto != 0) {
                $insertStmt->bind_param("iids", $idPerfil, $newConceptId, $monto, $fecha);
                $insertStmt->execute();
            }

            continue;
        }

        // idConcepto es numérico (concepto existente)
        $idNum = (int)$idConcepto;

        // comprobar si existe transacción para ese concepto en esa fecha
        $checkStmt->bind_param("iis", $idPerfil, $idNum, $fecha);
        $checkStmt->execute();
        $res = $checkStmt->get_result();

        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $idTrans = $row['idTransaccion'];

            if ($monto == 0) {
                // si quieres borrar transacciones con monto 0:
                $deleteStmt->bind_param("i", $idTrans);
                $deleteStmt->execute();
            } else {
                $updateStmt->bind_param("di", $monto, $idTrans);
                $updateStmt->execute();
            }
        } else {
            if ($monto != 0) {
                $insertStmt->bind_param("iids", $idPerfil, $idNum, $monto, $fecha); // i i d s
                $insertStmt->execute();
            }
        }
    }

    $conexion->commit();
    echo "ok";
} catch (Exception $e) {
    $conexion->rollback();
    echo "error: " . $e->getMessage();
}
?>


