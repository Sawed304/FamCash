<?php
/**
 * guardar_transaccion.php
 * -----------------------
 * Endpoint que maneja:
 * - Inserción de nuevas transacciones (recibe arrays: concepto_id[], tipo[], detalle[], monto[], fecha)
 * - Eliminación por id via POST { delete_id }
 * - Endpoint summary via GET?action=summary&fecha=YYYY-MM-DD que devuelve JSON con month_sum, month_display, year_sum
 * Comportamiento importante:
 * - Inserta siempre nuevas filas (no actualiza por concepto/fecha) para evitar sobreescrituras indeseadas.
 * - Usa un concepto por defecto 'Varios' si el id_concepto recibido no existe (evita errores FK).
 */
session_start();
include("conexion.php");

// Opcional: que mysqli lance excepciones en errores para que el try/catch las capture
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$sessionKey = isset($_SESSION['perfil_id']) ? 'perfil_id' : (isset($_SESSION['id_perfil']) ? 'id_perfil' : null);
if (!$sessionKey) {
    echo "no_session";
    exit;
}

$idPerfil = $_SESSION[$sessionKey];
$fecha = $_POST['fecha'] ?? date('Y-m-d');

// Compatibilidad: ahora la UI envía arrays posicionales:
// concepto_id[], tipo[], detalle[], monto[]
$conceptos = (isset($_POST['concepto_id']) && is_array($_POST['concepto_id'])) ? $_POST['concepto_id'] : [];
$tipos = (isset($_POST['tipo']) && is_array($_POST['tipo'])) ? $_POST['tipo'] : [];
$detalles = (isset($_POST['detalle']) && is_array($_POST['detalle'])) ? $_POST['detalle'] : [];
$montos = (isset($_POST['monto']) && is_array($_POST['monto'])) ? $_POST['monto'] : [];

try {
    // Manejo rápido de eliminación por id (petición AJAX desde la UI)
    if (isset($_POST['delete_id'])) {
        $delId = (int)$_POST['delete_id'];
        $delStmt = $conexion->prepare("DELETE FROM Transaccion WHERE id_transaccion = ? AND id_perfil_Perfil = ?");
        $delStmt->bind_param('ii', $delId, $idPerfil);
        if ($delStmt->execute()) {
            echo 'ok';
        } else {
            echo 'error';
        }
        exit;
    }

    // Endpoint para resumen (devuelve JSON con sums hasta una fecha dada)
    if (isset($_GET['action']) && $_GET['action'] === 'summary') {
        $fechaGet = $_GET['fecha'] ?? date('Y-m-d');
        $monthStart = date('Y-m-01', strtotime($fechaGet));
        $yearStart = date('Y-01-01', strtotime($fechaGet));

        // Detectar si la tabla Perfil tiene columna de familia para filtrar (usaremos la
        // familia de los perfiles que realizaron las transacciones)
        $perfilFamiliaCol = null;
        $stmtCol = $conexion->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('Perfil','perfil') AND (COLUMN_NAME = 'id_familia_Familia' OR COLUMN_NAME = 'id_familia') LIMIT 1");
        if ($stmtCol) {
            $stmtCol->execute();
            $resCol = $stmtCol->get_result();
            if ($resCol && $rc = $resCol->fetch_assoc()) {
                $perfilFamiliaCol = $rc['COLUMN_NAME'];
            }
        }

        $needFamilyFilter = ($perfilFamiliaCol !== null && isset($_SESSION['id_familia']));
        $idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;

        $sqlRange = "SELECT
            IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto) ELSE 0 END),0) AS ingresos,
            IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN ABS(t.monto) ELSE 0 END),0) AS egresos
        FROM Transaccion t
        JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto
        JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil";

        if ($needFamilyFilter) {
            $sqlRange .= "\nWHERE p." . $perfilFamiliaCol . " = ? AND DATE(t.fecha) BETWEEN ? AND ?";
        } else {
            $sqlRange .= "\nWHERE DATE(t.fecha) BETWEEN ? AND ?";
        }

        // Año
        $annualIncome = 0; $annualExpense = 0;
        $stmtRange = $conexion->prepare($sqlRange);
        if ($stmtRange) {
            if ($needFamilyFilter) {
                $stmtRange->bind_param('iss', $idFamilia, $yearStart, $fechaGet);
            } else {
                $stmtRange->bind_param('ss', $yearStart, $fechaGet);
            }
            $stmtRange->execute();
            $resRange = $stmtRange->get_result();
            if ($resRange) {
                $r = $resRange->fetch_assoc();
                $annualIncome = (float)$r['ingresos'];
                $annualExpense = (float)$r['egresos'];
            }
        }

        // Mes
        $monthlyIncome = 0; $monthlyExpense = 0;
        $stmtRange = $conexion->prepare($sqlRange);
        if ($stmtRange) {
            if ($needFamilyFilter) {
                $stmtRange->bind_param('iss', $idFamilia, $monthStart, $fechaGet);
            } else {
                $stmtRange->bind_param('ss', $monthStart, $fechaGet);
            }
            $stmtRange->execute();
            $resRange = $stmtRange->get_result();
            if ($resRange) {
                $r = $resRange->fetch_assoc();
                $monthlyIncome = (float)$r['ingresos'];
                $monthlyExpense = (float)$r['egresos'];
            }
        }

        $yearSum = $annualIncome - $annualExpense;
        $monthSum = $monthlyIncome - $monthlyExpense;
        $monthDisplay = max($monthSum, 0.0);

        header('Content-Type: application/json');
        echo json_encode([
            'month_sum' => $monthSum,
            'month_display' => $monthDisplay,
            'year_sum' => $yearSum
        ]);
        exit;
    }

    $conexion->begin_transaction();

    // Preparar consultas (nuevas tablas/columnas)
    // Nota: ahora insertaremos siempre nuevas transacciones para las filas enviadas
    // Insert para transacciones que referencian un Concepto (con detalle opcional)
    $insertDetalleStmt = $conexion->prepare("INSERT INTO Transaccion (id_perfil_Perfil, id_concepto_Concepto, fecha, monto, detalle) VALUES (?, ?, ?, ?, ?)");
    // Insert sin detalle (por compatibilidad)
    $insertStmt = $conexion->prepare("INSERT INTO Transaccion (id_perfil_Perfil, id_concepto_Concepto, fecha, monto) VALUES (?, ?, ?, ?)");
    // Comprobar transacción por detalle (cuando no hay Concepto) - usado solo si necesitas evitar duplicados por detalle
    $checkDetalleStmt = $conexion->prepare("SELECT id_transaccion FROM Transaccion WHERE id_perfil_Perfil = ? AND DATE(fecha) = ? AND LOWER(detalle) = LOWER(?) LIMIT 1");
    $deleteStmt = $conexion->prepare("DELETE FROM Transaccion WHERE id_transaccion = ?");

    // Obtener o crear concepto por defecto 'Varios' (para usar cuando no queremos crear Concepto nuevo)
    $defaultConceptId = null;
    $defaultName = 'Varios';
    $defaultTipo = 'Egreso';
    $stmtGetDefault = $conexion->prepare("SELECT id_concepto FROM Concepto WHERE LOWER(nombre_concepto) = LOWER(?) LIMIT 1");
    $stmtGetDefault->bind_param('s', $defaultName);
    $stmtGetDefault->execute();
    $resDefault = $stmtGetDefault->get_result();
    if ($resDefault && $resDefault->num_rows > 0) {
        $defaultConceptId = $resDefault->fetch_assoc()['id_concepto'];
    } else {
        $stmtCreateDefault = $conexion->prepare("INSERT INTO Concepto (nombre_concepto, tipo) VALUES (?, ?)");
        $stmtCreateDefault->bind_param('ss', $defaultName, $defaultTipo);
        $stmtCreateDefault->execute();
        $defaultConceptId = $conexion->insert_id;
    }

    // Procesar arrays posicionales enviados desde la UI
    $count = max(count($conceptos), count($montos));
    for ($i = 0; $i < $count; $i++) {
        $conceptoRaw = $conceptos[$i] ?? '';
        $tipoRaw = $tipos[$i] ?? '';
        $detalleRaw = $detalles[$i] ?? '';
        $valorRaw = $montos[$i] ?? '';

        if ($conceptoRaw === '' || $valorRaw === '') continue; // saltar filas incompletas

        // Normalizar monto
        $monto = floatval(str_replace(',', '.', $valorRaw));

        // Asegurar signo según tipo
        if (strtolower($tipoRaw) === 'ingreso') {
            $monto = abs($monto);
        } else {
            $monto = -abs($monto);
        }

        // Determinar id de concepto válido; si no existe, usar defaultConceptId para evitar FK error
        $idNum = intval($conceptoRaw);
        // Verificar existencia del concepto
        $stmtCheckConceptById = $conexion->prepare("SELECT id_concepto FROM Concepto WHERE id_concepto = ? LIMIT 1");
        $stmtCheckConceptById->bind_param('i', $idNum);
        $stmtCheckConceptById->execute();
        $resChkById = $stmtCheckConceptById->get_result();
        if (!($resChkById && $resChkById->num_rows > 0)) {
            // fallback al concepto por defecto para evitar violación de FK
            $idNum = $defaultConceptId;
        }
        $stmtCheckConceptById->close();

        // Siempre insertar una nueva transacción para la fila enviada (no reemplazamos montos de transacciones existentes con mismo concepto)
        $fechaTime = strpos($fecha, ' ') === false ? $fecha . ' 00:00:00' : $fecha;
        if ($monto == 0) {
            // Si el usuario envía monto 0, ignoramos (no insertamos)
            continue;
        }

        // Insertar nueva transacción: si hay detalle enviamos detalle, sino usamos la versión sin detalle
        $detalleToUse = $detalleRaw ?: null;
        if ($detalleToUse !== null && $detalleToUse !== '') {
            $insertDetalleStmt->bind_param("iisds", $idPerfil, $idNum, $fechaTime, $monto, $detalleToUse);
            $insertDetalleStmt->execute();
        } else {
            $insertStmt->bind_param("iisd", $idPerfil, $idNum, $fechaTime, $monto);
            $insertStmt->execute();
        }
    }

    // COMMIT debe estar dentro del try, después del foreach (sin '}' extra)
    $conexion->commit();
    echo "ok";
} catch (Exception $e) {
    $conexion->rollback();
    echo "error: " . $e->getMessage();
}
?>