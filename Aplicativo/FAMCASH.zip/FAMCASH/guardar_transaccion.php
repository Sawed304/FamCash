<?php
/**
 * guardar_transaccion.php
 * ================================================================================
 * ENDPOINT PARA GESTIÓN DE TRANSACCIONES (AJAX)
 * 
 * Este archivo es un endpoint auxiliar que maneja peticiones AJAX desde la UI.
 * Se encarga de:
 *  1. Insertar nuevas transacciones (Ingresos y Egresos)
 *  2. Eliminar transacciones por ID
 *  3. Calcular resúmenes financieros (totales por período)
 * 
 * MÉTODOS Y PARÁMETROS:
 * 
 *  [POST] Insertar transacciones:
 *   - concepto_id[]: IDs de conceptos (array posicional)
 *   - tipo[]: Tipo de transacción: 'Ingreso' o 'Egreso' (array)
 *   - detalle[]: Descripción adicional (array)
 *   - monto[]: Cantidad en dinero (array)
 *   - fecha: Fecha de la transacción (YYYY-MM-DD)
 *   Respuesta: 'ok' si éxito, mensaje de error si falla
 * 
 *  [POST] Eliminar transacción:
 *   - delete_id: ID de la transacción a eliminar
 *   Respuesta: 'ok' si éxito, 'error' si falla
 * 
 *  [GET] Obtener resumen:
 *   - action=summary
 *   - fecha=YYYY-MM-DD
 *   Respuesta: JSON con totales mensuales y anuales
 * 
 * CARACTERÍSTICAS IMPORTANTES:
 *  - Inserta SIEMPRE nuevas filas (no actualiza), evitando sobreescrituras
 *  - Usa transacciones DB para garantizar consistencia
 *  - Si un concepto no existe, intenta crear uno por defecto 'Varios'
 *  - Valida que el perfil sea el dueño de la transacción antes de eliminar
 * ================================================================================
 */

session_start();
include("conexion.php");

// Habilitar que mysqli lance excepciones en lugar de solo retornar false
// Permite usar try/catch para manejo de errores más limpio
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

/**
 * Obtener ID del perfil desde la sesión.
 * Verificar ambas claves posibles ('perfil_id' o 'id_perfil') por compatibilidad.
 * Si no hay sesión válida, retornar error y terminar.
 */
$sessionKey = isset($_SESSION['perfil_id']) ? 'perfil_id' : (isset($_SESSION['id_perfil']) ? 'id_perfil' : null);
if (!$sessionKey) {
    echo "no_session";
    exit;
}

// ID del perfil autenticado (propietario de las transacciones)
$idPerfil = $_SESSION[$sessionKey];

// Fecha de la transacción (por defecto, hoy)
$fecha = $_POST['fecha'] ?? date('Y-m-d');

/**
 * Recibir arrays posicionales desde la UI (entrada_diaria.php envía así):
 * - concepto_id[]: IDs de conceptos seleccionados
 * - tipo[]: Tipo de cada transacción
 * - detalle[]: Descripción opcional de cada transacción
 * - monto[]: Monto de dinero para cada transacción
 * 
 * Validar que sean arrays; si no, usar arrays vacíos
 */
$conceptos = (isset($_POST['concepto_id']) && is_array($_POST['concepto_id'])) ? $_POST['concepto_id'] : [];
$tipos = (isset($_POST['tipo']) && is_array($_POST['tipo'])) ? $_POST['tipo'] : [];
$detalles = (isset($_POST['detalle']) && is_array($_POST['detalle'])) ? $_POST['detalle'] : [];
$montos = (isset($_POST['monto']) && is_array($_POST['monto'])) ? $_POST['monto'] : [];

try {
    /**
     * MANEJO DE ELIMINACIÓN DE TRANSACCIÓN
     * Usar stored procedure sp_eliminar_transaccion
     */
    if (isset($_POST['delete_id'])) {
        $delId = (int)$_POST['delete_id'];
        $delStmt = $conexion->prepare("CALL sp_eliminar_transaccion(?, ?, @resultado)");
        $delStmt->bind_param('ii', $delId, $idPerfil);
        $delStmt->execute();
        $result = $conexion->query("SELECT @resultado AS resultado")->fetch_assoc();
        echo ($result['resultado'] == 1) ? 'ok' : 'error';
        exit;
    }

    /**
     * MANEJO DE ACTUALIZACIÓN DE TRANSACCIONES EXISTENTES
     * Actualiza detalle y/o monto de transacciones ya guardadas
     */
    if (isset($_POST['update_id']) && is_array($_POST['update_id']) && count($_POST['update_id']) > 0) {
        $updateIds = $_POST['update_id'];
        $updateDetalles = $_POST['update_detalle'] ?? [];
        $updateMontos = $_POST['update_monto'] ?? [];
        $updateTipos = $_POST['update_tipo'] ?? [];

        $conexion->begin_transaction();
        
        foreach ($updateIds as $idx => $transId) {
            $transId = (int)$transId;
            $nuevoDetalle = $updateDetalles[$idx] ?? NULL;
            $nuevoMontoRaw = $updateMontos[$idx] ?? '0';
            $nuevoTipo = $updateTipos[$idx] ?? 'Egreso';

            // Normalizar monto
            $nuevoMonto = floatval(str_replace(',', '.', $nuevoMontoRaw));

            // Asegurar signo según tipo
            if (strtolower($nuevoTipo) === 'ingreso') {
                $nuevoMonto = abs($nuevoMonto);
            } else {
                $nuevoMonto = -abs($nuevoMonto);
            }

            if ($nuevoMonto == 0) continue;

            // Actualizar transacción vía procedimiento (verifica propiedad internamente)
            $updateStmt = $conexion->prepare("CALL sp_update_transaccion(?, ?, ?, ?, @res)");
            if ($updateStmt) {
                $updateStmt->bind_param('isdi', $transId, $nuevoDetalle, $nuevoMonto, $idPerfil);
                $updateStmt->execute();
                $updateStmt->close();
                // opcional: revisar @res si se requiere
            }
        }
        
        $conexion->commit();
    }

    /**
     * MANEJO DE RESUMEN FINANCIERO
     * Usar stored procedure sp_get_resumen_rango
     */
    if (isset($_GET['action']) && $_GET['action'] === 'summary') {
        $fechaGet = $_GET['fecha'] ?? date('Y-m-d');
        $monthStart = date('Y-m-01', strtotime($fechaGet));
        $yearStart = date('Y-01-01', strtotime($fechaGet));

        $idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;

        // Año
        $annualIncome = 0; $annualExpense = 0;
        $stmtRange = $conexion->prepare("CALL sp_get_resumen_rango(?, ?, ?, ?, @ingresos, @egresos)");
        if ($stmtRange) {
            $stmtRange->bind_param('iiss', $idFamilia, $idPerfil, $yearStart, $fechaGet);
            $stmtRange->execute();
            $res = $conexion->query("SELECT @ingresos AS ingresos, @egresos AS egresos")->fetch_assoc();
            $annualIncome = (float)($res['ingresos'] ?? 0);
            $annualExpense = (float)($res['egresos'] ?? 0);
            $stmtRange->close();
        }

        // Mes
        $monthlyIncome = 0; $monthlyExpense = 0;
        $stmtRange = $conexion->prepare("CALL sp_get_resumen_rango(?, ?, ?, ?, @ingresos, @egresos)");
        if ($stmtRange) {
            $stmtRange->bind_param('iiss', $idFamilia, $idPerfil, $monthStart, $fechaGet);
            $stmtRange->execute();
            $res = $conexion->query("SELECT @ingresos AS ingresos, @egresos AS egresos")->fetch_assoc();
            $monthlyIncome = (float)($res['ingresos'] ?? 0);
            $monthlyExpense = (float)($res['egresos'] ?? 0);
            $stmtRange->close();
        }

        $yearSum = $annualIncome - $annualExpense;
        $monthSum = $monthlyIncome - $monthlyExpense;
        $monthDisplay = max($monthSum, 0.0);

        header('Content-Type: application/json');
        echo json_encode([
            'month_sum' => $monthSum,
            'month_display' => $monthDisplay,
            'year_sum' => $yearSum
        ]);
        exit;
    }

    $conexion->begin_transaction();

    // Preparar procedimiento para crear transacciones
    $stmtCreateTrans = $conexion->prepare("CALL sp_crear_transaccion(?, ?, ?, ?, ?, @id_transaccion)");
    
    // Procesar arrays posicionales enviados desde la UI
    $count = max(count($conceptos), count($montos));
    for ($i = 0; $i < $count; $i++) {
        $conceptoRaw = $conceptos[$i] ?? '';
        $tipoRaw = $tipos[$i] ?? '';
        $detalleRaw = $detalles[$i] ?? '';
        $valorRaw = $montos[$i] ?? '';

        if ($conceptoRaw === '' || $valorRaw === '') continue;

        // Normalizar monto
        $monto = floatval(str_replace(',', '.', $valorRaw));

        // Asegurar signo según tipo
        if (strtolower($tipoRaw) === 'ingreso') {
            $monto = abs($monto);
        } else {
            $monto = -abs($monto);
        }

        if ($monto == 0) continue;

        $idNum = intval($conceptoRaw);
        $detalleToUse = $detalleRaw ?: NULL;

        // Usar procedimiento para crear transacción
        // sp_crear_transaccion(IN id_perfil INT, IN id_concepto INT, IN fecha DATE, IN monto DECIMAL, IN detalle VARCHAR, OUT id_transaccion INT)
        // Pasar solo los 5 parámetros IN (omitimos el tipo, que no es requerido por el procedimiento)
        $stmtCreateTrans->bind_param("iisds", $idPerfil, $idNum, $fecha, $monto, $detalleToUse);
        $stmtCreateTrans->execute();
    }

    $conexion->commit();
    echo "ok";
} catch (Exception $e) {
    $conexion->rollback();
    echo "error: " . $e->getMessage();
}
?>