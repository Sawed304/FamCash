<?php
/**
 * gestionar_perfiles.php
 * ----------------
 * Página de administración de perfiles familiares (solo Admins).
 */
$idInterfaz = 10; // UI-10 / UI-11 combined
session_start();
include('conexion.php');

// Requerir sesión de familia y rol admin
if (!isset($_SESSION['id_familia'])) {
    header('Location: login.php'); exit;
}

$idFamilia = (int)$_SESSION['id_familia'];
$perfilIdSesion = isset($_SESSION['perfil_id']) ? (int)$_SESSION['perfil_id'] : null;
$perfilRolSesion = isset($_SESSION['perfil_rol']) ? strtolower(trim($_SESSION['perfil_rol'])) : '';

if (!in_array($perfilRolSesion, ['admin','administrador'])) {
    echo "<script>alert('Acceso sólo para administradores.');window.location.href='entrada_diaria.php';</script>";
    exit;
}

// Asegurar columna 'estado' en la tabla Perfil mediante procedimiento (evita SELECT directo)
$checkCol = $conexion->prepare("CALL sp_check_estado_column_in_Perfil()");
if ($checkCol) {
    $checkCol->execute();
    $resCol = $checkCol->get_result();
    $exists = false;
    if ($resCol) {
        $r = $resCol->fetch_assoc();
        if ($r && isset($r['c']) && (int)$r['c'] > 0) $exists = true;
    }
    $checkCol->close();
    if (!$exists) {
        // intentar crear la columna
        $conexion->query("ALTER TABLE Perfil ADD COLUMN estado VARCHAR(20) NOT NULL DEFAULT 'Habilitado'");
    }
}

$mensaje = '';

// Manejar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Crear nuevo perfil
    if ($action === 'create') {
        $nombre = trim($_POST['nombreUsuario'] ?? '');
        $contrasena = $_POST['contrasena'] ?? '';
        $confirm = $_POST['confirmacionContrasena'] ?? '';

        if ($nombre === '' || $contrasena === '' || $confirm === '') {
            $mensaje = "Complete todos los campos para crear el perfil.";
        } elseif ($contrasena !== $confirm) {
            $mensaje = "La contraseña y su confirmación no coinciden.";
        } else {
            // VERIFICAR SI YA EXISTE UN PERFIL CON ESE NOMBRE EN LA MISMA FAMILIA (procedimiento)
            $check_stmt = $conexion->prepare("CALL sp_get_perfil_por_nombre_en_familia(?, ?)");
            $check_stmt->bind_param('is', $idFamilia, $nombre);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $check_stmt->close();
            
            if ($check_result->num_rows > 0) {
                $mensaje = "Ya existe un perfil con el nombre '$nombre' en esta familia. Por favor, elige un nombre diferente.";
            } else {
                $hash = password_hash($contrasena, PASSWORD_DEFAULT);
                $rol = 'Miembro';
                // Usar procedimiento para crear perfil
                $stmt = $conexion->prepare("CALL sp_crear_perfil(?, ?, ?, ?, @id_perfil)");
                if ($stmt) {
                    $stmt->bind_param('isss', $idFamilia, $nombre, $hash, $rol);
                    $stmt->execute();
                    $stmt->close();
                    $rNew = $conexion->query("SELECT @id_perfil AS id")->fetch_assoc();
                    $nuevo_perfil_id = $rNew['id'] ?? 0;

                    if ((int)$nuevo_perfil_id > 0) {
                        // ASIGNAR CONCEPTOS PREDETERMINADOS AL NUEVO PERFIL (usar procedimiento por cada concepto)
                        $conceptos_asignados = 0;
                        $stmtConceptos = $conexion->prepare("CALL sp_get_all_conceptos()");
                        $todos_conceptos = [];
                        if ($stmtConceptos) {
                            $stmtConceptos->execute();
                            $result_conceptos = $stmtConceptos->get_result();
                            if ($result_conceptos && $result_conceptos->num_rows > 0) {
                                while ($concepto = $result_conceptos->fetch_assoc()) {
                                    $todos_conceptos[] = $concepto;
                                }
                            }
                            $stmtConceptos->close();
                        }
                        
                        // Ahora iterar sobre los conceptos guardados
                        foreach ($todos_conceptos as $concepto) {
                            $stmt_insert_concepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                            if ($stmt_insert_concepto) {
                                $stmt_insert_concepto->bind_param('iiis', $nuevo_perfil_id, $idFamilia, $concepto['id_concepto'], $concepto['nombre_concepto']);
                                $stmt_insert_concepto->execute();
                                $resInsertPerfConcepto = $stmt_insert_concepto->get_result();
                                $stmt_insert_concepto->close();
                                if ($resInsertPerfConcepto) {
                                    $rInsert = $resInsertPerfConcepto->fetch_assoc();
                                    if ($rInsert && (int)($rInsert['affected_rows'] ?? 0) > 0) $conceptos_asignados++;
                                }
                            }
                        }

                        $mensaje = 'Perfil creado correctamente. Se asignaron ' . $conceptos_asignados . ' conceptos predeterminados.';
                    } else {
                        $mensaje = 'Error al crear el perfil (procedimiento).';
                    }
                } else {
                    $mensaje = 'Error al preparar la creación de perfil.';
                }
            }
        }
    }

    // Cambiar rol (promover/demoter)
    if ($action === 'change_role') {
        $target = (int)($_POST['perfil_id'] ?? 0);
        $newRole = ($_POST['new_role'] ?? 'Miembro');
        if ($target === $perfilIdSesion && strtolower($newRole) !== 'admin' && strtolower($newRole) !== 'administrador') {
            $mensaje = 'No puedes revocar tu propio rol de Administrador.';
        } else {
            // Antes de cambiar, verificar que al demotar no quede sin administradores
            if (strtolower($newRole) !== 'admin' && strtolower($newRole) !== 'administrador') {
                $countAdmin = $conexion->prepare("CALL sp_count_admins_in_family(?)");
                $countAdmin->bind_param('i', $idFamilia);
                $countAdmin->execute();
                $resCountAdmin = $countAdmin->get_result();
                $r = $resCountAdmin ? $resCountAdmin->fetch_assoc() : ['c' => 0];
                $countAdmin->close();
                $numAdmin = (int)$r['c'];
                if ($numAdmin <= 1) {
                    $mensaje = 'Debe existir al menos un Administrador en la familia.';
                }
            }
            if ($mensaje === '') {
                $upd = $conexion->prepare("CALL sp_cambiar_rol_perfil(?, ?, ?, @res)");
                if ($upd) {
                    $upd->bind_param('iis', $target, $idFamilia, $newRole);
                    $upd->execute();
                    $upd->close();
                    $rchg = $conexion->query("SELECT @res AS result")->fetch_assoc();
                    if ($rchg && (int)$rchg['result'] > 0) $mensaje = 'Rol actualizado.'; else $mensaje = 'Error al actualizar rol.';
                } else {
                    $mensaje = 'Error al preparar cambio de rol.';
                }
            }
        }
    }

    // Toggle estado (habilitar/deshabilitar)
    if ($action === 'toggle_estado') {
        $target = (int)($_POST['perfil_id'] ?? 0);
        // No permitir deshabilitarse a sí mismo
        if ($target === $perfilIdSesion) {
            $mensaje = 'No puedes deshabilitar tu propio perfil.';
        } else {
            // obtener estado actual
                $s = $conexion->prepare("CALL sp_get_estado_perfil(?, ?)");
            $s->bind_param('ii', $target, $idFamilia);
            $s->execute();
            $res = $s->get_result();
            $s->close();
            if ($res && $row = $res->fetch_assoc()) {
                $actual = $row['estado'];
                $nuevo = ($actual === 'Habilitado') ? 'Deshabilitado' : 'Habilitado';
                // si estamos deshabilitando a un admin, asegurarnos al menos otro admin exista
                $rolQ = $conexion->prepare("CALL sp_get_rol_by_perfil(?)");
                $rolQ->bind_param('i', $target);
                $rolQ->execute();
                $resRolQ = $rolQ->get_result();
                $rolR = $resRolQ ? $resRolQ->fetch_assoc() : ['rol' => ''];
                $rolQ->close();
                $esAdminTarget = in_array(strtolower($rolR['rol']), ['admin','administrador']);
                if ($esAdminTarget && $nuevo === 'Deshabilitado') {
                    $countAdmin = $conexion->prepare("CALL sp_count_admins_in_family(?)");
                    if ($countAdmin) {
                        $countAdmin->bind_param('i', $idFamilia);
                        $countAdmin->execute();
                        $resCountAdmin = $countAdmin->get_result();
                        $r = $resCountAdmin ? $resCountAdmin->fetch_assoc() : ['c' => 0];
                        $countAdmin->close();
                    } else {
                        $r = ['c' => 0];
                    }
                    if ((int)$r['c'] <= 1) {
                        $mensaje = 'Debe existir al menos un Administrador habilitado.';
                    }
                }
                if ($mensaje === '') {
                    $u = $conexion->prepare("CALL sp_update_perfil_estado(?, ?, ?, @res)");
                    if ($u) {
                        $u->bind_param('iis', $target, $idFamilia, $nuevo);
                        $u->execute();
                        $u->close();
                        $rr = $conexion->query("SELECT @res AS result")->fetch_assoc();
                        if ($rr && (int)$rr['result'] > 0) $mensaje = 'Estado actualizado.'; else $mensaje = 'Error al actualizar estado.';
                    } else {
                        $mensaje = 'Error al preparar actualización de estado.';
                    }
                }
            } else {
                $mensaje = 'Perfil no encontrado.';
            }
        }
    }
}

// Obtener lista de perfiles de la familia
$perfiles = [];
$lst = $conexion->prepare("CALL sp_get_perfiles_familia(?)");
if ($lst) {
    $lst->bind_param('i', $idFamilia);
    $lst->execute();
    $resLst = $lst->get_result();
    if ($resLst) while ($r = $resLst->fetch_assoc()) $perfiles[] = $r;
    $lst->close();
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestionar Perfiles - FamCash</title>
    <link rel="stylesheet" href="css/gestionar_perfiles.css">
    <link rel="stylesheet" href="css/dialogs.css">
    
</head>
<body>
    <header class="header">
    <div class="logo" onclick="location.href='entrada_diaria.php'">
        <h1>FamCash</h1>
    </div>

    <nav class="menu">
        <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
        <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
        <div class="dropdown">
            <button class="menu-btn active">Configuración ▼</button>
            <div class="dropdown-content">
                <a href="gestionar_concepto.php">Config. de Conceptos</a>
                <a href="configuracion_perfil.php">Config. Perfil</a>
                <a href="gestionar_perfiles.php" style="background:#fffff;color:#000000;">Config. Perfiles Familiares</a>
            </div>
        </div>
    </nav>
</header>


<main>
    <div class="contenedor">

        <!-- Tarjeta izquierda: Crear perfil -->
        <section class="columna izquierda">
            <h2>Crear nuevo perfil</h2>
            <form method="post" onsubmit="return func01_validarCrear();">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Nombre</label>
                    <input class="campo" name="nombreUsuario" required>
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input class="campo" type="password" name="contrasena" id="contrasena" required>
                </div>
                <div class="form-group">
                    <label>Confirmar contraseña</label>
                    <input class="campo" type="password" name="confirmacionContrasena" id="confirmacionContrasena" required>
                </div>
                <div class="botones">
                    <button type="submit" class="guardar">Crear perfil</button>
                </div>
            </form>
        </section>

        <!-- Tarjeta derecha: Listado de perfiles -->
        <section class="columna derecha">
            <h2>Perfiles existentes</h2>

            <?php if (count($perfiles) === 0): ?>
                <p style="color:#666;">No hay perfiles registrados aún.</p>
            <?php endif; ?>

            <?php foreach ($perfiles as $p): ?>
                <div class="perfil-row">
                    <div class="meta">
                        <strong><?php echo htmlspecialchars($p['nombre_perfil']); ?></strong>
                        <span>Rol: <?php echo htmlspecialchars($p['rol']); ?> — Estado: <?php echo htmlspecialchars($p['estado']); ?></span>
                    </div>
                    <div class="acciones">
                        <!-- Cambiar rol -->
                        <form method="post">
                            <input type="hidden" name="action" value="change_role">
                            <input type="hidden" name="perfil_id" value="<?php echo (int)$p['id_perfil']; ?>">
                            <?php if (in_array(strtolower($p['rol']), ['admin','administrador'])): ?>
                                <input type="hidden" name="new_role" value="Miembro">
                                <button type="submit" class="btn-secundario" data-confirm="<?php echo htmlspecialchars('¿Quitar rol de administrador a '. $p['nombre_perfil'] . '?'); ?>">Quitar admin</button>
                            <?php else: ?>
                                <input type="hidden" name="new_role" value="Admin">
                                <button type="submit" class="btn-primario">Hacer admin</button>
                            <?php endif; ?>
                        </form>

                        <!-- Toggle estado -->
                        <form method="post">
                            <input type="hidden" name="action" value="toggle_estado">
                            <input type="hidden" name="perfil_id" value="<?php echo (int)$p['id_perfil']; ?>">
                            <?php if ($p['estado'] === 'Habilitado'): ?>
                                <button type="submit" class="btn-alerta" data-confirm="<?php echo htmlspecialchars('¿Deshabilitar '. $p['nombre_perfil'] . '?'); ?>">Deshabilitar</button>
                            <?php else: ?>
                                <button type="submit" class="btn-exito">Habilitar</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
    </div>

    <?php if ($mensaje !== ''): ?>
        <script>window.addEventListener('load', function(){ alert(<?php echo json_encode($mensaje); ?>); });</script>
    <?php endif; ?>
</main>


    <script src="js/gestionar_perfiles.js"></script>
    <script src="js/ui_dialogs.js"></script>
    <script src="js/confirm_handler.js"></script>
</body>
</html>