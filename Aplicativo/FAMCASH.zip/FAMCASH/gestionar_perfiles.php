<?php
/**
 * gestionar_perfiles.php
 * ----------------
 * Página de administración de perfiles familiares (solo Admins).
 * Funcionalidades:
 *  - Crear nuevos perfiles para la familia
 *  - Promover/demotar roles (Admin / Miembro)
 *  - Habilitar / Deshabilitar perfiles
 * Requiere: $_SESSION['id_familia'] y $_SESSION['perfil_rol'] con rol admin/administrador.
 */
$idInterfaz = 10; // UI-10 / UI-11 combined
session_start();
include('conexion.php');

// Requerir sesión de familia y rol admin
if (!isset($_SESSION['id_familia'])) {
    header('Location: login.php'); exit;
}

$idFamilia = (int)$_SESSION['id_familia'];
$perfilIdSesion = isset($_SESSION['perfil_id']) ? (int)$_SESSION['perfil_id'] : null;
$perfilRolSesion = isset($_SESSION['perfil_rol']) ? strtolower(trim($_SESSION['perfil_rol'])) : '';

if (!in_array($perfilRolSesion, ['admin','administrador'])) {
    echo "<script>alert('Acceso sólo para administradores.');window.location.href='entrada_diaria.php';</script>";
    exit;
}

// Asegurar columna 'estado' en la tabla Perfil (para deshabilitar perfiles)
$checkCol = $conexion->prepare("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='Perfil' AND COLUMN_NAME='estado' LIMIT 1");
$checkCol->execute();
$resCol = $checkCol->get_result();
if (!$resCol || $resCol->num_rows === 0) {
    // intentar crear la columna
    $conexion->query("ALTER TABLE Perfil ADD COLUMN estado VARCHAR(20) NOT NULL DEFAULT 'Habilitado'");
}

$mensaje = '';

// Manejar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Crear nuevo perfil
    if ($action === 'create') {
        $nombre = trim($_POST['nombreUsuario'] ?? '');
        $contrasena = $_POST['contrasena'] ?? '';
        $confirm = $_POST['confirmacionContrasena'] ?? '';

        if ($nombre === '' || $contrasena === '' || $confirm === '') {
            $mensaje = "Complete todos los campos para crear el perfil.";
        } elseif ($contrasena !== $confirm) {
            $mensaje = "La contraseña y su confirmación no coinciden.";
        } else {
            $hash = password_hash($contrasena, PASSWORD_DEFAULT);
            $rol = 'Miembro';
            $stmt = $conexion->prepare("INSERT INTO Perfil (id_perfil, id_familia_Familia, nombre_perfil, contraseña_perfil, rol, estado) VALUES (NULL, ?, ?, ?, ?, 'Habilitado')");
            if ($stmt) {
                $stmt->bind_param('isss', $idFamilia, $nombre, $hash, $rol);
                if ($stmt->execute()) {
                    $mensaje = 'Perfil creado correctamente.';
                } else {
                    $mensaje = 'Error al crear el perfil.';
                }
            } else {
                $mensaje = 'Error al preparar la inserción de perfil.';
            }
        }
    }

    // Cambiar rol (promover/demoter)
    if ($action === 'change_role') {
        $target = (int)($_POST['perfil_id'] ?? 0);
        $newRole = ($_POST['new_role'] ?? 'Miembro');
        if ($target === $perfilIdSesion && strtolower($newRole) !== 'admin' && strtolower($newRole) !== 'administrador') {
            $mensaje = 'No puedes revocar tu propio rol de Administrador.';
        } else {
            // Antes de cambiar, verificar que al demotar no quede sin administradores
            if (strtolower($newRole) !== 'admin' && strtolower($newRole) !== 'administrador') {
                $countAdmin = $conexion->prepare("SELECT COUNT(*) AS c FROM Perfil WHERE id_familia_Familia = ? AND LOWER(rol) IN ('admin','administrador') AND estado = 'Habilitado'");
                $countAdmin->bind_param('i', $idFamilia);
                $countAdmin->execute();
                $r = $countAdmin->get_result()->fetch_assoc();
                $numAdmin = (int)$r['c'];
                if ($numAdmin <= 1) {
                    $mensaje = 'Debe existir al menos un Administrador en la familia.';
                }
            }
            if ($mensaje === '') {
                $upd = $conexion->prepare("UPDATE Perfil SET rol = ? WHERE id_perfil = ? AND id_familia_Familia = ?");
                $upd->bind_param('sii', $newRole, $target, $idFamilia);
                if ($upd->execute()) $mensaje = 'Rol actualizado.'; else $mensaje = 'Error al actualizar rol.';
            }
        }
    }

    // Toggle estado (habilitar/deshabilitar)
    if ($action === 'toggle_estado') {
        $target = (int)($_POST['perfil_id'] ?? 0);
        // No permitir deshabilitarse a sí mismo
        if ($target === $perfilIdSesion) {
            $mensaje = 'No puedes deshabilitar tu propio perfil.';
        } else {
            // obtener estado actual
            $s = $conexion->prepare("SELECT estado FROM Perfil WHERE id_perfil = ? AND id_familia_Familia = ? LIMIT 1");
            $s->bind_param('ii', $target, $idFamilia);
            $s->execute();
            $res = $s->get_result();
            if ($res && $row = $res->fetch_assoc()) {
                $actual = $row['estado'];
                $nuevo = ($actual === 'Habilitado') ? 'Deshabilitado' : 'Habilitado';
                // si estamos deshabilitando a un admin, asegurarnos al menos otro admin exista
                $rolQ = $conexion->prepare("SELECT rol FROM Perfil WHERE id_perfil = ? LIMIT 1");
                $rolQ->bind_param('i', $target);
                $rolQ->execute();
                $rolR = $rolQ->get_result()->fetch_assoc();
                $esAdminTarget = in_array(strtolower($rolR['rol']), ['admin','administrador']);
                if ($esAdminTarget && $nuevo === 'Deshabilitado') {
                    $countAdmin = $conexion->prepare("SELECT COUNT(*) AS c FROM Perfil WHERE id_familia_Familia = ? AND LOWER(rol) IN ('admin','administrador') AND estado = 'Habilitado'");
                    $countAdmin->bind_param('i', $idFamilia);
                    $countAdmin->execute();
                    $r = $countAdmin->get_result()->fetch_assoc();
                    if ((int)$r['c'] <= 1) {
                        $mensaje = 'Debe existir al menos un Administrador habilitado.';
                    }
                }
                if ($mensaje === '') {
                    $u = $conexion->prepare("UPDATE Perfil SET estado = ? WHERE id_perfil = ? AND id_familia_Familia = ?");
                    $u->bind_param('sii', $nuevo, $target, $idFamilia);
                    if ($u->execute()) $mensaje = 'Estado actualizado.'; else $mensaje = 'Error al actualizar estado.';
                }
            } else {
                $mensaje = 'Perfil no encontrado.';
            }
        }
    }
}

// Obtener lista de perfiles de la familia
$lst = $conexion->prepare("SELECT id_perfil, nombre_perfil, rol, estado FROM Perfil WHERE id_familia_Familia = ? ORDER BY id_perfil ASC");
$lst->bind_param('i', $idFamilia);
$lst->execute();
$resLst = $lst->get_result();
$perfiles = [];
if ($resLst) while ($r = $resLst->fetch_assoc()) $perfiles[] = $r;

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestionar Perfiles - FamCash</title>
    <link rel="stylesheet" href="css/gestionar_perfiles.css">
    
</head>
<body>
    <header class="header">
    <div class="logo" onclick="location.href='entrada_diaria.php'">
        <h1>FamCash</h1>
    </div>

    <nav class="menu">
        <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
        <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
        <div class="dropdown">
            <button class="menu-btn active">Configuración ▼</button>
            <div class="dropdown-content">
                <a href="#">Config. de Conceptos</a>
                <a href="configuracion_perfil.php">Config. Perfil</a>
                <a href="gestionar_perfiles.php" style="background:#007bff;color:#fff;">Config. Perfiles Familiares</a>
            </div>
        </div>
    </nav>
</header>


<main>
    <div class="contenedor">

        <!-- Tarjeta izquierda: Crear perfil -->
        <section class="columna izquierda">
            <h2>Crear nuevo perfil</h2>
            <form method="post" onsubmit="return validarCrear();">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label>Nombre</label>
                    <input class="campo" name="nombreUsuario" required>
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input class="campo" type="password" name="contrasena" id="contrasena" required>
                </div>
                <div class="form-group">
                    <label>Confirmar contraseña</label>
                    <input class="campo" type="password" name="confirmacionContrasena" id="confirmacionContrasena" required>
                </div>
                <div class="botones">
                    <button type="submit" class="guardar">Crear perfil</button>
                </div>
            </form>
        </section>

        <!-- Tarjeta derecha: Listado de perfiles -->
        <section class="columna derecha">
            <h2>Perfiles existentes</h2>

            <?php if (count($perfiles) === 0): ?>
                <p style="color:#666;">No hay perfiles registrados aún.</p>
            <?php endif; ?>

            <?php foreach ($perfiles as $p): ?>
                <div class="perfil-row">
                    <div class="meta">
                        <strong><?php echo htmlspecialchars($p['nombre_perfil']); ?></strong>
                        <span>Rol: <?php echo htmlspecialchars($p['rol']); ?> — Estado: <?php echo htmlspecialchars($p['estado']); ?></span>
                    </div>
                    <div class="acciones">
                        <!-- Cambiar rol -->
                        <form method="post">
                            <input type="hidden" name="action" value="change_role">
                            <input type="hidden" name="perfil_id" value="<?php echo (int)$p['id_perfil']; ?>">
                            <?php if (in_array(strtolower($p['rol']), ['admin','administrador'])): ?>
                                <input type="hidden" name="new_role" value="Miembro">
                                <button type="submit" class="btn-secundario" onclick="return confirm('¿Quitar rol de administrador a <?php echo addslashes($p['nombre_perfil']); ?>?')">Quitar admin</button>
                            <?php else: ?>
                                <input type="hidden" name="new_role" value="Admin">
                                <button type="submit" class="btn-primario">Hacer admin</button>
                            <?php endif; ?>
                        </form>

                        <!-- Toggle estado -->
                        <form method="post">
                            <input type="hidden" name="action" value="toggle_estado">
                            <input type="hidden" name="perfil_id" value="<?php echo (int)$p['id_perfil']; ?>">
                            <?php if ($p['estado'] === 'Habilitado'): ?>
                                <button type="submit" class="btn-alerta" onclick="return confirm('¿Deshabilitar <?php echo addslashes($p['nombre_perfil']); ?>?')">Deshabilitar</button>
                            <?php else: ?>
                                <button type="submit" class="btn-exito">Habilitar</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
    </div>

    <?php if ($mensaje !== ''): ?>
        <script>window.addEventListener('load', function(){ alert(<?php echo json_encode($mensaje); ?>); });</script>
    <?php endif; ?>
</main>


    <script>
    function validarCrear(){
        const a = document.getElementById('contrasena').value;
        const b = document.getElementById('confirmacionContrasena').value;
        if (a !== b){ alert('La contraseña y su confirmación no coinciden.'); return false; }
        if (a.length < 6){ alert('La contraseña debe tener al menos 6 caracteres.'); return false; }
        return true;
    }
    </script>
</body>
</html>
