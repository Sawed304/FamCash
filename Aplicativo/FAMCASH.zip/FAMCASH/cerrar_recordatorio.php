<?php
/**
 * cerrar_recordatorio.php
 * -----------------------
 * Maneja el cierre de recordatorios desde la interfaz de entrada diaria.
 * Cuando un usuario hace clic en la "X" de un recordatorio, este archivo
 * procesa la solicitud y marca el recordatorio como cerrado para esa fecha.
 * Retorna una respuesta JSON indicando el éxito o error de la operación.
 * Requiere: $_SESSION['perfil_id']
 */
session_start();
include('conexion.php');

header('Content-Type: application/json');

if (!isset($_SESSION['perfil_id'])) {
    echo json_encode(['success' => false, 'message' => 'No hay sesión activa']);
    exit;
}

$idPerfil = $_SESSION['perfil_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idRecordatorio = (int)($_POST['id_recordatorio'] ?? 0);
    
    if ($idRecordatorio === 0) {
        echo json_encode(['success' => false, 'message' => 'Recordatorio no válido']);
        exit;
    }
    
    // Verificar que el recordatorio pertenece al perfil actual (usar procedimiento)
    $verificar = $conexion->prepare("CALL sp_get_recordatorio_por_id(?, ?)");
    $verificar->bind_param('ii', $idRecordatorio, $idPerfil);
    $verificar->execute();
    $resVerif = $verificar->get_result();
    
    if ($resVerif->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'No tiene permisos para cerrar este recordatorio']);
        exit;
    }
    
    // En un sistema más complejo, aquí podríamos insertar en una tabla de recordatorios_cerrados
    // Para este ejemplo, simplemente retornamos éxito ya que el recordatorio se mostrará
    // nuevamente según su periodicidad
    echo json_encode(['success' => true, 'message' => 'Recordatorio cerrado']);
    
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>