<?php
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    echo "Sesión expirada.";
    exit;
}

$idPerfil = $_SESSION["perfil_id"];
$nombre = trim($_POST["nombre"]);
$tipo = $_POST["tipo"];

if ($nombre == "" || !in_array($tipo, ["ingreso", "egreso"])) {
    echo "Datos inválidos.";
    exit;
}
// Si se pide sólo verificar (check=1), devolver JSON con info sobre existencia
if (isset($_POST['check']) && $_POST['check'] == '1') {
    $fecha = isset($_POST['fecha']) ? $_POST['fecha'] : null;
    // buscar si existe concepto con ese nombre para este perfil
    $stmt = $conexion->prepare("SELECT idConcepto FROM conceptos WHERE idPerfil = ? AND nombre = ? AND estado = 'Habilitado' LIMIT 1");
    $stmt->bind_param('is', $idPerfil, $nombre);
    $stmt->execute();
    $res = $stmt->get_result();
    $existsConcept = false;
    $conceptId = null;
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $existsConcept = true;
        $conceptId = $row['idConcepto'];
    }

    $existsTransaction = false;
    if ($existsConcept && $fecha) {
        $stmt2 = $conexion->prepare("SELECT idTransaccion FROM transacciones WHERE idPerfil = ? AND idConcepto = ? AND fecha = ? LIMIT 1");
        $stmt2->bind_param('iis', $idPerfil, $conceptId, $fecha);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        if ($res2 && $res2->num_rows > 0) {
            $existsTransaction = true;
        }
    }

    header('Content-Type: application/json');
    echo json_encode([
        'exists_concept' => $existsConcept,
        'concept_id' => $conceptId,
        'exists_transaction' => $existsTransaction
    ]);
    exit;
}

// No insertar automáticamente en la tabla `conceptos` desde aquí.
// La creación de conceptos ocurrirá cuando el usuario presione "Guardar" en la pantalla de entrada diaria
// y proporcione un monto. Esto evita conceptos huérfanos creados sin monto.

// Para compatibilidad con otras partes que usen este endpoint sin check, respondemos 'ok' si los datos son válidos.
echo "ok";
?>