<?php
/**
 * gestionar_concepto.php
 * ----------------
 * Página de administración de conceptos (Ingresos y Egresos) con sistema de recordatorios.
 */
$idInterfaz = 11; // UIGestionarConceptos
session_start();
include('conexion.php');

// Verificar que hay sesión de perfil
if (!isset($_SESSION['perfil_id'])) {
    header('Location: seleccionperfil.php');
    exit;
}

$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;
$idPerfil = $_SESSION['perfil_id'];
$mensaje = '';
$tipoMensaje = ''; // 'success' o 'error'

// Inicializar variables para evitar errores
$conceptos = [];
$ingresos = [];
$egresos = [];
$recordatorios = [];

// Manejar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Crear nuevo concepto
    if ($action === 'create') {
        $nombre = trim($_POST['nombre_concepto'] ?? '');
        $tipo = $_POST['tipo_concepto'] ?? '';

        if ($nombre === '' || $tipo === '') {
            $mensaje = "Complete todos los campos para crear el concepto.";
            $tipoMensaje = 'error';
        } elseif (!in_array($tipo, ['Ingreso', 'Egreso'])) {
            $mensaje = "Tipo de concepto inválido.";
            $tipoMensaje = 'error';
        } else {
            // 1. PRIMERO: Verificar si ya existe en Perfil_Concepto para este perfil (mismo nombre y tipo)
            $verificarPerfilConcepto = $conexion->prepare("CALL sp_get_perfil_concepto(?, ?, ?)");
            $verificarPerfilConcepto->bind_param('iss', $idPerfil, $nombre, $tipo);
            $verificarPerfilConcepto->execute();
            $resPerfilConcepto = $verificarPerfilConcepto->get_result();
            $verificarPerfilConcepto->close();
            
            if ($resPerfilConcepto && $resPerfilConcepto->num_rows > 0) {
                $conceptoPerfil = $resPerfilConcepto->fetch_assoc();
                if ($conceptoPerfil['activo'] == 1) {
                    $mensaje = "Ya tienes este concepto activo en tu perfil.";
                    $tipoMensaje = 'error';
                } else {
                    // ACTIVAR el concepto inactivo (mismo tipo) via SP
                    $activarStmt = $conexion->prepare("CALL sp_activate_perfil_concepto(?, ?, @res)");
                    if ($activarStmt) {
                        $activarStmt->bind_param('ii', $idPerfil, $conceptoPerfil['id_concepto']);
                        $activarStmt->execute();
                        $activarStmt->close();
                        $r = $conexion->query("SELECT @res AS result")->fetch_assoc();
                        if ($r && (int)$r['result'] > 0) {
                            $mensaje = "Concepto activado correctamente en tu perfil.";
                            $tipoMensaje = 'success';
                        } else {
                            $mensaje = "Error al activar el concepto.";
                            $tipoMensaje = 'error';
                        }
                    } else {
                        $mensaje = "Error al preparar activación del concepto.";
                        $tipoMensaje = 'error';
                    }
                }
            } else {
                // 2. Verificar si existe en Perfil_Concepto con el mismo nombre pero DIFERENTE tipo (e inactivo)
                $verificarPerfilConceptoDifTipo = $conexion->prepare("CALL sp_get_perfil_concepto_different_tipo(?, ?, ?)");
                $verificarPerfilConceptoDifTipo->bind_param('iss', $idPerfil, $nombre, $tipo);
                $verificarPerfilConceptoDifTipo->execute();
                $resPerfilConceptoDifTipo = $verificarPerfilConceptoDifTipo->get_result();
                $verificarPerfilConceptoDifTipo->close();
                
                if ($resPerfilConceptoDifTipo && $resPerfilConceptoDifTipo->num_rows > 0) {
                    // Existe con diferente tipo pero inactivo - CREAR NUEVO según tu requerimiento
                    $conceptoPerfilDifTipo = $resPerfilConceptoDifTipo->fetch_assoc();
                    
                    // Verificar si el concepto existe en la tabla Concepto con el mismo nombre y tipo deseado
                    $verificarConcepto = $conexion->prepare("CALL sp_get_concepto_by_name(?, ?)");
                    $verificarConcepto->bind_param('ss', $nombre, $tipo);
                    $verificarConcepto->execute();
                    $resConcepto = $verificarConcepto->get_result();
                    $verificarConcepto->close();
                    
                    if ($resConcepto && $resConcepto->num_rows > 0) {
                        // El concepto ya existe en Concepto con el mismo nombre y tipo, obtener su ID
                        $conceptoExistente = $resConcepto->fetch_assoc();
                        $id_concepto = $conceptoExistente['id_concepto'];
                        
                        // Insertar en Perfil_Concepto via SP
                        $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                        $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_concepto, $nombre);
                        if ($stmtInsertPerfilConcepto->execute()) {
                            $mensaje = "Concepto creado y agregado a tu perfil correctamente.";
                            $tipoMensaje = 'success';
                        } else {
                            $mensaje = "Error al agregar el concepto a tu perfil.";
                            $tipoMensaje = 'error';
                        }
                    } else {
                        // No existe en Concepto, crear nuevo concepto
                        $stmtInsertConcepto = $conexion->prepare("CALL sp_insert_concepto(?, ?)");
                        $stmtInsertConcepto->bind_param('ss', $nombre, $tipo);
                        
                        if ($stmtInsertConcepto->execute()) {
                            $resInsertConcepto = $stmtInsertConcepto->get_result();
                            $id_nuevo_concepto = null;
                            if ($resInsertConcepto) {
                                $rowConcepto = $resInsertConcepto->fetch_assoc();
                                $id_nuevo_concepto = $rowConcepto['id_concepto'] ?? null;
                            }
                            $stmtInsertConcepto->close();
                            
                            // Insertar en Perfil_Concepto via SP
                            $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                            $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_nuevo_concepto, $nombre);
                            
                            if ($stmtInsertPerfilConcepto->execute()) {
                                $resInsertPerfilConcepto = $stmtInsertPerfilConcepto->get_result();
                                $stmtInsertPerfilConcepto->close();
                                $mensaje = "Concepto creado y agregado a tu perfil correctamente (mismo nombre, diferente tipo).";
                                $tipoMensaje = 'success';
                            } else {
                                $mensaje = "Concepto creado pero error al agregarlo a tu perfil.";
                                $tipoMensaje = 'error';
                            }
                        } else {
                            // Si hay conflicto de nombres, crear con nombre único
                            if ($stmtInsertConcepto->errno == 1062) { // Error de duplicado
                                $nombreUnico = $nombre . '_' . strtolower($tipo);
                                
                                $stmtInsertConceptoUnico = $conexion->prepare("CALL sp_insert_concepto(?, ?)");
                                $stmtInsertConceptoUnico->bind_param('ss', $nombreUnico, $tipo);
                                
                                if ($stmtInsertConceptoUnico->execute()) {
                                    $id_nuevo_concepto = $stmtInsertConceptoUnico->insert_id;
                                    
                                    // Insertar en Perfil_Concepto via SP
                                    $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                                    $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_nuevo_concepto, $nombre);
                                    
                                    if ($stmtInsertPerfilConcepto->execute()) {
                                        $mensaje = "Concepto creado y agregado a tu perfil correctamente (nombre ajustado por conflicto).";
                                        $tipoMensaje = 'success';
                                    } else {
                                        $mensaje = "Concepto creado pero error al agregarlo a tu perfil.";
                                        $tipoMensaje = 'error';
                                    }
                                } else {
                                    $mensaje = "Error al crear el concepto con nombre único.";
                                    $tipoMensaje = 'error';
                                }
                            } else {
                                $mensaje = "Error al crear el concepto.";
                                $tipoMensaje = 'error';
                            }
                        }
                    }
                } else {
                    // 3. Verificar si el concepto existe en la tabla Concepto (mismo nombre y tipo)
                    $verificarConcepto = $conexion->prepare("CALL sp_get_concepto_by_name(?, ?)");
                    $verificarConcepto->bind_param('ss', $nombre, $tipo);
                    $verificarConcepto->execute();
                    $resConcepto = $verificarConcepto->get_result();
                    $verificarConcepto->close();
                    
                    if ($resConcepto && $resConcepto->num_rows > 0) {
                        // El concepto ya existe en Concepto con el mismo nombre y tipo, obtener su ID
                        $conceptoExistente = $resConcepto->fetch_assoc();
                        $id_concepto = $conceptoExistente['id_concepto'];
                        
                        // Insertar en Perfil_Concepto via SP
                        $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                        $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_concepto, $nombre);
                        if ($stmtInsertPerfilConcepto->execute()) {
                            $mensaje = "Concepto agregado a tu perfil correctamente.";
                            $tipoMensaje = 'success';
                        } else {
                            $mensaje = "Error al agregar el concepto a tu perfil.";
                            $tipoMensaje = 'error';
                        }
                    } else {
                        // 4. Verificar si existe en Concepto con el mismo nombre pero DIFERENTE tipo
                        $verificarMismoNombre = $conexion->prepare("CALL sp_get_concepto_same_name(?)");
                        $verificarMismoNombre->bind_param('s', $nombre);
                        $verificarMismoNombre->execute();
                        $resMismoNombre = $verificarMismoNombre->get_result();
                        $verificarMismoNombre->close();
                        
                        if ($resMismoNombre && $resMismoNombre->num_rows > 0) {
                            // Existe con el mismo nombre pero diferente tipo - CREAR NUEVO
                            $conceptoMismoNombre = $resMismoNombre->fetch_assoc();
                            
                            $stmtInsertConcepto = $conexion->prepare("CALL sp_insert_concepto(?, ?)");
                            $stmtInsertConcepto->bind_param('ss', $nombre, $tipo);
                            
                            if ($stmtInsertConcepto->execute()) {
                                $resInsertConcepto = $stmtInsertConcepto->get_result();
                                $id_nuevo_concepto = null;
                                if ($resInsertConcepto) {
                                    $rowConcepto = $resInsertConcepto->fetch_assoc();
                                    $id_nuevo_concepto = $rowConcepto['id_concepto'] ?? null;
                                }
                                $stmtInsertConcepto->close();
                                
                                // Insertar en Perfil_Concepto via SP
                                $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                                $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_nuevo_concepto, $nombre);
                                
                                if ($stmtInsertPerfilConcepto->execute()) {
                                    $resInsertPerfilConcepto = $stmtInsertPerfilConcepto->get_result();
                                    $stmtInsertPerfilConcepto->close();
                                    $mensaje = "Concepto creado y agregado a tu perfil correctamente (mismo nombre, diferente tipo).";
                                    $tipoMensaje = 'success';
                                } else {
                                    $mensaje = "Concepto creado pero error al agregarlo a tu perfil.";
                                    $tipoMensaje = 'error';
                                }
                            } else {
                                // Si hay conflicto de nombres, crear con nombre único
                                if ($stmtInsertConcepto->errno == 1062) { // Error de duplicado
                                    $nombreUnico = $nombre . '_' . strtolower($tipo);
                                    
                                    $stmtInsertConceptoUnico = $conexion->prepare("CALL sp_insert_concepto(?, ?)");
                                    $stmtInsertConceptoUnico->bind_param('ss', $nombreUnico, $tipo);
                                    
                                    if ($stmtInsertConceptoUnico->execute()) {
                                        $id_nuevo_concepto = $stmtInsertConceptoUnico->insert_id;
                                        
                                        // Insertar en Perfil_Concepto via SP
                                        $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                                        $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_nuevo_concepto, $nombre);
                                        
                                        if ($stmtInsertPerfilConcepto->execute()) {
                                            $mensaje = "Concepto creado y agregado a tu perfil correctamente (nombre ajustado por conflicto).";
                                            $tipoMensaje = 'success';
                                        } else {
                                            $mensaje = "Concepto creado pero error al agregarlo a tu perfil.";
                                            $tipoMensaje = 'error';
                                        }
                                    } else {
                                        $mensaje = "Error al crear el concepto con nombre único.";
                                        $tipoMensaje = 'error';
                                    }
                                } else {
                                    $mensaje = "Error al crear el concepto.";
                                    $tipoMensaje = 'error';
                                }
                            }
                        } else {
                            // No existe en Concepto, crear nuevo concepto
                            $stmtInsertConcepto = $conexion->prepare("CALL sp_insert_concepto(?, ?)");
                            $stmtInsertConcepto->bind_param('ss', $nombre, $tipo);
                            
                            if ($stmtInsertConcepto->execute()) {
                                $resInsertConcepto = $stmtInsertConcepto->get_result();
                                $id_nuevo_concepto = null;
                                if ($resInsertConcepto) {
                                    $rowConcepto = $resInsertConcepto->fetch_assoc();
                                    $id_nuevo_concepto = $rowConcepto['id_concepto'] ?? null;
                                }
                                $stmtInsertConcepto->close();
                                
                                // Insertar en Perfil_Concepto via SP
                                $stmtInsertPerfilConcepto = $conexion->prepare("CALL sp_insert_perfil_concepto(?, ?, ?, ?)");
                                $stmtInsertPerfilConcepto->bind_param('iiis', $idPerfil, $idFamilia, $id_nuevo_concepto, $nombre);
                                
                                if ($stmtInsertPerfilConcepto->execute()) {
                                    $resInsertPerfilConcepto = $stmtInsertPerfilConcepto->get_result();
                                    $stmtInsertPerfilConcepto->close();
                                    $mensaje = "Concepto creado y agregado a tu perfil correctamente.";
                                    $tipoMensaje = 'success';
                                } else {
                                    $mensaje = "Concepto creado pero error al agregarlo a tu perfil.";
                                    $tipoMensaje = 'error';
                                }
                            } else {
                                $mensaje = "Error al crear el concepto.";
                                $tipoMensaje = 'error';
                            }
                        }
                    }
                }
            }
        }
    }

    // Editar concepto (solo el alias)
    if ($action === 'edit') {
        $id_concepto = (int)($_POST['id_concepto'] ?? 0);
        $alias = trim($_POST['alias_concepto'] ?? '');

        if ($id_concepto === 0 || $alias === '') {
            $mensaje = "Complete el alias para editar el concepto.";
            $tipoMensaje = 'error';
        } else {
            // Actualizar solo el alias en Perfil_Concepto vía procedimiento
            $stmt = $conexion->prepare("CALL sp_update_perfil_concepto_alias(?, ?, ?, @res)");
            if ($stmt) {
                $stmt->bind_param('iis', $idPerfil, $id_concepto, $alias);
                $stmt->execute();
                $stmt->close();
                $r = $conexion->query("SELECT @res AS result")->fetch_assoc();
                if ($r && (int)$r['result'] > 0) {
                    $mensaje = "Alias actualizado correctamente.";
                    $tipoMensaje = 'success';
                } else {
                    $mensaje = "Error al actualizar el alias.";
                    $tipoMensaje = 'error';
                }
            } else {
                $mensaje = "Error al preparar actualización de alias.";
                $tipoMensaje = 'error';
            }
        }
    }

    // Eliminar concepto (desactivar en Perfil_Concepto)
    if ($action === 'delete') {
        $id_concepto = (int)($_POST['id_concepto'] ?? 0);

        if ($id_concepto === 0) {
            $mensaje = "Concepto no válido.";
            $tipoMensaje = 'error';
        } else {
            // Verificar si hay transacciones asociadas a ESTE PERFIL con ESTE CONCEPTO (procedimiento)
            $verificar = $conexion->prepare("CALL sp_count_transactions_by_concept_and_perfil(?, ?)");
            $verificar->bind_param('ii', $id_concepto, $idPerfil);
            $verificar->execute();
            $resTemp = $verificar->get_result();
            $resVerif = $resTemp ? $resTemp->fetch_assoc() : ['c' => 0];
            $verificar->close();

            if ((int)$resVerif['c'] > 0) {
                $mensaje = "No se puede eliminar un concepto que tiene transacciones asociadas en tu perfil.";
                $tipoMensaje = 'error';
            } else {
                // Desactivar en Perfil_Concepto vía procedimiento (no eliminar)
                $stmt = $conexion->prepare("CALL sp_deactivate_perfil_concepto(?, ?, @res)");
                if ($stmt) {
                    $stmt->bind_param('ii', $idPerfil, $id_concepto);
                    $stmt->execute();
                    $stmt->close();
                    $r = $conexion->query("SELECT @res AS result")->fetch_assoc();
                    if ($r && (int)$r['result'] > 0) {
                        $mensaje = "Concepto eliminado de tu perfil correctamente.";
                        $tipoMensaje = 'success';
                    } else {
                        $mensaje = "Error al eliminar el concepto.";
                        $tipoMensaje = 'error';
                    }
                } else {
                    $mensaje = "Error al preparar desactivación del concepto.";
                    $tipoMensaje = 'error';
                }
            }
        }
    }
}

// Obtener lista de conceptos ACTIVOS para este perfil
$conceptos = [];
$stmt = $conexion->prepare("CALL sp_get_conceptos_activos_por_perfil(?)");
if ($stmt) {
    $stmt->bind_param('i', $idPerfil);
    $stmt->execute();
    $resConceptos = $stmt->get_result();
    if ($resConceptos) {
        while ($r = $resConceptos->fetch_assoc()) {
            $conceptos[] = $r;
        }
    }
    $stmt->close();
}

// Obtener recordatorios del perfil actual
$stmtRecordatorios = $conexion->prepare("CALL sp_get_recordatorios_por_perfil(?)");
if ($stmtRecordatorios) {
    $stmtRecordatorios->bind_param('i', $idPerfil);
    $stmtRecordatorios->execute();
    $resRecordatorios = $stmtRecordatorios->get_result();
    if ($resRecordatorios) {
        while ($r = $resRecordatorios->fetch_assoc()) {
            $recordatorios[] = $r;
        }
    }
    $stmtRecordatorios->close();
}

// Separar por tipo
$ingresos = array_filter($conceptos, function($c) { return $c['tipo'] === 'Ingreso'; });
$egresos = array_filter($conceptos, function($c) { return $c['tipo'] === 'Egreso'; });

// rol del perfil en sesión
$isAdmin = isset($_SESSION['perfil_rol']) && in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin','administrador']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestionar Conceptos - FamCash</title>
    <link rel="stylesheet" href="css/gestionar_perfiles.css">
    <link rel="stylesheet" href="css/gestionar_concepto.css">
    <link rel="stylesheet" href="css/dialogs.css">
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
            <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
            <div class="dropdown">
                <button class="menu-btn active">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="gestionar_concepto.php">Config. de Conceptos</a>
                    <a href="configuracion_perfil.php">Config. Perfil</a>
                    <?php if ($isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="contenedor">
            <!-- Tarjeta izquierda: Crear concepto -->
            <section class="columna izquierda">
                <h2>Agregar concepto a mi perfil</h2>
                
                <?php if ($mensaje): ?>
                    <div class="mensaje <?php echo $tipoMensaje; ?>">
                        <?php echo htmlspecialchars($mensaje); ?>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <input type="hidden" name="action" value="create">
                    <div class="form-group">
                        <label>Nombre del concepto</label>
                        <input type="text" name="nombre_concepto" placeholder="Ej: Sueldo, Alquiler, etc." required>
                    </div>
                    <div class="form-group">
                        <label>Tipo</label>
                        <select name="tipo_concepto" required>
                            <option value="">-- Seleccionar tipo --</option>
                            <option value="Ingreso">Ingreso</option>
                            <option value="Egreso">Egreso</option>
                        </select>
                    </div>
                    
                    <div class="botones">
                        <button type="submit" class="guardar">Agregar concepto</button>
                    </div>
                </form>
                
                <!-- Sección para crear recordatorios independientes -->
                <h3 style="margin-top: 30px;">Crear Recordatorio Independiente</h3>
                <form method="post" action="guardar_recordatorio.php">
                    <div class="form-group">
                        <label>Texto del recordatorio</label>
                        <input type="text" name="nombre_recordatorio" placeholder="Recordatorio personalizado" required>
                    </div>
                    <div class="form-group">
                        <label>Fecha de inicio</label>
                        <input type="date" name="fecha_inicio" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Periodicidad</label>
                        <select name="periodo" required>
                            <option value="diario">Diario</option>
                            <option value="semanal">Semanal</option>
                            <option value="quincenal">Quincenal</option>
                            <option value="mensual">Mensual</option>
                        </select>
                    </div>
                    <div class="botones">
                        <button type="submit" class="guardar">Crear Recordatorio</button>
                    </div>
                </form>
            </section>

            <!-- Tarjeta derecha: Listado de conceptos y recordatorios -->
            <section class="columna derecha">
                <h2>Mis conceptos activos</h2>

                <div class="listado-conceptos">
                    <?php if (count($conceptos) === 0): ?>
                        <p style="color:#666;text-align:center;padding:20px;">No hay conceptos activos en tu perfil.</p>
                    <?php else: ?>
                        <!-- Ingresos -->
                        <?php if (count($ingresos) > 0): ?>
                            <h4 style="padding: 10px 0; border-bottom: 2px solid #4a82f2; margin: 15px 0;">Ingresos</h4>
                            <?php foreach ($ingresos as $concepto): ?>
                                <div class="concepto-item">
                                    <div class="concepto-info">
                                        <strong><?php echo htmlspecialchars($concepto['alias_concepto'] ?? $concepto['nombre_concepto']); ?></strong>
                                        <?php if ($concepto['alias_concepto']): ?>
                                            <small>Original: <?php echo htmlspecialchars($concepto['nombre_concepto']); ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="concepto-acciones">
                                        <button type="button" class="btn-editar" onclick="func01_abrirModalEditar(<?php echo $concepto['id_concepto']; ?>, '<?php echo addslashes($concepto['alias_concepto'] ?? $concepto['nombre_concepto']); ?>')">Editar alias</button>
                                        <form method="post" style="display:inline;" data-confirm="<?php echo htmlspecialchars('¿Eliminar este concepto de tu perfil?'); ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id_concepto" value="<?php echo $concepto['id_concepto']; ?>">
                                            <button type="submit" class="btn-eliminar">Aceptar</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <!-- Egresos -->
                        <?php if (count($egresos) > 0): ?>
                            <h4 style="padding: 10px 0; border-bottom: 2px solid #e74c3c; margin: 15px 0;">Egresos</h4>
                            <?php foreach ($egresos as $concepto): ?>
                                <div class="concepto-item egreso">
                                    <div class="concepto-info">
                                        <strong><?php echo htmlspecialchars($concepto['alias_concepto'] ?? $concepto['nombre_concepto']); ?></strong>
                                        <?php if ($concepto['alias_concepto']): ?>
                                            <small>Original: <?php echo htmlspecialchars($concepto['nombre_concepto']); ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="concepto-acciones">
                                        <button type="button" class="btn-editar" onclick="func01_abrirModalEditar(<?php echo $concepto['id_concepto']; ?>, '<?php echo addslashes($concepto['alias_concepto'] ?? $concepto['nombre_concepto']); ?>')">Editar alias</button>
                                        <form method="post" style="display:inline;" data-confirm="<?php echo htmlspecialchars('¿Eliminar este concepto de tu perfil?'); ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id_concepto" value="<?php echo $concepto['id_concepto']; ?>">
                                            <button type="submit" class="btn-eliminar">Eliminar</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Lista de recordatorios activos -->
                <h2 style="margin-top: 30px;">Recordatorios Activos</h2>
                <div class="listado-recordatorios">
                    <?php if (count($recordatorios) === 0): ?>
                        <p style="color:#666;text-align:center;padding:20px;">No hay recordatorios activos.</p>
                    <?php else: ?>
                        <?php foreach ($recordatorios as $recordatorio): ?>
                            <div class="recordatorio-item">
                                <div class="recordatorio-info">
                                    <strong><?php echo htmlspecialchars($recordatorio['nombre_recordatorio']); ?></strong>
                                    <small>
                                        Inicio: <?php echo date('d/m/Y', strtotime($recordatorio['fecha_inicio'])); ?> | 
                                        Periodicidad: <?php echo ucfirst($recordatorio['periodo']); ?>
                                    </small>
                                </div>
                                <div class="recordatorio-acciones">
                                    <form method="post" action="eliminar_recordatorio.php" style="display:inline;" data-confirm="<?php echo htmlspecialchars('¿Eliminar este recordatorio?'); ?>">
                                        <input type="hidden" name="id_recordatorio" value="<?php echo $recordatorio['id_recordatorio']; ?>">
                                        <button type="submit" class="btn-eliminar">Eliminar</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>

    <!-- Modal para editar alias -->
    <div class="modal-overlay" id="modalEditar">
        <div class="modal-content">
            <h3>Editar alias del concepto</h3>
            <form method="post">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id_concepto" id="modalId">
                <div class="form-group">
                    <label>Alias personalizado</label>
                    <input type="text" name="alias_concepto" id="modalAlias" placeholder="Alias personalizado" required>
                    <small>Este es el nombre que verás en tu perfil</small>
                </div>
                <div class="modal-botones">
                    <button type="button" class="btn-cancelar" onclick="func02_cerrarModal()">Cancelar</button>
                    <button type="submit" class="btn-guardar">Guardar alias</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function func01_abrirModalEditar(id, alias) {
        document.getElementById('modalId').value = id;
        document.getElementById('modalAlias').value = alias;
        document.getElementById('modalEditar').classList.add('active');
    }

    function func02_cerrarModal() {
        document.getElementById('modalEditar').classList.remove('active');
    }

    // Cerrar modal al hacer clic fuera
    document.addEventListener('DOMContentLoaded', function() {
        const modal = document.getElementById('modalEditar');
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    cerrarModal();
                }
            });
        }
    });
    </script>
    <script src="js/ui_dialogs.js"></script>
    <script src="js/confirm_handler.js"></script>
    <script src="js/gestionar_concepto.js?v=<?php echo filemtime('js/gestionar_concepto.js'); ?>"></script>
</body>
</html>