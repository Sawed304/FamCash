<?php
/**
 * eliminar_recordatorio.php
 * -------------------------
 * Maneja la eliminación de recordatorios desde la interfaz de gestión de conceptos.
 * Elimina un recordatorio específico basado en su ID, verificando que pertenezca al perfil en sesión.
 * Requiere: $_SESSION['perfil_id']
 */
session_start();
include('conexion.php');

if (!isset($_SESSION['perfil_id'])) {
    header('Location: seleccionperfil.php');
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$mensaje = '';
$tipoMensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idRecordatorio = (int)($_POST['id_recordatorio'] ?? 0);
    
    if ($idRecordatorio === 0) {
        $mensaje = "Recordatorio no válido.";
        $tipoMensaje = 'error';
    } else {
        // Verificar que el recordatorio pertenece al perfil actual (usar procedimiento)
        $verificar = $conexion->prepare("CALL sp_get_recordatorio_por_id(?, ?)");
        $verificar->bind_param('ii', $idRecordatorio, $idPerfil);
        $verificar->execute();
        $resVerif = $verificar->get_result();
        $verificar->close();
        
        if ($resVerif->num_rows === 0) {
            $mensaje = "No tiene permisos para eliminar este recordatorio.";
            $tipoMensaje = 'error';
        } else {
            $stmt = $conexion->prepare("CALL sp_delete_recordatorio(?, ?)");
            $stmt->bind_param('ii', $idRecordatorio, $idPerfil);
            
            if ($stmt->execute()) {
                $resTemp = $stmt->get_result();
                $stmt->close();
                $mensaje = "Recordatorio eliminado correctamente.";
                $tipoMensaje = 'success';
            } else {
                $mensaje = "Error al eliminar el recordatorio: " . $stmt->error;
                $tipoMensaje = 'error';
            }
        }
    }
}

// Redirigir de vuelta a gestionar_concepto.php con mensaje
$_SESSION['mensaje_recordatorio'] = $mensaje;
$_SESSION['tipo_mensaje_recordatorio'] = $tipoMensaje;
header('Location: gestionar_concepto.php');
exit;
?>