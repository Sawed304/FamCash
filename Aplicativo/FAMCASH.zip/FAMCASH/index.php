<?php
/**
 * index.php
 * ----------------
 * Página de aterrizaje pública del proyecto FamCash.
 * - Muestra botones para registrar o iniciar sesión.
 * - Define $idInterfaz = 1 (referencia del diccionario de interfaces).
 */
 $idInterfaz = 1; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
<header>
    <div class="logo">
            <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
        <h1>FamCash</h1>
    </div>
    <div class="botones">
        <button onclick="ingresarARegistro(2)">Registrar</button>
        <button onclick="ingresarAIniciarSesión(3)">Iniciar Sesión</button>
    </div>
</header>

<main>
    <section class="izquierda">
        <img src="img/money.png" alt="Dinero">
        <h2>Gestiona, ahorra y planifica sin complicaciones.</h2>
    </section>
    <section class="derecha">
        <h1>FamCash</h1>
        <img src="img/fam_happy.png" alt="Familia">
    </section>
</main>

<footer>
    © 2025 FamCash | Proyecto Solve-It
</footer>

<script src="js/index.js"></script>
</body>
</html>

