<?php
// index.php – Página de información de FamCash
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FamCash</title>
    <link rel="img" href="img/logo_solveit.png">
    <link rel="stylesheet" href="css/style1.css">

</head>
<body>
    <header>
        <div class="logo">
            <img src="img/logo_solveit.png" alt="Logo" class="logo-img">
            <h1>SOLVE-IT</h1>
        </div>

        <div class="botones">
            <button onclick="location.href='registro.php'">Registrar</button>
            <button onclick="location.href='login.php'">Iniciar Sesión</button>
        </div>
    </header>

    <main>
        <section class="izquierda">
            <img src="img/money.png" alt="Dinero" class="icono">
            <h2>Gestiona, ahorra<br>y planifica sin<br>complicaciones.</h2>
        </section>

        <section class="derecha">
            <h1>FamCash</h1>
            <p class="simbolo">S/.</p>
            <img src="img/fam_happy.png" alt="Familia" class="familia">
        </section>
    </main>

    <footer>
        © 2025 FamCash | Proyecto Solve-It
    </footer>
</body>

</html>
