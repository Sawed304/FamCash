<?php
/**
 * guardar_recordatorio.php
 * ------------------------
 * Maneja la creación de recordatorios independientes desde la interfaz de gestión de conceptos.
 * Procesa los datos del formulario de recordatorio y los inserta en la tabla recordatorio.
 * Requiere: $_SESSION['perfil_id'], $_SESSION['id_familia']
 */
session_start();
include('conexion.php');

if (!isset($_SESSION['perfil_id'])) {
    header('Location: seleccionperfil.php');
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;
$mensaje = '';
$tipoMensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombreRecordatorio = trim($_POST['nombre_recordatorio'] ?? '');
    $fechaInicio = $_POST['fecha_inicio'] ?? date('Y-m-d');
    $periodo = $_POST['periodo'] ?? 'diario';
    
    if ($nombreRecordatorio === '') {
        $mensaje = "El texto del recordatorio es obligatorio.";
        $tipoMensaje = 'error';
    } elseif (!in_array($periodo, ['diario', 'semanal', 'quincenal', 'mensual'])) {
        $mensaje = "Periodicidad no válida.";
        $tipoMensaje = 'error';
    } else {
        $stmt = $conexion->prepare("CALL sp_insert_recordatorio(?, ?, ?, ?, ?)");
        $stmt->bind_param('iisss', $idPerfil, $idFamilia, $nombreRecordatorio, $fechaInicio, $periodo);
        
        if ($stmt->execute()) {
            $resTemp = $stmt->get_result();
            $stmt->close();
            $mensaje = "Recordatorio creado correctamente.";
            $tipoMensaje = 'success';
        } else {
            $mensaje = "Error al crear el recordatorio: " . $stmt->error;
            $tipoMensaje = 'error';
        }
    }
}

// Redirigir de vuelta a gestionar_concepto.php con mensaje
$_SESSION['mensaje_recordatorio'] = $mensaje;
$_SESSION['tipo_mensaje_recordatorio'] = $tipoMensaje;
header('Location: gestionar_concepto.php');
exit;
?>