let ingresos = [];
let egresos = [];

function renderLista(tipo) {
    const lista = document.getElementById(tipo === "ingreso" ? "listaIngresos" : "listaEgresos");
    const data = tipo === "ingreso" ? ingresos : egresos;
    lista.innerHTML = "";

    data.forEach((item, index) => {
        const div = document.createElement("div");
        div.innerHTML = `
            <span>${item.nombre}</span>
            <input type="number" value="${item.monto}" onchange="actualizarMonto('${tipo}', ${index}, this.value)">
            <button onclick="eliminarConcepto('${tipo}', ${index})">✖</button>
        `;
        lista.appendChild(div);
    });
    recalcularTotales();
}

function agregarConcepto(tipo) {
    const select = document.getElementById(tipo === "ingreso" ? "selectIngreso" : "selectEgreso");
    const input = document.getElementById(tipo === "ingreso" ? "inputIngreso" : "inputEgreso");
    let nombre = select.value === "nuevo" ? input.value.trim() : select.value;

    if (!nombre) return alert("Ingrese un nombre válido.");

    const data = tipo === "ingreso" ? ingresos : egresos;
    data.push({ nombre, monto: 0 });
    renderLista(tipo);
    input.value = "";
}

function eliminarConcepto(tipo, index) {
    const data = tipo === "ingreso" ? ingresos : egresos;
    data.splice(index, 1);
    renderLista(tipo);
}

function actualizarMonto(tipo, index, valor) {
    const data = tipo === "ingreso" ? ingresos : egresos;
    data[index].monto = parseFloat(valor) || 0;
    recalcularTotales();
}

function recalcularTotales() {
    const totalIngresos = ingresos.reduce((s, i) => s + i.monto, 0);
    const totalEgresos = egresos.reduce((s, i) => s + i.monto, 0);

    document.getElementById("totalIngresos").textContent = totalIngresos.toFixed(2);
    document.getElementById("totalEgresos").textContent = totalEgresos.toFixed(2);

    document.getElementById("balanceAnual").value = (totalIngresos - totalEgresos).toFixed(2);
    document.getElementById("balanceMensual").value = (totalIngresos * 0.8 - totalEgresos).toFixed(2);
}

document.getElementById("guardar").addEventListener("click", () => {
    const perfil = "<?php echo $perfilId; ?>";
    const fecha = document.getElementById("fecha").value;

    localStorage.setItem(`ingresos_${perfil}_${fecha}`, JSON.stringify(ingresos));
    localStorage.setItem(`egresos_${perfil}_${fecha}`, JSON.stringify(egresos));
    alert("Datos guardados (simulación local).");
});

window.onload = () => {
    const perfil = "<?php echo $perfilId; ?>";
    const fecha = document.getElementById("fecha").value;

    ingresos = JSON.parse(localStorage.getItem(`ingresos_${perfil}_${fecha}`)) || [];
    egresos = JSON.parse(localStorage.getItem(`egresos_${perfil}_${fecha}`)) || [];

    renderLista("ingreso");
    renderLista("egreso");
};
