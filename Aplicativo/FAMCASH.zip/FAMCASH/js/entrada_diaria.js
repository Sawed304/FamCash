/**
 * entrada_diaria.js
 * ================================================================================
 * LÓGICA DE INTERFAZ DE USUARIO PARA LA PÁGINA DE ENTRADA DIARIA (entrada_diaria.php)
 * 
 * Este archivo contiene funciones para:
 *  1. Agregar nuevas filas de transacciones (ingresos y gastos)
 *  2. Eliminar filas de transacciones (nuevo y guardado)
 *  3. Calcular totales de ingresos y gastos en tiempo real
 *  4. Guardar transacciones al servidor mediante formulario/AJAX
 *  5. Actualizar resúmenes mensuales y anuales
 *  6. Manejar dropdowns de selección de conceptos

/*
 * func01_toggleDetalleInput
 *
 * 1. Descripción
 * Muestra u oculta el input de detalle asociado a un select de conceptos.
 *
 * 2. Parámetros
 * - nombre: selectId
 *   tipo: string
 *   explicación: ID del elemento <select> que contiene conceptos.
 * - nombre: inputId
 *   tipo: string
 *   explicación: ID del input de detalle que se muestra/oculta.
 *
 * 3. Errores, advertencias o notas
 * - Asume que los elementos existen en el DOM cuando se llama.
 */
function func01_toggleDetalleInput(selectId, inputId) {
    const select = document.getElementById(selectId);
    const input = document.getElementById(inputId);
    
    select.addEventListener('change', e => {
        const val = e.target.value;
        if (val) {
            input.style.display = 'block';
            input.focus();
        } else {
            input.style.display = 'none';
            input.value = '';
        }
    });
}

/*
 * func02_addTransactionRow
 *
 * 1. Descripción
 * Crea y agrega una nueva fila de transacción (ingreso/egreso) en la interfaz.
 *
 * 2. Parámetros
 * - nombre: tipo
 *   tipo: string
 *   explicación: 'ingreso' o 'egreso' (determina el panel donde insertar).
 * - nombre: detalle
 *   tipo: string
 *   explicación: Descripción o detalle de la transacción.
 * - nombre: conceptId
 *   tipo: int
 *   explicación: ID del concepto seleccionado.
 * - nombre: categoria
 *   tipo: string
 *   explicación: Nombre visible de la categoría/concepto.
 *
 * 3. Errores, advertencias o notas
 * - Las filas nuevas no tienen atributo data-id hasta que se guardan en la BD.
 */
function func02_addTransactionRow(tipo, detalle, conceptId, categoria) {
    const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
    const lista = panel.querySelector('.lista');

    const fila = document.createElement('div');
    fila.className = 'fila';

    const detalleInput = document.createElement('input');
    detalleInput.type = 'text';
    detalleInput.name = 'detalle[]';
    detalleInput.className = 'detalle';
    detalleInput.value = detalle || '';

    const montoInput = document.createElement('input');
    montoInput.type = 'number';
    montoInput.name = 'monto[]';
    montoInput.className = 'monto';
    montoInput.step = '0.01';
    montoInput.placeholder = '0.00';
    montoInput.required = true;
    montoInput.value = '';

    const categoriaSpan = document.createElement('span');
    categoriaSpan.className = 'categoria';
    categoriaSpan.textContent = categoria;

    const conceptoHidden = document.createElement('input');
    conceptoHidden.type = 'hidden';
    conceptoHidden.name = 'concepto_id[]';
    conceptoHidden.value = conceptId;

    const tipoHidden = document.createElement('input');
    tipoHidden.type = 'hidden';
    tipoHidden.name = 'tipo[]';
    tipoHidden.value = (tipo === 'ingreso') ? 'Ingreso' : 'Egreso';

    const borrarBtn = document.createElement('button');
    borrarBtn.type = 'button';
    borrarBtn.className = 'borrar';
    borrarBtn.textContent = '✖';

    fila.appendChild(categoriaSpan);
    fila.appendChild(detalleInput);
    fila.appendChild(montoInput);
    fila.appendChild(conceptoHidden);
    fila.appendChild(tipoHidden);
    fila.appendChild(borrarBtn);

    lista.appendChild(fila);
    montoInput.focus();
    func03_calcularTotales();
}

/*
 * func03_calcularTotales
 *
 * 1. Descripción
 * Recalcula y actualiza los totales de ingresos y egresos mostrados en pantalla.
 *
 * 2. Parámetros
 * - No requiere parámetros.
 *
 * 3. Errores, advertencias o notas
 * - Solo suma montos visibles en la interfaz.
 */
function func03_calcularTotales() {
    let totalIngresos = 0, totalEgresos = 0;

    document.querySelectorAll('.ingresos .fila .monto').forEach(input => {
        totalIngresos += parseFloat(input.value) || 0;
    });

    document.querySelectorAll('.egresos .fila .monto').forEach(input => {
        totalEgresos += parseFloat(input.value) || 0;
    });

    document.getElementById('totalIngresos').value = 'S/' + Number(totalIngresos).toFixed(2);
    document.getElementById('totalEgresos').value = 'S/' + Number(totalEgresos).toFixed(2);
}

/*
 * func04_refreshSummaries
 *
 * 1. Descripción
 * Solicita al servidor los resúmenes mensual y anual y actualiza los displays.
 *
 * 2. Parámetros
 * - No requiere parámetros; lee la fecha actual del datepicker en el DOM.
 *
 * 3. Errores, advertencias o notas
 * - Depende de la respuesta JSON del endpoint `guardar_transaccion.php?action=summary`.
 */
function func04_refreshSummaries() {
    const fecha = document.querySelector('input[type="date"]').value;
    fetch('guardar_transaccion.php?action=summary&fecha=' + encodeURIComponent(fecha))
        .then(r => r.json())
        .then(data => {
            const monthlyValue = Number(data.month_display);
            const annualValue = Number(data.year_sum);
            
            // Actualizar displays con formato correcto
            document.getElementById('monthlyDisplay').textContent = monthlyValue.toFixed(2);
            document.getElementById('annualDisplay').textContent = annualValue.toFixed(2);
            
            // Actualizar los displays en la parte superior (TOP)
            const monthlyDisplayTop = document.getElementById('monthlyDisplayTop');
            const annualDisplayTop = document.getElementById('annualDisplayTop');
            
            if (monthlyDisplayTop) {
                monthlyDisplayTop.textContent = 'S/' + monthlyValue.toFixed(2);
                // Cambiar color según si es positivo o negativo
                monthlyDisplayTop.className = monthlyValue < 0 ? 'value negativo' : 'value positivo';
            }
            
            if (annualDisplayTop) {
                annualDisplayTop.textContent = 'S/' + annualValue.toFixed(2);
                // Cambiar color según si es positivo o negativo
                annualDisplayTop.className = annualValue < 0 ? 'value negativo' : 'value positivo';
            }
        })
        .catch(err => console.error('No se pudo actualizar resumen:', err));
}

// ================================================================================
// INICIALIZADORES Y MANEJADORES DE EVENTOS (DOMContentLoaded)
// ================================================================================
/**
 * Se ejecuta cuando el DOM está completamente cargado.
 * Realiza inicializaciones y configura todos los manejadores de eventos para:
 *  - Dropdowns de selección de conceptos
 *  - Botones de agregar transacciones
 *  - Botones de eliminar transacciones
 *  - Botón de guardar transacciones
 */
document.addEventListener("DOMContentLoaded", () => {
    // ========== DROPDOWN MENU HANDLER ==========
    /**
     * Maneja la apertura/cierre del dropdown del menú de configuración.
     * Comportamiento:
     *  - Al pasar mouse: abre el dropdown (.dropdown-content)
     *  - Al quitar mouse: espera 400ms antes de cerrarlo (permite movimiento entre botón y menú)
     */
    const dropdown = document.querySelector(".dropdown");
    if (dropdown) {
        const content = dropdown.querySelector(".dropdown-content");
        let hideTimeout;

        dropdown.addEventListener("mouseenter", () => {
            clearTimeout(hideTimeout);
            content.style.display = "block";
        });

        dropdown.addEventListener("mouseleave", () => {
            hideTimeout = setTimeout(() => {
                content.style.display = "none";
            }, 400);
        });
    }

    // ========== CONFIGURACIÓN INICIAL DE INPUTS ==========
    /**
     * Configura los inputs de detalles para ingresos y egresos.
     * Inicializa la visibilidad y el comportamiento de los campos
     * cuando el usuario selecciona un concepto.
     */
    func01_toggleDetalleInput('selectIngreso', 'nuevoIngreso');
    func01_toggleDetalleInput('selectEgreso', 'nuevoEgreso');

    // ========== MANEJADOR: BOTÓN "AGREGAR INGRESO" ==========
    /**
     * Se dispara cuando el usuario hace clic en "Agregar" para un nuevo ingreso.
     * Valida que:
     *  - Se haya seleccionado un concepto (value != '')
     *  - Se haya ingresado una descripción (detalle no vacío)
     * Si es válido:
     *  1. Obtiene el texto del concepto desde las opciones del select
     *  2. Crea una nueva fila de transacción
     *  3. Limpia los inputs y resetea el dropdown
     */
    document.getElementById('btnAgregarIngreso').addEventListener('click', e => {
        e.preventDefault();
        const sel = document.getElementById('selectIngreso');
        const val = sel.value;
        const detalle = document.getElementById('nuevoIngreso').value.trim();

        if (!val || !detalle) return;

        const opt = sel.options[sel.selectedIndex];
        func02_addTransactionRow('ingreso', detalle, val, opt.text);

        document.getElementById('nuevoIngreso').value = '';
        document.getElementById('nuevoIngreso').style.display = 'none';
        sel.selectedIndex = 0;
    });

    // ========== MANEJADOR: BOTÓN "AGREGAR EGRESO" ==========
    /**
     * Se dispara cuando el usuario hace clic en "Agregar" para un nuevo egreso.
     * Funciona igual al manejador de ingresos, pero:
     *  - Obtiene datos del dropdown #selectEgreso
     *  - Obtiene la descripción del input #nuevoEgreso
     *  - Crea una fila con tipo 'egreso'
     */
    document.getElementById('btnAgregarEgreso').addEventListener('click', e => {
        e.preventDefault();
        const sel = document.getElementById('selectEgreso');
        const val = sel.value;
        const detalle = document.getElementById('nuevoEgreso').value.trim();

        if (!val || !detalle) return;

        const opt = sel.options[sel.selectedIndex];
        func02_addTransactionRow('egreso', detalle, val, opt.text);

        document.getElementById('nuevoEgreso').value = '';
        document.getElementById('nuevoEgreso').style.display = 'none';
        sel.selectedIndex = 0;
    });

    // ========== MANEJADOR: BOTÓN "ELIMINAR FILA" (✖) ==========
    /**
     * Se dispara cuando el usuario hace clic en el botón "✖" de cualquier fila.
     * 
     * Comportamiento según el tipo de fila:
     *  - Si la fila es NUEVA (sin data-id):
     *    - Simplemente la elimina del DOM
     *    - No hay solicitud al servidor
     *  
     *  - Si la fila es GUARDADA (tiene data-id):
     *    - Envía POST a guardar_transaccion.php con delete_id=X
     *    - Si el servidor responde "ok", elimina la fila del DOM
     *    - Recalcula totales y actualiza resúmenes
     * 
     * En ambos casos:
     *  - Recalcula los totales mostrados en pantalla
     *  - Si era guardada, actualiza los resúmenes mensuales/anuales
     */
    document.addEventListener('click', async (e) => {
        if (!e.target.matches('.borrar')) return;
        const fila = e.target.closest('.fila');
        if (!fila) return;

        // Confirmación del usuario antes de borrar
        const confirmMsg = '¿Está seguro que desea eliminar esta transacción? Esta acción no se puede deshacer.';
        if (typeof showConfirm === 'function') {
            const ok = await showConfirm(confirmMsg, 'Confirmar eliminación');
            if (!ok) return;
        } else {
            if (!confirm(confirmMsg)) return;
        }

        const transId = fila.getAttribute('data-id');
        if (transId) {
            fetch('guardar_transaccion.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: new URLSearchParams({ delete_id: transId })
            })
            .then(r => r.text())
            .then(async txt => {
                if (txt.trim() === 'ok') {
                    fila.remove();
                    func03_calcularTotales();
                    func04_refreshSummaries();
                } else {
                    if (typeof showAlert === 'function') await showAlert('No se pudo eliminar la transacción: ' + txt, 'Error'); else alert('No se pudo eliminar la transacción: ' + txt);
                }
            })
            .catch(async err => { if (typeof showAlert === 'function') await showAlert('Error en la petición de eliminación: ' + err, 'Error'); else alert('Error en la petición de eliminación: ' + err); });
        } else {
            // Fila nueva (no persistida) — simplemente eliminar del DOM
            fila.remove();
            func03_calcularTotales();
        }
    });

    // ========== MANEJADOR: BOTÓN "GUARDAR TRANSACCIONES" ==========
    /**
     * Se dispara cuando el usuario hace clic en "Guardar".
     * 
     * Proceso:
     *  1. Itera sobre todas las filas en pantalla
     *  2. Filtra las filas NUEVAS (sin data-id)
     *  3. Para cada fila nueva, recopila:
     *     - concepto_id: ID del concepto (hidden input)
     *     - tipo: "Ingreso" o "Egreso" (hidden input)
     *     - detalle: Descripción ingresada
     *     - monto: Cantidad en números
     *  4. Valida que tenga concepto e monto válidos
     *  5. Construye un FormData con todos los datos
     *  6. Agrega la fecha actual del datepicker
     *  7. Envía POST a guardar_transaccion.php
     * 
     * Respuesta del servidor:
     *  - Si respuesta es "ok": muestra alerta de éxito y recarga la página
     *    (esto mostrará las transacciones guardadas con data-id y id de BD)
     *  - Si error: muestra el mensaje de error devuelto por el servidor
     * 
     * Validación:
     *  - Si no hay transacciones nuevas para guardar, muestra alerta
     *  - No recarga si hay error (permite reintentar)
     */
    document.querySelector('.guardar').addEventListener('click', async () => {
        const formData = new FormData();
        const fecha = document.querySelector('input[type="date"]').value;

        let newCount = 0;
        let updateCount = 0;

        // Recolectar filas nuevas (sin data-id)
        document.querySelectorAll('.fila').forEach(fila => {
            const existingId = fila.getAttribute('data-id');
            if (existingId) return;

            const concepto = fila.querySelector('input[name="concepto_id[]"]')?.value || '';
            const tipo = fila.querySelector('input[name="tipo[]"]')?.value || '';
            const detalle = fila.querySelector('input[name="detalle[]"]')?.value || '';
            const monto = fila.querySelector('input[name="monto[]"]')?.value || '';

            if (concepto && monto !== '') {
                formData.append('concepto_id[]', concepto);
                formData.append('tipo[]', tipo);
                formData.append('detalle[]', detalle);
                formData.append('monto[]', monto);
                newCount++;
            }
        });

        // Recolectar filas existentes editadas (con data-id)
        document.querySelectorAll('.fila[data-id]').forEach(fila => {
            const id = fila.getAttribute('data-id');
            const detalle = fila.querySelector('input[name="detalle[]"]')?.value || '';
            const monto = fila.querySelector('input[name="monto[]"]')?.value || '';
            const tipo = fila.querySelector('input[name="tipo[]"]')?.value || '';

            // Si no hay cambios detectables (puedes mejorar con comparación), aún permitimos enviar
            if (id && (monto !== '' || detalle !== '')) {
                formData.append('update_id[]', id);
                formData.append('update_detalle[]', detalle);
                formData.append('update_monto[]', monto);
                formData.append('update_tipo[]', tipo);
                updateCount++;
            }
        });

        if (newCount === 0 && updateCount === 0) {
            if (typeof showAlert === 'function') await showAlert('No hay cambios para guardar.', 'Aviso'); else alert('No hay cambios para guardar.');
            return;
        }

        formData.append('fecha', fecha);

        fetch('guardar_transaccion.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(async result => {
            if (result.trim().startsWith('ok')) {
                if (typeof showAlert === 'function') await showAlert('Cambios guardados correctamente', 'Éxito'); else alert('Cambios guardados correctamente');
                location.reload();
            } else {
                if (typeof showAlert === 'function') await showAlert('Error al guardar los cambios: ' + result, 'Error'); else alert('Error al guardar los cambios: ' + result);
            }
        })
        .catch(async err => { if (typeof showAlert === 'function') await showAlert('Error en la petición: ' + err, 'Error'); else alert('Error en la petición: ' + err); });
    });

    func03_calcularTotales();
});


/**
 * cerrarRecordatorio(idRecordatorio)
 * 
 * Elimina un recordatorio específico de la interfaz mediante AJAX.
 * Cuando el usuario hace clic en la "X" de un recordatorio, esta función
 *                                                                                                                                                                               envía una solicitud al servidor para marcar el recordatorio como cerrado
 * y lo remueve visualmente de la lista.
 * 
 * Parámetros:
 *  - idRecordatorio (int): ID único del recordatorio en la base de datos
 * 
 * Proceso:
 *  1. Envía una solicitud POST a cerrar_recordatorio.php con el ID
 *  2. Si la operación es exitosa, remueve el elemento del DOM
 *  3. Si hay error, muestra un mensaje de alerta
 * 
 * NOTA: Esta función proporciona una experiencia de usuario fluida al
 *       permitir cerrar recordatorios sin recargar la página completa.
 */
/**
 * func05_cerrarRecordatorio
 *
 * 1. Descripción
 * Cierra (marca como resuelto) un recordatorio mediante petición AJAX y lo remueve del DOM.
 *
 * 2. Parámetros
 * - nombre: idRecordatorio
 *   tipo: int
 *   explicación: ID del recordatorio en la base de datos.
 *
 * 3. Errores, advertencias o notas
 * - Usa `showConfirm` y `showAlert` si están disponibles para mejorar la experiencia.
 */
async function func05_cerrarRecordatorio(idRecordatorio) {
    const recordatorioElement = document.querySelector(`.recordatorio-alerta[data-id="${idRecordatorio}"]`);
    
    if (!recordatorioElement) return;
    
    // Confirmación antes de cerrar el recordatorio
    const confirmMsg = '¿Está seguro que desea cerrar este recordatorio?';
    if (typeof showConfirm === 'function') {
        const ok = await showConfirm(confirmMsg, 'Confirmar cierre');
        if (!ok) return;
    } else {
        if (!confirm(confirmMsg)) return;
    }
    // Crear formulario para enviar la solicitud
    const formData = new FormData();
    formData.append('id_recordatorio', idRecordatorio);
    
    fetch('cerrar_recordatorio.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
            if (data.success) {
            // Remover el recordatorio de la interfaz
            recordatorioElement.remove();
            
            // Si no quedan recordatorios, mostrar mensaje
            const listaRecordatorios = document.getElementById('lista-recordatorios');
            if (listaRecordatorios.querySelectorAll('.recordatorio-alerta').length === 0) {
                listaRecordatorios.innerHTML = '<p style="color:#666;text-align:center;">No hay recordatorios para hoy.</p>';
            }
        } else {
            if (typeof showAlert === 'function') showAlert('Error al cerrar el recordatorio: ' + data.message, 'Error'); else alert('Error al cerrar el recordatorio: ' + data.message);
        }
    })
        .catch(error => {
        console.error('Error:', error);
        if (typeof showAlert === 'function') showAlert('Error de conexión al cerrar el recordatorio', 'Error'); else alert('Error de conexión al cerrar el recordatorio');
    });
}