/**
 * gestionar_perfiles.js
 * ================================================================================
 * LÓGICA DE INTERFAZ DE USUARIO PARA LA PÁGINA DE GESTIONAR PERFILES
 * (gestionar_perfiles.php)
 * 
 * Este archivo contiene funciones para:
 *  1. Validar contraseña al crear un nuevo perfil
 *  2. Manejar el dropdown del menú de configuración
 *  3. Control de cambio de roles (admin/miembro)
 *  4. Control de activación/desactivación de perfiles
 */

/**
 * func01_validarCrear
 *
 * 1. Descripción
 * Valida los campos de contraseña antes de crear un nuevo perfil.
 * Se ejecuta con onsubmit="return func01_validarCrear()" en el formulario de creación.
 *
 * 2. Parámetros
 * - No requiere parámetros; lee del DOM:
 *   - #contrasena: Input[type="password"] de la primera contraseña.
 *   - #confirmacionContrasena: Input[type="password"] de confirmación.
 *
 * 3. Errores, advertencias o notas
 * - Valida que contraseña y confirmación sean idénticas.
 * - Valida que la contraseña tenga mínimo 6 caracteres.
 * - Retorna false si hay error (previene envío del formulario).
 * - Retorna true si es válido (permite envío del formulario).
 */
function func01_validarCrear() {
    const a = document.getElementById('contrasena').value;
    const b = document.getElementById('confirmacionContrasena').value;
    if (a !== b) {
        alert('La contraseña y su confirmación no coinciden.');
        return false;
    }
    if (a.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres.');
        return false;
    }
    return true;
}

// Dropdown menu handler
document.addEventListener("DOMContentLoaded", () => {
    const dropdown = document.querySelector(".dropdown");
    if (dropdown) {
        const content = dropdown.querySelector(".dropdown-content");
        let hideTimeout;

        dropdown.addEventListener("mouseenter", () => {
            clearTimeout(hideTimeout);
            content.style.display = "block";
        });

        dropdown.addEventListener("mouseleave", () => {
            hideTimeout = setTimeout(() => {
                content.style.display = "none";
            }, 1500);
        });
    }
});
