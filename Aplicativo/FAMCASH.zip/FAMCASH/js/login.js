/**
 * login.js
 * --------
 * Funciones de inicio de sesión para login.php.
 * Diccionario UI-03: iniciarSesion, redirigirAInterfazDentroDeCuenta, ingresarARegistro, mostrarMensaje
 */


/**
 * func01_iniciarSesion
 *
 * 1. Descripción
 * Valida que los campos de nombre y contraseña estén completos antes de enviar el formulario de login.
 *
 * 2. Parámetros
 * - No recibe parámetros (toma los valores del DOM).
 *
 * 3. Errores, advertencias o notas
 * - Muestra mensaje si algún campo está vacío y retorna false.
 */
function func01_iniciarSesion() {
    const nombre = document.querySelector('[name="nombre"]').value.trim();
    const contrasena = document.querySelector('[name="contrasena"]').value.trim();
    if (!nombre || !contrasena) {
        func04_mostrarMensaje(false, "Por favor, complete todos los campos.");
        return false;
    }
    return true;
}


/**
 * func02_redirigirAInterfazDentroDeCuenta
 *
 * 1. Descripción
 * Redirige al usuario a la interfaz interna de la cuenta según el ID recibido.
 *
 * 2. Parámetros
 * - nombre: idInterfaz
 *   tipo: number
 *   explicación: ID de la interfaz destino (4 para selección de perfil).
 *
 * 3. Errores, advertencias o notas
 * - Si el ID no es 4, muestra mensaje de advertencia.
 */
function func02_redirigirAInterfazDentroDeCuenta(idInterfaz) {
    if (idInterfaz === 4) {
        window.location.href = "seleccionperfil.php";
    } else {
        func04_mostrarMensaje(false, "No se pudo determinar la interfaz destino.");
    }
}


/**
 * func03_ingresarARegistro
 *
 * 1. Descripción
 * Redirige al usuario a la página de registro si el ID es correcto.
 *
 * 2. Parámetros
 * - nombre: idInterfazRegistro
 *   tipo: number
 *   explicación: ID de la interfaz de registro (2).
 *
 * 3. Errores, advertencias o notas
 * - Si el ID no es 2, muestra mensaje de advertencia.
 */
function func03_ingresarARegistro(idInterfazRegistro) {
    if (idInterfazRegistro === 2) {
        window.location.href = "registro.php";
    } else {
        func04_mostrarMensaje(false, "No se pudo redirigir a la interfaz de registro.");
    }
}


/**
 * func04_mostrarMensaje
 *
 * 1. Descripción
 * Muestra un mensaje de alerta con un icono según el comprobante.
 *
 * 2. Parámetros
 * - nombre: comprobante
 *   tipo: boolean
 *   explicación: Si es true, muestra icono de éxito; si es false, de advertencia.
 * - nombre: mensaje
 *   tipo: string
 *   explicación: Mensaje a mostrar en la alerta.
 *
 * 3. Errores, advertencias o notas
 * - Utiliza alert() del navegador.
 */
function func04_mostrarMensaje(comprobante, mensaje) {
    alert((comprobante ? "✅ " : "⚠️ ") + mensaje);
}
