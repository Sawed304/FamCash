/*
 * balance.js
 * ===============================================================================
 * Este archivo contiene funciones para:
 *  1. Mostrar balances por concepto y período
 *  2. Filtrar transacciones por perfil y fecha
 *  3. Calcular y mostrar resúmenes mensuales y anuales
 *  4. Manejar el color indicador del perfil seleccionado
 *  5. Gestionar el dropdown del menú de configuración
 *  6. Actualizar automáticamente la vista al cambiar filtros
 */

/*
 * VARIABLES DE ESTADO GLOBAL
 * Almacenan información del perfil actual para usar en funciones sin parámetros
 */
let perfilColors = {};           // Mapeo: idPerfil -> colorHex (ej: {1: '#4363d8', 2: '#e6194b'})
let perfilesList = [];           // Lista de perfiles disponibles para el usuario
let sessionPerfilId = 0;         // ID del perfil autenticado en la sesión actual
let selectedPerfilInitial = 0;   // ID del perfil seleccionado al cargar la página
let fechaInicial = "";           // Fecha inicial mostrada en el filtro

/**
 * func01_mostrarBalance
 *
 * 1. Descripción
 * Navega a balance.php con los parámetros de filtro especificados.
 * Usa URL parameters para mantener estado entre recargas.
 *
 * 2. Parámetros
 * - nombre: fecha
 *   tipo: string
 *   explicación: Fecha en formato YYYY-MM-DD para filtrar transacciones.
 * - nombre: idPerfil
 *   tipo: int
 *   explicación: ID del perfil a mostrar (0 = todos).
 * - nombre: idUsuario
 *   tipo: int
 *   explicación: ID del usuario (compatibilidad).
 *
 * 3. Errores, advertencias o notas
 * - La función codifica la fecha para evitar problemas con caracteres especiales.
 * - Redirige a balance.php?perfil=X&fecha=Y.
 */
function func01_mostrarBalance(fecha, idPerfil, idUsuario) {
    const f = encodeURIComponent(fecha);
    const p = (typeof idPerfil === 'undefined' || idPerfil === null) ? 0 : idPerfil;
    location.href = 'balance.php?perfil=' + p + '&fecha=' + f;
}

/**
 * func02_actualizarVista
 *
 * 1. Descripción
 * Se ejecuta automáticamente cuando el usuario cambia el perfil seleccionado o la fecha.
 * Construye una nueva URL con los parámetros de filtro y redirige a ella.
 *
 * 2. Parámetros
 * - No requiere parámetros. Obtiene los valores del DOM:
 *   - Selector de perfil (#perfil)
 *   - Input de fecha (#fechaFiltro)
 *
 * 3. Errores, advertencias o notas
 * - Siempre incluye el parámetro perfil, incluso cuando es 0 para "Todos".
 * - Se llama desde eventos 'change' del selector de perfil e input de fecha.
 */
function func02_actualizarVista() {
    const perfilSelect = document.getElementById('perfil');
    const fechaInput = document.getElementById('fechaFiltro');
    
    if (perfilSelect && fechaInput) {
        const perfil = perfilSelect.value;
        const fecha = fechaInput.value;
        
        // CORRECCIÓN: Siempre incluir el parámetro perfil, incluso cuando es 0
        const url = `balance.php?perfil=${perfil}&fecha=${fecha}`;
        
        // Redirigir a la nueva URL
        window.location.href = url;
    }
}

/**
 * func03_presionarCambiarFecha
 *
 * 1. Descripción
 * Manejador del evento cuando el usuario cambia el filtro de fecha.
 * Valida que se haya seleccionado una fecha antes de actualizar.
 *
 * 2. Parámetros
 * - nombre: accionRealizada
 *   tipo: bool
 *   explicación: Flag para indicar si fue por evento onchange.
 *
 * 3. Errores, advertencias o notas
 * - Obtiene el valor del input de fecha (#fechaFiltro).
 * - Si está vacío, muestra una alerta.
 * - Si no, obtiene el perfil seleccionado y llama a seleccionarNuevaFecha().
 */
function func03_presionarCambiarFecha(accionRealizada) {
    const nueva = document.getElementById('fechaFiltro').value;
    if (!nueva) {
        alert('Seleccione una fecha válida');
        return;
    }
    const perfilEl = document.getElementById('perfil');
    const perfilVal = perfilEl ? perfilEl.value : sessionPerfilId;
    func04_seleccionarNuevaFecha(nueva, perfilVal, sessionPerfilId);
}

/**
 * func04_seleccionarNuevaFecha
 *
 * 1. Descripción
 * Wrapper que llama a func01_mostrarBalance con los parámetros especificados.
 * Se usa cuando el usuario cambia la fecha en el filtro.
 *
 * 2. Parámetros
 * - nombre: nuevaFecha
 *   tipo: string
 *   explicación: Fecha en formato YYYY-MM-DD seleccionada por el usuario.
 * - nombre: idPerfil
 *   tipo: int
 *   explicación: ID del perfil actual.
 * - nombre: idUsuario
 *   tipo: int
 *   explicación: ID del usuario de la sesión.
 *
 * 3. Errores, advertencias o notas
 * - Función auxiliar que delega toda la lógica a func01_mostrarBalance.
 */
function func04_seleccionarNuevaFecha(nuevaFecha, idPerfil, idUsuario) {
    func01_mostrarBalance(nuevaFecha, idPerfil, idUsuario);
}

/**
 * func05_mostrarBalanceGeneral
 *
 * 1. Descripción
 * Muestra el balance de TODOS los perfiles (no filtrado por perfil individual).
 * Equivale a llamar func01_mostrarBalance con idPerfil = 0.
 *
 * 2. Parámetros
 * - nombre: fecha
 *   tipo: string
 *   explicación: Fecha en formato YYYY-MM-DD para filtrar transacciones.
 * - nombre: idPerfil
 *   tipo: int
 *   explicación: ID del perfil (será reemplazado por 0 para mostrar todos).
 * - nombre: idUsuario
 *   tipo: int
 *   explicación: ID del usuario de la sesión.
 *
 * 3. Errores, advertencias o notas
 * - Se usa cuando el usuario hace clic en "Ver general".
 */
function func05_mostrarBalanceGeneral(fecha, idPerfil, idUsuario) {
    func01_mostrarBalance(fecha, 0, idUsuario);
}

/**
 * func06_seleccionarBotón
 *
 * 1. Descripción
 * Maneja clics en botones de acción en la interfaz.
 * Se puede extender para agregar más acciones (exportar, descargar, etc).
 *
 * 2. Parámetros
 * - nombre: opcion
 *   tipo: int
 *   explicación: Número que identifica qué botón fue clickeado.
 *                1 = Actualizar balance, 2 = Exportar, 3 = Abrir detalle.
 *
 * 3. Errores, advertencias o notas
 * - Las opciones 2 y 3 muestran alertas indicando que no están implementadas.
 * - Valida el valor de opcion y registra en consola si es desconocido.
 */
function func06_seleccionarBotón(opcion) {
    switch(opcion) {
        case 1:
            func01_mostrarBalance(document.getElementById('fechaFiltro').value, document.getElementById('perfil').value, sessionPerfilId);
            break;
        case 2:
            alert('Función exportar no implementada en esta vista (por ahora).');
            break;
        case 3:
            alert('Abrir detalle (no implementado).');
            break;
        default:
            console.log('Botón desconocido', opcion);
    }
}

/**
 * func07_seleccionarPerfilEspecífico
 *
 * 1. Descripción
 * Se dispara cuando el usuario selecciona un perfil diferente desde el dropdown.
 * Actualiza el indicador visual del perfil y navega a balance.php con el nuevo filtro.
 *
 * 2. Parámetros
 * - nombre: perfilId
 *   tipo: int|string
 *   explicación: ID del perfil seleccionado.
 * - nombre: fecha
 *   tipo: string
 *   explicación: Fecha actual (por defecto, la del filtro #fechaFiltro).
 * - nombre: idUsuario
 *   tipo: int
 *   explicación: ID del usuario de la sesión.
 *
 * 3. Errores, advertencias o notas
 * - Convierte perfilId a entero con parseInt(perfilId, 10).
 * - Si no se proporciona fecha, intenta obtenerla del DOM.
 */
function func07_seleccionarPerfilEspecífico(perfilId, fecha, idUsuario) {
    const fechaAct = fecha || document.getElementById('fechaFiltro').value || fechaInicial;
    const pid = parseInt(perfilId, 10);
    func09_actualizarIndicadorPerfil(pid);
    func01_mostrarBalance(fechaAct, pid, idUsuario || sessionPerfilId);
}

/**
 * func08_cargarInformación
 *
 * 1. Descripción
 * Función auxiliar para futuros análisis de transacciones.
 * Actualmente, solo registra en consola para debugging.
 *
 * 2. Parámetros
 * - nombre: colecciónTransacciones
 *   tipo: array
 *   explicación: Lista de transacciones a procesar.
 *
 * 3. Errores, advertencias o notas
 * - Función en fase de desarrollo, no realiza procesamiento real aún.
 * - Útil para debugging y análisis futuro de datos de transacciones.
 */
function func08_cargarInformación(colecciónTransacciones) {
    console.log('cargarInformación llamado con:', colecciónTransacciones);
}

/**
 * func09_actualizarIndicadorPerfil
 *
 * 1. Descripción
 * Cambia el color del indicador visual (#perfilIndicator) al color asignado
 * del perfil especificado.
 *
 * 2. Parámetros
 * - nombre: pid
 *   tipo: int
 *   explicación: ID del perfil cuyo color se desea aplicar.
 *
 * 3. Errores, advertencias o notas
 * - Busca el color en la variable global perfilColors.
 * - Si no existe el color, usa gris por defecto (#999).
 * - Aplica el color al elemento indicador (#perfilIndicator).
 */
function func09_actualizarIndicadorPerfil(pid) {
    const el = document.getElementById('perfilIndicator');
    if (!el) return;
    const color = perfilColors[pid] || '#999';
    el.style.background = color;
    el.title = 'Color del perfil seleccionado';
}

// ================================================================================
// DROPDOWN MENU HANDLER (Menú de Configuración)
// ================================================================================
/**
 * Maneja la apertura y cierre del dropdown del menú Configuración.
 * 
 * COMPORTAMIENTO:
 *  - Al pasar mouse sobre el botón o el dropdown: abre el menú
 *  - Al quitar mouse: espera 1.5s antes de cerrar (permite pasar al dropdown)
 *  - Al hacer clic en el botón: alterna estado de "abierto permanente"
 *  - Mientras el dropdown está abierto, el menú permanece visible (clase .open)
 * 
 * VARIABLES LOCALES:
 *  - dropdown: Elemento contenedor del dropdown (.dropdown)
 *  - content: Elemento contenedor de enlaces (.dropdown-content)
 *  - btn: Botón "Configuración" (.menu-btn)
 *  - hideTimeout: Temporizador para cerrar el dropdown con retraso
 *  - keepOpen: Bandera para mantener el dropdown abierto al hacer clic
*/
/**
 * func10_initBalanceHandlers
 *
 * 1. Descripción
 * Inicializa todos los manejadores de eventos y comportamientos de la página de balance.
 * Configura el dropdown de configuración, actualización automática de filtros,
 * manejo de la leyenda colapsable, y carga de datos desde PHP.
 *
 * 2. Parámetros
 * - No requiere parámetros.
 *
 * 3. Errores, advertencias o notas
 * - Debe ejecutarse después de que el DOM esté completamente cargado.
 * - Configura múltiples comportamientos: dropdown, filtros, leyenda, colores de balance.
 * - Se ejecuta automáticamente al cargar el script si el DOM está listo.
 */
function initBalanceHandlers() {
    const dropdown = document.querySelector(".dropdown");
    if (dropdown) {
        const content = dropdown.querySelector(".dropdown-content");
        const btn = dropdown.querySelector('.menu-btn');
        let hideTimeout;              // ID del setTimeout para poder cancelarlo
        let keepOpen = false;          // Bandera: si true, el dropdown se mantiene abierto

    /**
     * func10_1_showContent
     *
     * 1. Descripción
     * Muestra el dropdown añadiendo clase 'open' y asignando display: block.
     * Cancela cualquier cierre pendiente.
     *
     * 2. Parámetros
     * - No requiere parámetros.
     *
     * 3. Errores, advertencias o notas
     * - Función interna dentro de func10_initBalanceHandlers.
     * - Maneja la visibilidad del menú de configuración.
     */
        function showContent() {
            clearTimeout(hideTimeout);
            if (content) content.style.display = 'block';
            dropdown.classList.add('open');
        }

        /**
         * func10_2_scheduleHide
         *
         * 1. Descripción
         * Si keepOpen es true, no hace nada (menú está "fijado").
         * Permite al usuario mover el mouse del botón al dropdown sin que se cierre.
         *
         * 2. Parámetros
         * - No requiere parámetros.
         *
         * 3. Errores, advertencias o notas
         * - Función interna dentro de func10_initBalanceHandlers.
         * - Espera 1500ms antes de cerrar el dropdown.
         */
        function scheduleHide() {
            if (keepOpen) return;
            // Esperar 1500ms antes de cerrar para permitir mover el mouse al contenido
            hideTimeout = setTimeout(() => {
                if (content) content.style.display = 'none';
                dropdown.classList.remove('open');
            }, 1500);
        }

        // Manejadores de mouse en el contenedor dropdown
        if (btn) {
            btn.addEventListener('mouseenter', () => { showContent(); });
            btn.addEventListener('mouseleave', () => { scheduleHide(); });
        }

        dropdown.addEventListener("mouseenter", () => { showContent(); });
        dropdown.addEventListener("mouseleave", () => { scheduleHide(); });

        // Manejadores de mouse en el contenido del dropdown
        // Impide que se cierre cuando el mouse entra en los links
        if (content) {
            content.addEventListener('mouseenter', () => { clearTimeout(hideTimeout); dropdown.classList.add('open'); });
            content.addEventListener('mouseleave', () => { scheduleHide(); });
        }

        // Manejador de clic en el botón: alterna estado "abierto permanente"
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                keepOpen = !keepOpen;
                if (keepOpen) showContent(); else scheduleHide();
            });
        }
    }

    // Actualizar el indicador de color cuando la página carga
    func09_actualizarIndicadorPerfil(selectedPerfilInitial);

    // ============================================================================
    // MANEJADORES PARA ACTUALIZACIÓN AUTOMÁTICA DE FILTROS
    // ============================================================================

    // Manejador para el dropdown de selección de perfil - ACTUALIZACIÓN AUTOMÁTICA
    const sel = document.getElementById('perfil');
    if (sel) {
        sel.addEventListener('change', (e) => {
            const pid = parseInt(e.target.value, 10);
            func09_actualizarIndicadorPerfil(pid);
            // Llamar a func02_actualizarVista para redirigir automáticamente
            func02_actualizarVista();
        });
    }

    // Manejador para el campo de fecha - ACTUALIZACIÓN AUTOMÁTICA
    const fechaInput = document.getElementById('fechaFiltro');
    if (fechaInput) {
        fechaInput.addEventListener('change', () => {
            // Obtener valores actuales
            const perfilSelect = document.getElementById('perfil');
            const perfil = perfilSelect ? perfilSelect.value : '0';
            const fecha = fechaInput.value;
            
            // CORRECCIÓN: Usar URL directa que siempre incluya el parámetro perfil
            const url = `balance.php?perfil=${perfil}&fecha=${fecha}`;
            window.location.href = url;
        });

        // Manejador para Enter en el campo de fecha (compatibilidad)
        fechaInput.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') {
                const perfilSelect = document.getElementById('perfil');
                const perfil = perfilSelect ? perfilSelect.value : '0';
                const fecha = fechaInput.value;
                const url = `balance.php?perfil=${perfil}&fecha=${fecha}`;
                window.location.href = url;
            }
        });
    }

    // ============================================================================
    // MANEJO DE LEYENDA COLAPSABLE
    // ============================================================================
    
    const leyendaHeader = document.getElementById('leyendaHeader');
    const leyendaList = document.getElementById('leyendaList');
    
    if (leyendaHeader && leyendaList) {
        // Inicializar usando aria-expanded si existe, por accesibilidad
        const aria = leyendaHeader.getAttribute('aria-expanded');
        let isCollapsed = (aria === 'false');

        // Función auxiliar para aplicar estado visual (usa estilos inline para evitar conflictos)
        const applyLeyendaState = (collapsed) => {
            if (collapsed) {
                leyendaList.style.maxHeight = '0px';
                leyendaList.style.opacity = '0';
                leyendaList.style.marginTop = '0';
                leyendaList.style.pointerEvents = 'none';
                leyendaHeader.setAttribute('aria-expanded', 'false');
                leyendaHeader.innerHTML = '<strong>▶ Perfiles (' + (leyendaList.querySelectorAll('.leyenda-item').length) + ')</strong>';
            } else {
                // Expandir: medir el scrollHeight real para animar correctamente
                const sh = leyendaList.scrollHeight || (leyendaList.children.length * 26);
                leyendaList.style.maxHeight = sh + 'px';
                leyendaList.style.opacity = '1';
                leyendaList.style.marginTop = '8px';
                leyendaList.style.pointerEvents = 'auto';
                leyendaHeader.setAttribute('aria-expanded', 'true');
                leyendaHeader.innerHTML = '<strong>▼ Perfiles (' + (leyendaList.querySelectorAll('.leyenda-item').length) + ')</strong>';
            }
        };

        // Aplicar estado inicial (si la cabecera indica expandido, mostrarlo)
        applyLeyendaState(!isCollapsed);

        // Evento: clic en la cabecera para toggle
        leyendaHeader.addEventListener('click', function(e) {
            console.log('leyendaHeader click (handler)');
            e.preventDefault();
            e.stopPropagation();
            isCollapsed = !isCollapsed;
            applyLeyendaState(isCollapsed);
        });

        // Exponer una función global como fallback para clicks inline
        window.toggleLeyenda = function() {
            try {
                console.log('toggleLeyenda invoked (global)');
                const hdr = document.getElementById('leyendaHeader');
                const lst = document.getElementById('leyendaList');
                if (!hdr || !lst) return;
                const aria = hdr.getAttribute('aria-expanded');
                const collapsedNow = (aria === 'false');
                // Si collapsedNow === true, aria says collapsed, so we should expand
                if (collapsedNow) {
                    const sh = lst.scrollHeight || (lst.children.length * 26);
                    lst.style.maxHeight = sh + 'px';
                    lst.style.opacity = '1';
                    lst.style.marginTop = '8px';
                    lst.style.pointerEvents = 'auto';
                    hdr.setAttribute('aria-expanded', 'true');
                    hdr.innerHTML = '<strong>▼ Perfiles (' + (lst.querySelectorAll('.leyenda-item').length) + ')</strong>';
                } else {
                    lst.style.maxHeight = '0px';
                    lst.style.opacity = '0';
                    lst.style.marginTop = '0';
                    lst.style.pointerEvents = 'none';
                    hdr.setAttribute('aria-expanded', 'false');
                    hdr.innerHTML = '<strong>▶ Perfiles (' + (lst.querySelectorAll('.leyenda-item').length) + ')</strong>';
                }
            } catch (err) {
                console.error('toggleLeyenda error', err);
            }
        };
    }

    // Listener de captura en document: detecta clicks incluso si otros elementos detienen
    // la propagación o hay overlays. Usamos capture=true para que se ejecute en la fase
    // de captura (antes que listeners que podrían bloquear el evento).
    document.addEventListener('click', function(evt) {
        try {
            const hdr = document.getElementById('leyendaHeader');
            if (!hdr) return;
            // Si el click ocurrió sobre la cabecera (o un hijo), invocar el toggle
            if (evt.target && evt.target.closest && evt.target.closest('#leyendaHeader')) {
                console.log('document capture: leyendaHeader click detected');
                // marcar visualmente para confirmar
                hdr.style.outline = '2px solid rgba(67,99,216,0.6)';
                setTimeout(() => { hdr.style.outline = ''; }, 400);
                // Llamar al toggle global si existe
                if (typeof window.toggleLeyenda === 'function') {
                    window.toggleLeyenda();
                }
                // Evitar que otros manejadores hagan cosas inesperadas
                evt.preventDefault();
                evt.stopPropagation();
            }
        } catch (err) {
            console.error('capture listener error', err);
        }
    }, true);
    
    // ============================================================================
    // INICIALIZACIÓN DE DATOS DESDE PHP
    // ============================================================================
    
    // Si hay datos pasados desde PHP, inicializar las variables globales
    if (typeof balanceData !== 'undefined') {
        perfilColors = balanceData.perfilColors || {};
        perfilesList = balanceData.perfilesList || [];
        sessionPerfilId = balanceData.sessionPerfilId || 0;
        selectedPerfilInitial = balanceData.selectedPerfilInitial || 0;
        fechaInicial = balanceData.fechaInicial || "";
        
        // Actualizar indicador con los datos cargados
        func09_actualizarIndicadorPerfil(selectedPerfilInitial);
        
        // Actualizar colores de los valores del balance (positivo/negativo)
        func10_3_actualizarColoresBalance();
    }
    
    /**
     * func10_3_actualizarColoresBalance
     *
     * 1. Descripción
     * Aplica clases de color a los elementos del balance según si son positivos o negativos.
     * Actualiza visualmente los valores de balance mensual y anual.
     *
     * 2. Parámetros
     * - No requiere parámetros.
     *
     * 3. Errores, advertencias o notas
     * - Función interna dentro de func10_initBalanceHandlers.
     * - Lee los valores del DOM y aplica clases CSS según el signo (positivo/negativo).
     */
    function func10_3_actualizarColoresBalance() {
        const monthlyValue = document.querySelector('.top-summary .box:nth-child(1) .value');
        const annualValue = document.querySelector('.top-summary .box:nth-child(2) .value');
        
        if (monthlyValue) {
            const texto = monthlyValue.textContent;
            const valor = parseFloat(texto.replace('S/', ''));
            monthlyValue.className = valor < 0 ? 'value negativo' : 'value positivo';
        }
        
        if (annualValue) {
            const texto = annualValue.textContent;
            const valor = parseFloat(texto.replace('S/', ''));
            annualValue.className = valor < 0 ? 'value negativo' : 'value positivo';
        }
    }
}

// Ejecutar la inicialización inmediatamente si el documento ya está listo;
// en caso contrario, esperar a DOMContentLoaded.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBalanceHandlers);
} else {
    initBalanceHandlers();
}