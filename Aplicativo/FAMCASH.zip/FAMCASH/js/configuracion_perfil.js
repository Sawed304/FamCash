/**
 * configuracion_perfil.js
 * ----------------------
 * Funciones para configuracion_perfil.php: cambio de alias y contraseña.
 * Diccionario UI-09: func01_seleccionarBoton, func02_redirigirAInterfaz,
 * func03_mostrarMensaje, func04_validarFormulario
 * */

/**
 * func01_seleccionarBoton
 *
 * 1. Descripción
 * Maneja la acción de botones en la interfaz de configuración de perfil.
 *
 * 2. Parámetros
 * - nombre: idOpcion
 *   tipo: int
 *   explicación: Identificador de la opción seleccionada (1,2,...).
 *
 * 3. Errores, advertencias o notas
 * - Para idOpcion === 2 redirige a la interfaz 5 mediante func02_redirigirAInterfaz.
 * - Para idOpcion === 1 no realiza acción (el formulario hará submit).
 */
function func01_seleccionarBoton(idOpcion) {
    if (idOpcion === 2) {
        func02_redirigirAInterfaz(5);
    } else if (idOpcion === 1) {
        // El formulario manejará el submit
    }
}

/**
 * func02_redirigirAInterfaz
 *
 * 1. Descripción
 * Redirige a distintas interfaces según el id proporcionado.
 *
 * 2. Parámetros
 * - nombre: idInterfaz
 *   tipo: int
 *   explicación: ID de la interfaz destino.
 *
 * 3. Errores, advertencias o notas
 * - Si el id no coincide, muestra mensaje de error con func03_mostrarMensaje.
 */
function func02_redirigirAInterfaz(idInterfaz) {
    if (idInterfaz === 5) {
        window.location.href = 'entrada_diaria.php';
    } else {
        func03_mostrarMensaje(false, 'Interfaz destino desconocida.');
    }
}

/**
 * func03_mostrarMensaje
 *
 * 1. Descripción
 * Muestra mensajes al usuario usando SweetAlert2 si está disponible, o alert() como fallback.
 *
 * 2. Parámetros
 * - nombre: comprobante
 *   tipo: bool
 *   explicación: true = éxito, false = error/atención.
 * - nombre: mensaje
 *   tipo: string
 *   explicación: Texto a mostrar al usuario.
 *
 * 3. Errores, advertencias o notas
 * - Depende de la librería global `Swal` si está cargada.
 */
function func03_mostrarMensaje(comprobante, mensaje) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            icon: comprobante ? 'success' : 'error',
            title: comprobante ? 'Éxito' : 'Atención',
            text: mensaje
        });
    } else {
        alert((comprobante ? '✅ ' : '⚠️ ') + mensaje);
    }
}

/**
 * func04_validarFormulario
 *
 * 1. Descripción
 * Valida los campos de cambio de contraseña antes de permitir el envío.
 *
 * 2. Parámetros
 * - No requiere parámetros; lee valores del DOM:
 *   - `#contrasena_actual`, `#contrasena_nueva`, `#confirmar_contrasena`
 *
 * 3. Errores, advertencias o notas
 * - Muestra mensajes con func03_mostrarMensaje en caso de error y devuelve false.
 */
function func04_validarFormulario() {
    const actual = document.getElementById('contrasena_actual').value.trim();
    const nueva = document.getElementById('contrasena_nueva').value;
    const confirmar = document.getElementById('confirmar_contrasena').value;

    if ((nueva !== '' || confirmar !== '') && actual === '') {
        func03_mostrarMensaje(false, 'Para cambiar la contraseña debe ingresar la contraseña actual.');
        return false;
    }
    if (nueva !== '' && nueva !== confirmar) {
        func03_mostrarMensaje(false, 'La nueva contraseña y su confirmación no coinciden.');
        return false;
    }
    if (nueva !== '' && nueva.length < 6) {
        func03_mostrarMensaje(false, 'La nueva contraseña debe tener al menos 6 caracteres.');
        return false;
    }
    return true;
}

// Dropdown menu handler
document.addEventListener("DOMContentLoaded", () => {
    const dropdown = document.querySelector(".dropdown");
    if (dropdown) {
        const content = dropdown.querySelector(".dropdown-content");
        let hideTimeout;

        dropdown.addEventListener("mouseenter", () => {
            clearTimeout(hideTimeout);
            content.style.display = "block";
        });

        dropdown.addEventListener("mouseleave", () => {
            hideTimeout = setTimeout(() => {
                content.style.display = "none";
            }, 400);
        });
    }
});
