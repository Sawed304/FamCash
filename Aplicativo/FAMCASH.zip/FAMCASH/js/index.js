/**
 * index.js
 * --------
 * Funciones de navegación para la página de aterrizaje (index.php).
 * Diccionario UI-01: ingresarARegistro, ingresarAIniciarSesión, redirigirAInterfaz, mostrarMensaje
 */


/**
 * func01_ingresarARegistro
 *
 * 1. Descripción
 * Navega a la página de registro usando el id de interfaz correspondiente.
 *
 * 2. Parámetros
 * - nombre: idInterfazRegistro
 *   tipo: number
 *   explicación: ID de la interfaz de registro (usualmente 2).
 *
 * 3. Errores, advertencias o notas
 * - Llama a func03_redirigirAInterfaz internamente.
 */
function func01_ingresarARegistro(idInterfazRegistro) {
    func03_redirigirAInterfaz(idInterfazRegistro);
}


/**
 * func02_ingresarAIniciarSesion
 *
 * 1. Descripción
 * Navega a la página de inicio de sesión usando el id de interfaz correspondiente.
 *
 * 2. Parámetros
 * - nombre: idInterfazIniciarSesion
 *   tipo: number
 *   explicación: ID de la interfaz de inicio de sesión (usualmente 3).
 *
 * 3. Errores, advertencias o notas
 * - Llama a func03_redirigirAInterfaz internamente.
 */
function func02_ingresarAIniciarSesion(idInterfazIniciarSesion) {
    func03_redirigirAInterfaz(idInterfazIniciarSesion);
}


/**
 * func03_redirigirAInterfaz
 *
 * 1. Descripción
 * Redirige al usuario a la interfaz correspondiente según el ID recibido.
 *
 * 2. Parámetros
 * - nombre: idInterfaz
 *   tipo: number
 *   explicación: ID de la interfaz destino (2 para registro, 3 para login).
 *
 * 3. Errores, advertencias o notas
 * - Si el ID no es reconocido, muestra un mensaje de advertencia.
 */
function func03_redirigirAInterfaz(idInterfaz) {
    switch (idInterfaz) {
        case 2:
            window.location.href = "registro.php";
            break;
        case 3:
            window.location.href = "login.php";
            break;
        default:
            func04_mostrarMensaje(false, "Interfaz desconocida");
    }
}


/**
 * func04_mostrarMensaje
 *
 * 1. Descripción
 * Muestra un mensaje de alerta con un icono según el comprobante.
 *
 * 2. Parámetros
 * - nombre: comprobante
 *   tipo: boolean
 *   explicación: Si es true, muestra icono de éxito; si es false, de advertencia.
 * - nombre: mensaje
 *   tipo: string
 *   explicación: Mensaje a mostrar en la alerta.
 *
 * 3. Errores, advertencias o notas
 * - Utiliza alert() del navegador.
 */
function func04_mostrarMensaje(comprobante, mensaje) {
    alert((comprobante ? "✅ " : "⚠️ ") + mensaje);
}
