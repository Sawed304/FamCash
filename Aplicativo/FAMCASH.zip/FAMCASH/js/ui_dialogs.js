/* ui_dialogs.js
   Small, dependency-free modal dialogs: showConfirm(message, title) and showAlert(message, title)
   Returns Promises so callers can await user's choice.
*/
(function(){
  function createOverlay(){
    const ov = document.createElement('div'); ov.className = 'fc-overlay';
    return ov;
  }

  function createModal(title, message, isConfirm){
    const modal = document.createElement('div'); modal.className = 'fc-modal';

    if (title) {
      const h = document.createElement('div'); h.className = 'fc-title'; h.textContent = title; modal.appendChild(h);
    }

    const body = document.createElement('div'); body.className = 'fc-body'; body.innerHTML = message.replace(/\n/g, '<br>'); modal.appendChild(body);

    const actions = document.createElement('div'); actions.className = 'fc-actions';

    const btnCancel = document.createElement('button'); btnCancel.className = 'fc-btn fc-btn--secondary fc-small'; btnCancel.textContent = 'Cancelar';
    const btnOk = document.createElement('button'); btnOk.className = isConfirm ? 'fc-btn fc-btn--danger fc-small' : 'fc-btn fc-btn--primary fc-small'; btnOk.textContent = isConfirm ? 'Eliminar' : 'Aceptar';

    if (isConfirm) actions.appendChild(btnCancel);
    actions.appendChild(btnOk);
    modal.appendChild(actions);

    return { modal, btnOk, btnCancel };
  }

  function showConfirm(message, title){
    return new Promise(resolve => {
      const ov = createOverlay();
      const node = createModal(title || 'Confirmar acción', message, true);
      ov.appendChild(node.modal);
      document.body.appendChild(ov);

      node.btnOk.addEventListener('click', () => {
        document.body.removeChild(ov);
        resolve(true);
      });
      node.btnCancel.addEventListener('click', () => {
        document.body.removeChild(ov);
        resolve(false);
      });

      // allow ESC to cancel
      const keyHandler = (ev) => { if (ev.key === 'Escape') { document.body.removeChild(ov); document.removeEventListener('keydown', keyHandler); resolve(false); } };
      document.addEventListener('keydown', keyHandler);
    });
  }

  function showAlert(message, title){
    return new Promise(resolve => {
      const ov = createOverlay();
      const node = createModal(title || 'Aviso', message, false);
      ov.appendChild(node.modal);
      document.body.appendChild(ov);

      node.btnOk.addEventListener('click', () => {
        document.body.removeChild(ov);
        resolve();
      });

      // allow ESC to close
      const keyHandler = (ev) => { if (ev.key === 'Escape') { document.body.removeChild(ov); document.removeEventListener('keydown', keyHandler); resolve(); } };
      document.addEventListener('keydown', keyHandler);
    });
  }

  window.showConfirm = showConfirm;
  window.showAlert = showAlert;
})();
