/**
 * seleccionperfil.js
 * ------------------
 * Funciones para selección de perfil en seleccionperfil.php.
 * Diccionario UI-04: seleccionarUnPerfil, mostrarVentanaContraseña, llenarContraseñaPerfil,
 *                     redirigirAInterfazDentroDeCuenta, mostrarMensaje, cerrarModal
 */



/**
 * func01_mostrarVentanaContrasena
 *
 * 1. Descripción
 * Muestra el modal para ingresar la contraseña del perfil y enfoca el input.
 *
 * 2. Parámetros
 * - No recibe parámetros (accede al DOM directamente).
 *
 * 3. Errores, advertencias o notas
 * - Limpia el campo de contraseña antes de mostrar el modal.
 */
function func01_mostrarVentanaContrasena() {
    const modal = document.getElementById('modal');
    const passInput = document.getElementById('password');
    passInput.value = '';
    modal.style.display = 'flex';
    passInput.focus();
}



/**
 * func02_redirigirAInterfazDentroDeCuenta
 *
 * 1. Descripción
 * Redirige al usuario a la interfaz de entrada diaria si el ID es 5.
 *
 * 2. Parámetros
 * - nombre: idInterfaz
 *   tipo: number
 *   explicación: ID de la interfaz destino (5 para entrada diaria).
 *
 * 3. Errores, advertencias o notas
 * - Si el ID no es 5, muestra mensaje de advertencia.
 */
function func02_redirigirAInterfazDentroDeCuenta(idInterfaz) {
    if (idInterfaz === 5) {
        setTimeout(function() {
            window.location.href = "entrada_diaria.php";
        }, 900);
    } else {
        func05_mostrarMensaje(false, "Interfaz desconocida.");
    }
}


/**
 * func05_mostrarMensaje
 *
 * 1. Descripción
 * Muestra un mensaje de alerta con un icono según el comprobante.
 *
 * 2. Parámetros
 * - nombre: comprobante
 *   tipo: boolean
 *   explicación: Si es true, muestra icono de éxito; si es false, de advertencia.
 * - nombre: mensaje
 *   tipo: string
 *   explicación: Mensaje a mostrar en la alerta.
 *
 * 3. Errores, advertencias o notas
 * - Utiliza alert() del navegador.
 */
function func05_mostrarMensaje(comprobante, mensaje) {
    alert((comprobante ? '✅ ' : '⚠️ ') + mensaje);
}




/**
 * func03_seleccionarUnPerfil
 *
 * 1. Descripción
 * Selecciona un perfil y muestra el modal para ingresar la contraseña.
 *
 * 2. Parámetros
 * - nombre: perfilId
 *   tipo: number|string
 *   explicación: ID del perfil seleccionado.
 *
 * 3. Errores, advertencias o notas
 * - Asigna el valor al input oculto y muestra el modal.
 */
function func03_seleccionarUnPerfil(perfilId) {
    document.getElementById('perfil_id').value = perfilId;
    document.getElementById('modal').style.display = 'flex';
}


/**
 * func04_cerrarModal
 *
 * 1. Descripción
 * Cierra el modal de contraseña y limpia el campo de contraseña.
 *
 * 2. Parámetros
 * - No recibe parámetros (accede al DOM directamente).
 *
 * 3. Errores, advertencias o notas
 * - Limpia el campo de contraseña al cerrar el modal.
 */
function func04_cerrarModal() {
    document.getElementById('modal').style.display = 'none';
    document.getElementById('password').value = '';
}


/**
 * func06_llenarContrasenaPerfil
 *
 * 1. Descripción
 * Valida que el campo de contraseña no esté vacío antes de enviar el formulario.
 *
 * 2. Parámetros
 * - No recibe parámetros (accede al DOM directamente).
 *
 * 3. Errores, advertencias o notas
 * - Muestra mensaje de advertencia si el campo está vacío.
 */
function func06_llenarContrasenaPerfil() {
    const password = document.getElementById('password').value;
    if (!password) {
        func05_mostrarMensaje(false, "Por favor, ingrese la contraseña");
        return false;
    }
    return true;
}