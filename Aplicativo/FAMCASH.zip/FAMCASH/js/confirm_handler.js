// confirm_handler.js
// Intercepta formularios y elementos con `data-confirm` y muestra el modal showConfirm
document.addEventListener('DOMContentLoaded', function () {
    function getConfirmFn() {
        if (typeof showConfirm === 'function') return showConfirm;
        return function (msg, title) {
            return new Promise(function (resolve) {
                resolve(confirm(msg));
            });
        };
    }

    const confirmFn = getConfirmFn();

    // Manejar forms con data-confirm
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const msg = form.getAttribute('data-confirm') || '¿Estás seguro?';
            confirmFn(msg, 'Confirmar').then(function (ok) {
                if (ok) form.submit();
            });
        });
    });

    // Manejar elementos clickables con data-confirm y data-href (links o botones fuera de form)
    document.querySelectorAll('[data-confirm][data-href]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            e.preventDefault();
            const msg = el.getAttribute('data-confirm') || '¿Estás seguro?';
            const href = el.getAttribute('data-href');
            confirmFn(msg, 'Confirmar').then(function (ok) {
                if (ok) window.location.href = href;
            });
        });
    });

    // Manejar botones dentro de forms con data-confirm (p.e. botones tipo submit)
    // Evitar volver a procesar elementos que ya tienen data-href (manejados arriba)
    document.querySelectorAll('button[data-confirm]:not([data-href]), input[type="submit"][data-confirm]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            const form = btn.closest('form');
            if (!form) return; // no es submit dentro de form
            const msg = btn.getAttribute('data-confirm') || form.getAttribute('data-confirm') || '¿Estás seguro?';
            // Si el form ya gestiona data-confirm, dejar que el submit sea manejado por él
            if (form.hasAttribute('data-confirm')) return;
            e.preventDefault();
            confirmFn(msg, 'Confirmar').then(function (ok) {
                if (ok) {
                    // Si el botón tiene name/value, crear envío vía form
                    // Simular click real para respetar valores
                    btn.disabled = true;
                    form.submit();
                }
            }).finally(function(){ btn.disabled = false; });
        });
    });
});
