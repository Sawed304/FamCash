/**
 * gestionar_concepto.js
 * ================================================================================
 * LÓGICA DE INTERFAZ DE USUARIO PARA LA PÁGINA DE GESTIONAR CONCEPTOS
 * (gestionar_concepto.php)
 * 
 * Este archivo contiene funciones para:
 *  1. Abrir modal de edición de conceptos
 *  2. Cerrar modal de edición
 *  3. Manejar clics fuera del modal para cerrarlo
 *  4. Gestionar el dropdown del menú de configuración
 *  5. Mostrar/ocultar la configuración de recordatorios
 */

/**
 * func01_abrirModalEditar
 *
 * 1. Descripción
 * Abre el modal de edición precargando los datos del concepto seleccionado.
 *
 * 2. Parámetros
 * - nombre: id
 *   tipo: int
 *   explicación: ID del concepto en la BD (id_concepto).
 * - nombre: nombre
 *   tipo: string
 *   explicación: Nombre actual del concepto (ej: "Salario").
 * - nombre: tipo
 *   tipo: string
 *   explicación: Tipo actual ("Ingreso" o "Egreso").
 *
 * 3. Errores, advertencias o notas
 * - Añade la clase 'active' al modal para mostrarlo con display: block.
 * - El modal envía datos a gestionar_concepto.php al hacer POST.
 */
function func01_abrirModalEditar(id, nombre, tipo) {
    // Guardar id si el campo existe
    const modalIdEl = document.getElementById('modalId');
    if (modalIdEl) modalIdEl.value = id;

    // Compatibilidad: algunas páginas usan 'modalAlias' (alias), otras 'modalNombre' (nombre)
    const modalAliasEl = document.getElementById('modalAlias');
    const modalNombreEl = document.getElementById('modalNombre');
    const modalTipoEl = document.getElementById('modalTipo');

    if (modalAliasEl) {
        modalAliasEl.value = (typeof nombre !== 'undefined') ? nombre : '';
    }
    if (modalNombreEl) {
        modalNombreEl.value = (typeof nombre !== 'undefined') ? nombre : '';
    }
    if (modalTipoEl && typeof tipo !== 'undefined') {
        modalTipoEl.value = tipo;
    }

    const modalEditar = document.getElementById('modalEditar');
    if (modalEditar) {
        modalEditar.classList.add('active');
        // focus the most relevant input
        if (modalAliasEl) modalAliasEl.focus();
        else if (modalNombreEl) modalNombreEl.focus();
    }
}

/**
 * func02_cerrarModal
 *
 * 1. Descripción
 * Cierra el modal de edición removiendo la clase 'active'.
 *
 * 2. Parámetros
 * - No requiere parámetros.
 *
 * 3. Errores, advertencias o notas
 * - Remueve la clase 'active' del modal para ocultarlo con CSS (display: none).
 */
function func02_cerrarModal() {
    document.getElementById('modalEditar').classList.remove('active');
}

/**
 * func03_toggleRecordatorioConfig
 *
 * 1. Descripción
 * Muestra u oculta la sección de configuración de recordatorios según el estado del checkbox.
 *
 * 2. Parámetros
 * - No requiere parámetros; lee el checkbox #crear_recordatorio del DOM.
 *
 * 3. Errores, advertencias o notas
 * - Si el checkbox está marcado, muestra la sección.
 * - Si no está marcado, oculta la sección.
 */
function func03_toggleRecordatorioConfig() {
    const checkbox = document.getElementById('crear_recordatorio');
    const configSection = document.getElementById('recordatorio_config');
    
    if (checkbox.checked) {
        configSection.style.display = 'block';
        // Rellenar automáticamente el nombre del recordatorio si está vacío
        const nombreConcepto = document.querySelector('input[name="nombre_concepto"]').value;
        const nombreRecordatorio = document.getElementById('nombre_recordatorio');
        if (nombreRecordatorio.value === '' && nombreConcepto !== '') {
            nombreRecordatorio.value = 'Recordatorio: ' + nombreConcepto;
        }
    } else {
        configSection.style.display = 'none';
    }
}

// ================================================================================
// INICIALIZADORES (DOMContentLoaded)
// ================================================================================
/**
 * Se ejecuta cuando el DOM está completamente cargado.
 * Realiza inicializaciones necesarias:
 *  1. Configura el manejador de clic fuera del modal para cerrarlo
 *  2. Configura el dropdown del menú de configuración
 *  3. Configura el evento para el checkbox de recordatorios
 */
document.addEventListener('DOMContentLoaded', () => {
    /**
     * MANEJADOR: Cerrar modal al hacer clic fuera de su contenido
     * 
     * Comportamiento:
     *  - Si el usuario hace clic en el fondo del modal (no en el contenido):
     *    - Se dispara el evento click en el modal
     *    - Si e.target === modal (clic en el fondo): llama a cerrarModal()
     *  - Si hace clic dentro del modal (en el contenido):
     *    - El evento no lo dispara cerrarModal()
     *    - El usuario puede seguir editando o hacer clic en "Cancelar"
     * 
     * NOTA: Proporciona una mejor UX permitiendo cerrar sin botón,
     *       pero evitando cerrar accidentalmente al hacer clic en el formulario.
     */
    const modal = document.getElementById('modalEditar');
    const modalContent = document.querySelector('.modal-content');

    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                func02_cerrarModal();
            }
        });
    }

    /**
     * CONFIGURACIÓN DE RECORDATORIOS
     * 
     * Inicializa el comportamiento del checkbox de recordatorios
     * y establece el estado inicial de la sección de configuración.
     */
    const recordatorioCheckbox = document.getElementById('crear_recordatorio');
    if (recordatorioCheckbox) {
        // Establecer estado inicial
        func03_toggleRecordatorioConfig();
        // Configurar evento para cambios
        recordatorioCheckbox.addEventListener('change', func03_toggleRecordatorioConfig);
    }

    /**
     * DROPDOWN MENU HANDLER
     * 
     * Maneja la apertura/cierre del dropdown del menú de configuración.
     * 
     * Comportamiento:
     *  - Al pasar el mouse sobre el dropdown:
     *    - Limpia cualquier timeout pendiente
     *    - Muestra .dropdown-content (display: block)
     *  
     *  - Al quitar el mouse del dropdown:
     *    - Espera 400ms
     *    - Luego oculta .dropdown-content (display: none)
     *    - Este retraso permite que el usuario mueva el cursor suavemente
     *      desde el botón al menú sin que se cierre
     * 
     * NOTA: El dropdown contiene enlaces como "Cerrar sesión" o "Volver".
     */
    const dropdown = document.querySelector(".dropdown");
    if (dropdown) {
        const content = dropdown.querySelector(".dropdown-content");
        let hideTimeout;

        dropdown.addEventListener("mouseenter", () => {
            clearTimeout(hideTimeout);
            content.style.display = "block";
        });

        dropdown.addEventListener("mouseleave", () => {
            hideTimeout = setTimeout(() => {
                content.style.display = "none";
            }, 1500);
        });
    }
});