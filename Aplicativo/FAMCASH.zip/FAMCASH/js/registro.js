/**
 * registro.js
 * -----------
 * Funciones de registro para registro.php.
 * Diccionario UI-02: llenarRegistroPerfil, redirigirAInterfazDentroDeCuenta, mostrarMensaje
 */


/**
 * func01_validarContrasena
 *
 * 1. Descripción
 * Valida si una contraseña cumple con los requisitos mínimos: longitud y al menos un número.
 *
 * 2. Parámetros
 * - nombre: contrasena
 *   tipo: string
 *   explicación: Contraseña a validar.
 *
 * 3. Errores, advertencias o notas
 * - Retorna un objeto con propiedades valido (boolean) y mensaje (string).
 */
function func01_validarContrasena(contrasena) {
    if (contrasena.length < 6) {
        return { valido: false, mensaje: "La contraseña debe tener al menos 6 caracteres." };
    }
    if (!/\d/.test(contrasena)) {
        return { valido: false, mensaje: "La contraseña debe contener al menos un número." };
    }
    return { valido: true, mensaje: "" };
}


/**
 * func02_llenarRegistroPerfil
 *
 * 1. Descripción
 * Valida todos los campos del formulario de registro antes de enviarlo.
 *
 * 2. Parámetros
 * - No recibe parámetros (toma los valores del DOM).
 *
 * 3. Errores, advertencias o notas
 * - Muestra mensajes de error y retorna false si alguna validación falla.
 */
function func02_llenarRegistroPerfil() {
    const nombre = document.querySelector('[name="nombre_registro"]').value.trim();
    const contrasena = document.querySelector('[name="contrasena_registro"]').value;
    const repetir = document.querySelector('[name="repetir_contrasena_registro"]').value;
    const nombrePerfil = document.querySelector('[name="nombre_perfil"]').value.trim();
    const contrasenaPerfil = document.querySelector('[name="contrasena_perfil"]').value;
    const repetirPerfil = document.querySelector('[name="repetir_contrasena_perfil"]').value;

    // Validar campos vacíos
    if (!nombre || !contrasena || !repetir || !nombrePerfil || !contrasenaPerfil || !repetirPerfil) {
        func04_mostrarMensaje(false, "Por favor, complete todos los campos.");
        return false;
    }

    // Validar contraseña de la familia
    const validacionFamilia = func01_validarContrasena(contrasena);
    if (!validacionFamilia.valido) {
        func04_mostrarMensaje(false, "Contraseña de cuenta: " + validacionFamilia.mensaje);
        return false;
    }

    // Validar contraseña del perfil
    const validacionPerfil = func01_validarContrasena(contrasenaPerfil);
    if (!validacionPerfil.valido) {
        func04_mostrarMensaje(false, "Contraseña de perfil: " + validacionPerfil.mensaje);
        return false;
    }

    // Validar aceptación de términos
    const acceptTerms = document.querySelector('[name="accept_terms"]');
    if (!acceptTerms || !acceptTerms.checked) {
        func04_mostrarMensaje(false, 'Debe aceptar los Términos y condiciones para registrarse.');
        return false;
    }

    // Validar que las contraseñas coincidan
    if (contrasena !== repetir || contrasenaPerfil !== repetirPerfil) {
        func04_mostrarMensaje(false, "Las contraseñas no coinciden.");
        return false;
    }

    return true;
}


/**
 * func03_redirigirAInterfazDentroDeCuenta
 *
 * 1. Descripción
 * Redirige al usuario a la interfaz correspondiente después del registro.
 *
 * 2. Parámetros
 * - nombre: idInterfaz
 *   tipo: number
 *   explicación: ID de la interfaz destino (3 para login, otro para index).
 * - nombre: idPerfil
 *   tipo: number
 *   explicación: ID del perfil (no se usa en la lógica actual).
 *
 * 3. Errores, advertencias o notas
 * - El cambio de página se realiza con un retardo de 900 ms.
 */
function func03_redirigirAInterfazDentroDeCuenta(idInterfaz, idPerfil) {
    if (idInterfaz === 3) {
        setTimeout(function() {
            window.location.href = "login.php";
        }, 900);
    } else {
        setTimeout(function() {
            window.location.href = "index.php";
        }, 900);
    }
}


/**
 * func04_mostrarMensaje
 *
 * 1. Descripción
 * Muestra un mensaje de alerta usando SweetAlert2 si está disponible, o alert() si no.
 *
 * 2. Parámetros
 * - nombre: comprobante
 *   tipo: boolean
 *   explicación: Si es true, muestra icono de éxito; si es false, de error.
 * - nombre: mensaje
 *   tipo: string
 *   explicación: Mensaje a mostrar en la alerta.
 *
 * 3. Errores, advertencias o notas
 * - Si SweetAlert2 no está disponible, usa alert() del navegador.
 */
function func04_mostrarMensaje(comprobante, mensaje) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            icon: comprobante ? 'success' : 'error',
            title: comprobante ? 'Éxito' : 'Atención',
            text: mensaje
        });
    } else {
        alert((comprobante ? "✅ " : "⚠️ ") + mensaje);
    }
}


/**
 * func05_togglePasswordVisibility
 *
 * 1. Descripción
 * Muestra u oculta el texto de un campo de contraseña para mejorar la experiencia de usuario.
 *
 * 2. Parámetros
 * - nombre: inputId
 *   tipo: string
 *   explicación: Nombre del campo de input a mostrar/ocultar.
 *
 * 3. Errores, advertencias o notas
 * - Cambia el tipo del input entre 'password' y 'text'.
 */
function func05_togglePasswordVisibility(inputId) {
    const input = document.querySelector(`[name="${inputId}"]`);
    if (input.type === 'password') {
        input.type = 'text';
    } else {
        input.type = 'password';
    }
}


/**
 * Validación en tiempo real mientras el usuario escribe (opcional)
 *
 * 1. Descripción
 * Agrega listeners a los campos de contraseña para validar en tiempo real mientras el usuario escribe.
 *
 * 2. Parámetros
 * - No recibe parámetros (se ejecuta al cargar el DOM).
 *
 * 3. Errores, advertencias o notas
 * - Llama a func06_validarContrasenaEnTiempoReal en cada input.
 */
document.addEventListener('DOMContentLoaded', function() {
    const passwordInputs = [
        'contrasena_registro',
        'repetir_contrasena_registro', 
        'contrasena_perfil',
        'repetir_contrasena_perfil'
    ];
    passwordInputs.forEach(inputName => {
        const input = document.querySelector(`[name="${inputName}"]`);
        if (input) {
            input.addEventListener('input', function() {
                func06_validarContrasenaEnTiempoReal(this);
            });
        }
    });
});


/**
 * func06_validarContrasenaEnTiempoReal
 *
 * 1. Descripción
 * Valida visualmente en tiempo real la contraseña mientras el usuario escribe.
 *
 * 2. Parámetros
 * - nombre: input
 *   tipo: HTMLElement
 *   explicación: Campo de input de contraseña a validar.
 *
 * 3. Errores, advertencias o notas
 * - Cambia las clases CSS del input según la validez de la contraseña.
 */
function func06_validarContrasenaEnTiempoReal(input) {
    const contrasena = input.value;
    input.classList.remove('contrasena-valida', 'contrasena-invalida');
    if (contrasena.length === 0) {
        return; // No mostrar nada si está vacío
    }
    const validacion = func01_validarContrasena(contrasena);
    if (validacion.valido) {
        input.classList.add('contrasena-valida');
    } else {
        input.classList.add('contrasena-invalida');
    }
}