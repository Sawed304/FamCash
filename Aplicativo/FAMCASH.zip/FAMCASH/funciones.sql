-- ================================================================================
-- FUNCIONES Y PROCEDIMIENTOS CONSOLIDADOS PARA FAMCASH
-- ================================================================================
-- Archivo único con TODAS las funciones almacenadas.
-- Los archivos PHP SOLO deben llamar a estos procedimientos.
-- 
-- INSTALACIÓN: En phpMyAdmin, Base de datos > SQL > Copiar todo este contenido
--              y ejecutar. O en terminal: mysql famcash_db < funciones.sql
-- ================================================================================

DELIMITER $$

-- ================================================================================
-- 1. PROCEDIMIENTOS PARA GESTIÓN DE TRANSACCIONES
-- ================================================================================

-- 1.1. Obtener conceptos disponibles para un perfil
DROP PROCEDURE IF EXISTS sp_get_conceptos_perfil $$
CREATE PROCEDURE sp_get_conceptos_perfil(
    IN p_id_perfil INT
)
READS SQL DATA
BEGIN
    SELECT 
        c.id_concepto, 
        COALESCE(pc.alias_concepto, c.nombre_concepto) AS nombre, 
        c.tipo 
    FROM Concepto c
    INNER JOIN Perfil_Concepto pc ON c.id_concepto = pc.id_concepto_Concepto
    WHERE pc.id_perfil_Perfil = p_id_perfil AND pc.activo = 1
    ORDER BY c.tipo DESC, COALESCE(pc.alias_concepto, c.nombre_concepto);
END $$

-- 1.2. Obtener transacciones del día para un perfil
DROP PROCEDURE IF EXISTS sp_get_transacciones_dia $$
CREATE PROCEDURE sp_get_transacciones_dia(
    IN p_id_perfil INT,
    IN p_fecha DATE
)
READS SQL DATA
BEGIN
    SELECT 
        t.*, 
        c.nombre_concepto, 
        c.tipo, 
        pc.alias_concepto
    FROM Transaccion t 
    JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto 
    LEFT JOIN Perfil_Concepto pc ON (c.id_concepto = pc.id_concepto_Concepto AND pc.id_perfil_Perfil = p_id_perfil)
    WHERE t.id_perfil_Perfil = p_id_perfil AND DATE(t.fecha) = p_fecha
    ORDER BY c.tipo DESC, t.detalle;
END $$

-- 1.3. Crear nueva transacción
DROP PROCEDURE IF EXISTS sp_crear_transaccion $$
CREATE PROCEDURE sp_crear_transaccion(
    IN p_id_perfil INT,
    IN p_id_concepto INT,
    IN p_fecha DATE,
    IN p_monto DECIMAL(10, 2),
    IN p_detalle VARCHAR(255),
    OUT p_id_transaccion INT
)
MODIFIES SQL DATA
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_id_transaccion = -1;
    END;
    
    INSERT INTO Transaccion (id_perfil_Perfil, id_concepto_Concepto, fecha, monto, detalle) 
    VALUES (p_id_perfil, p_id_concepto, p_fecha, p_monto, p_detalle);
    
    SET p_id_transaccion = LAST_INSERT_ID();
END $$

-- 1.4. Eliminar transacción (con validación de propiedad)
DROP PROCEDURE IF EXISTS sp_eliminar_transaccion $$
CREATE PROCEDURE sp_eliminar_transaccion(
    IN p_id_transaccion INT,
    IN p_id_perfil INT,
    OUT p_resultado INT
)
MODIFIES SQL DATA
BEGIN
    DECLARE v_owner INT;
    
    -- Verificar que el perfil es dueño de la transacción
    SELECT id_perfil_Perfil INTO v_owner FROM Transaccion 
    WHERE id_transaccion = p_id_transaccion LIMIT 1;
    
    IF v_owner IS NULL OR v_owner != p_id_perfil THEN
        SET p_resultado = 0;
    ELSE
        DELETE FROM Transaccion WHERE id_transaccion = p_id_transaccion;
        SET p_resultado = 1;
    END IF;
END $$

-- 1.5. Obtener transacciones con filtros (familia + perfil + fecha)
DROP PROCEDURE IF EXISTS sp_get_transacciones_detalle $$
CREATE PROCEDURE sp_get_transacciones_detalle(
    IN p_id_familia INT,
    IN p_id_perfil INT,
    IN p_fecha DATE
)
READS SQL DATA
BEGIN
    SELECT 
        t.id_transaccion, 
        CASE 
            WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto)
            ELSE t.monto 
        END as monto,
        t.detalle, 
        t.id_perfil_Perfil AS perfil_id, 
        p.nombre_perfil, 
        c.id_concepto, 
        c.tipo, 
        pc.alias_concepto
    FROM Transaccion t 
    JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto 
    JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil 
    LEFT JOIN Perfil_Concepto pc ON (c.id_concepto = pc.id_concepto_Concepto 
        AND pc.id_perfil_Perfil = t.id_perfil_Perfil AND pc.activo = 1)
    WHERE DATE(t.fecha) = p_fecha 
        AND (p_id_familia IS NULL OR p.id_familia_Familia = p_id_familia)
        AND (p_id_perfil IS NULL OR t.id_perfil_Perfil = p_id_perfil)
    ORDER BY c.tipo DESC, t.detalle;
END $$

-- 1.6. Actualizar transacción
DROP PROCEDURE IF EXISTS sp_update_transaccion $$
CREATE PROCEDURE sp_update_transaccion(
    IN p_id_transaccion INT,
    IN p_detalle TEXT,
    IN p_monto DECIMAL(12,2),
    IN p_id_perfil INT,
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Transaccion SET detalle = p_detalle, monto = p_monto WHERE id_transaccion = p_id_transaccion AND id_perfil_Perfil = p_id_perfil;
    SET p_result = ROW_COUNT();
END $$

-- ================================================================================
-- 2. PROCEDIMIENTOS PARA RESÚMENES FINANCIEROS
-- ================================================================================

-- 2.1. Obtener resumen por rango (mensual/anual)
DROP PROCEDURE IF EXISTS sp_get_resumen_rango $$
CREATE PROCEDURE sp_get_resumen_rango(
    IN p_id_familia INT,
    IN p_id_perfil INT,
    IN p_fecha_inicio DATE,
    IN p_fecha_fin DATE,
    OUT p_ingresos DECIMAL(12, 2),
    OUT p_egresos DECIMAL(12, 2)
)
READS SQL DATA
BEGIN
    SELECT 
        IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto) ELSE 0 END), 0),
        IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN ABS(t.monto) ELSE 0 END), 0)
    INTO p_ingresos, p_egresos
    FROM Transaccion t
    JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto
    JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil
    WHERE DATE(t.fecha) BETWEEN p_fecha_inicio AND p_fecha_fin
        AND (p_id_familia IS NULL OR p.id_familia_Familia = p_id_familia)
        AND (p_id_perfil IS NULL OR t.id_perfil_Perfil = p_id_perfil);
END $$

-- 2.2. Obtener balance por concepto para una fecha
DROP PROCEDURE IF EXISTS sp_get_balance_por_concepto $$
CREATE PROCEDURE sp_get_balance_por_concepto(
    IN p_id_familia INT,
    IN p_id_perfil INT,
    IN p_fecha DATE
)
READS SQL DATA
BEGIN
    SELECT 
        c.id_concepto AS idConcepto, 
        COALESCE(pc.alias_concepto, c.nombre_concepto) AS nombre, 
        c.tipo, 
        t.id_perfil_Perfil AS contribuidor, 
        SUM(t.monto) AS total
    FROM Concepto c
    INNER JOIN Transaccion t ON c.id_concepto = t.id_concepto_Concepto 
    LEFT JOIN Perfil_Concepto pc ON (c.id_concepto = pc.id_concepto_Concepto 
        AND pc.id_perfil_Perfil = t.id_perfil_Perfil AND pc.activo = 1)
    WHERE DATE(t.fecha) = p_fecha
        AND (p_id_familia IS NULL OR EXISTS (
            SELECT 1 FROM Perfil pf WHERE pf.id_perfil = t.id_perfil_Perfil 
            AND pf.id_familia_Familia = p_id_familia
        ))
        AND (p_id_perfil IS NULL OR t.id_perfil_Perfil = p_id_perfil)
    GROUP BY c.id_concepto, COALESCE(pc.alias_concepto, c.nombre_concepto), c.tipo, t.id_perfil_Perfil 
    ORDER BY c.tipo DESC, COALESCE(pc.alias_concepto, c.nombre_concepto);
END $$

-- 2.3. Obtener totales por rango (balance general)
DROP PROCEDURE IF EXISTS sp_get_totals_range $$
CREATE PROCEDURE sp_get_totals_range(IN p_id_familia INT, IN p_fecha_inicio DATE, IN p_fecha_fin DATE)
READS SQL DATA
BEGIN
    SELECT
        IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto) ELSE 0 END),0) AS ingresos,
        IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN ABS(t.monto) ELSE 0 END),0) AS egresos
    FROM Transaccion t
    JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto
    JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil
    WHERE (p.id_familia_Familia = p_id_familia OR p_id_familia IS NULL)
      AND DATE(t.fecha) BETWEEN p_fecha_inicio AND p_fecha_fin;
END $$

-- ================================================================================
-- 3. PROCEDIMIENTOS PARA GESTIÓN DE CONCEPTOS
-- ================================================================================

-- 3.1. Obtener conceptos activos por perfil (con todos los campos)
DROP PROCEDURE IF EXISTS sp_get_conceptos_activos_por_perfil $$
CREATE PROCEDURE sp_get_conceptos_activos_por_perfil(IN p_id_perfil INT)
READS SQL DATA
BEGIN
    SELECT c.id_concepto, c.nombre_concepto, c.tipo, pc.alias_concepto, pc.activo
    FROM Concepto c
    INNER JOIN Perfil_Concepto pc ON c.id_concepto = pc.id_concepto_Concepto
    WHERE pc.id_perfil_Perfil = p_id_perfil AND pc.activo = 1
    ORDER BY c.tipo DESC, COALESCE(pc.alias_concepto, c.nombre_concepto) ASC;
END $$

-- 3.2. Insertar concepto
DROP PROCEDURE IF EXISTS sp_insert_concepto $$
CREATE PROCEDURE sp_insert_concepto(
    IN p_nombre VARCHAR(255),
    IN p_tipo VARCHAR(50)
)
MODIFIES SQL DATA
BEGIN
    INSERT IGNORE INTO Concepto (nombre_concepto, tipo) VALUES (p_nombre, p_tipo);
    SELECT id_concepto FROM Concepto WHERE nombre_concepto = p_nombre AND tipo = p_tipo LIMIT 1;
END $$

-- 3.3. Obtener concepto por nombre
DROP PROCEDURE IF EXISTS sp_get_concepto_by_name $$
CREATE PROCEDURE sp_get_concepto_by_name(
    IN p_nombre VARCHAR(255),
    IN p_tipo VARCHAR(50)
)
READS SQL DATA
BEGIN
    SELECT id_concepto FROM Concepto WHERE nombre_concepto = p_nombre AND tipo = p_tipo LIMIT 1;
END $$

-- 3.4. Obtener concepto por nombre y tipo (ID y tipo)
DROP PROCEDURE IF EXISTS sp_get_concepto_same_name $$
CREATE PROCEDURE sp_get_concepto_same_name(
    IN p_nombre VARCHAR(255)
)
READS SQL DATA
BEGIN
    SELECT id_concepto, tipo FROM Concepto WHERE nombre_concepto = p_nombre LIMIT 1;
END $$

-- 3.5. Obtener todos los conceptos
DROP PROCEDURE IF EXISTS sp_get_all_conceptos $$
CREATE PROCEDURE sp_get_all_conceptos()
READS SQL DATA
BEGIN
    SELECT id_concepto, nombre_concepto, tipo FROM Concepto;
END $$

-- 3.6. Insertar perfil concepto
DROP PROCEDURE IF EXISTS sp_insert_perfil_concepto $$
CREATE PROCEDURE sp_insert_perfil_concepto(
    IN p_id_perfil INT,
    IN p_id_familia INT,
    IN p_id_concepto INT,
    IN p_alias VARCHAR(255)
)
MODIFIES SQL DATA
BEGIN
    INSERT IGNORE INTO Perfil_Concepto (id_perfil_Perfil, id_familia_Familia, id_concepto_Concepto, alias_concepto, activo)
    VALUES (p_id_perfil, p_id_familia, p_id_concepto, p_alias, 1);
    SELECT ROW_COUNT() AS affected_rows;
END $$

-- 3.7. Obtener perfil concepto
DROP PROCEDURE IF EXISTS sp_get_perfil_concepto $$
CREATE PROCEDURE sp_get_perfil_concepto(
    IN p_id_perfil INT,
    IN p_nombre VARCHAR(255),
    IN p_tipo VARCHAR(50)
)
READS SQL DATA
BEGIN
    SELECT pc.activo, c.tipo, c.id_concepto
    FROM Perfil_Concepto pc
    JOIN Concepto c ON pc.id_concepto_Concepto = c.id_concepto
    WHERE pc.id_perfil_Perfil = p_id_perfil AND c.nombre_concepto = p_nombre AND c.tipo = p_tipo
    LIMIT 1;
END $$

-- 3.8. Obtener perfil concepto con tipo diferente
DROP PROCEDURE IF EXISTS sp_get_perfil_concepto_different_tipo $$
CREATE PROCEDURE sp_get_perfil_concepto_different_tipo(
    IN p_id_perfil INT,
    IN p_nombre VARCHAR(255),
    IN p_tipo VARCHAR(50)
)
READS SQL DATA
BEGIN
    SELECT pc.activo, c.tipo, c.id_concepto
    FROM Perfil_Concepto pc
    JOIN Concepto c ON pc.id_concepto_Concepto = c.id_concepto
    WHERE pc.id_perfil_Perfil = p_id_perfil AND c.nombre_concepto = p_nombre AND c.tipo != p_tipo AND pc.activo = 0
    LIMIT 1;
END $$

-- 3.9. Activar perfil concepto
DROP PROCEDURE IF EXISTS sp_activate_perfil_concepto $$
CREATE PROCEDURE sp_activate_perfil_concepto(
    IN p_id_perfil INT,
    IN p_id_concepto INT,
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil_Concepto SET activo = 1 WHERE id_perfil_Perfil = p_id_perfil AND id_concepto_Concepto = p_id_concepto;
    SET p_result = ROW_COUNT();
END $$

-- 3.10. Desactivar perfil concepto
DROP PROCEDURE IF EXISTS sp_deactivate_perfil_concepto $$
CREATE PROCEDURE sp_deactivate_perfil_concepto(
    IN p_id_perfil INT,
    IN p_id_concepto INT,
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil_Concepto SET activo = 0 WHERE id_perfil_Perfil = p_id_perfil AND id_concepto_Concepto = p_id_concepto;
    SET p_result = ROW_COUNT();
END $$

-- 3.11. Actualizar perfil concepto alias
DROP PROCEDURE IF EXISTS sp_update_perfil_concepto_alias $$
CREATE PROCEDURE sp_update_perfil_concepto_alias(
    IN p_id_perfil INT,
    IN p_id_concepto INT,
    IN p_alias VARCHAR(255),
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil_Concepto SET alias_concepto = p_alias WHERE id_perfil_Perfil = p_id_perfil AND id_concepto_Concepto = p_id_concepto;
    SET p_result = ROW_COUNT();
END $$

-- 3.12. Contar transacciones por concepto y perfil
DROP PROCEDURE IF EXISTS sp_count_transactions_by_concept_and_perfil $$
CREATE PROCEDURE sp_count_transactions_by_concept_and_perfil(IN p_id_concepto INT, IN p_id_perfil INT)
READS SQL DATA
BEGIN
    SELECT COUNT(*) AS c FROM Transaccion WHERE id_concepto_Concepto = p_id_concepto AND id_perfil_Perfil = p_id_perfil;
END $$

-- ================================================================================
-- 4. PROCEDIMIENTOS PARA GESTIÓN DE PERFILES
-- ================================================================================

-- 4.1. Obtener perfiles de una familia
DROP PROCEDURE IF EXISTS sp_get_perfiles_familia $$
CREATE PROCEDURE sp_get_perfiles_familia(
    IN p_id_familia INT
)
READS SQL DATA
BEGIN
    SELECT id_perfil, nombre_perfil, rol, IFNULL(estado, 'Habilitado') AS estado FROM Perfil WHERE id_familia_Familia = p_id_familia ORDER BY id_perfil ASC;
END $$

-- 4.2. Crear nuevo perfil
DROP PROCEDURE IF EXISTS sp_crear_perfil $$
CREATE PROCEDURE sp_crear_perfil(
    IN p_id_familia INT,
    IN p_nombre VARCHAR(100),
    IN p_contrasena_hash VARCHAR(255),
    IN p_rol VARCHAR(50),
    OUT p_id_perfil INT
)
MODIFIES SQL DATA
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_id_perfil = -1;
    END;
    
    INSERT INTO Perfil (id_familia_Familia, nombre_perfil, contraseña_perfil, rol, estado) 
    VALUES (p_id_familia, p_nombre, p_contrasena_hash, p_rol, 'Habilitado');
    
    SET p_id_perfil = LAST_INSERT_ID();
END $$

-- 4.3. Obtener perfil por ID
DROP PROCEDURE IF EXISTS sp_get_perfil_por_id $$
CREATE PROCEDURE sp_get_perfil_por_id(
    IN p_id_perfil INT
)
READS SQL DATA
BEGIN
    SELECT * FROM Perfil WHERE id_perfil = p_id_perfil LIMIT 1;
END $$

-- 4.4. Obtener credenciales de perfil
DROP PROCEDURE IF EXISTS sp_get_perfil_credentials $$
CREATE PROCEDURE sp_get_perfil_credentials(
    IN p_id_perfil INT
)
READS SQL DATA
BEGIN
    SELECT nombre_perfil, contraseña_perfil FROM Perfil WHERE id_perfil = p_id_perfil LIMIT 1;
END $$

-- 4.5. Obtener rol de perfil
DROP PROCEDURE IF EXISTS sp_get_rol_by_perfil $$
CREATE PROCEDURE sp_get_rol_by_perfil(IN p_id_perfil INT)
READS SQL DATA
BEGIN
    SELECT rol FROM Perfil WHERE id_perfil = p_id_perfil LIMIT 1;
END $$

-- 4.6. Cambiar rol de perfil
DROP PROCEDURE IF EXISTS sp_cambiar_rol_perfil $$
CREATE PROCEDURE sp_cambiar_rol_perfil(
    IN p_id_perfil INT,
    IN p_id_familia INT,
    IN p_nuevo_rol VARCHAR(50),
    OUT p_resultado INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil 
    SET rol = p_nuevo_rol 
    WHERE id_perfil = p_id_perfil AND id_familia_Familia = p_id_familia;
    
    SET p_resultado = IF(ROW_COUNT() > 0, 1, 0);
END $$

-- 4.7. Obtener estado del perfil
DROP PROCEDURE IF EXISTS sp_get_estado_perfil $$
CREATE PROCEDURE sp_get_estado_perfil(IN p_id_perfil INT, IN p_id_familia INT)
READS SQL DATA
BEGIN
    SELECT estado FROM Perfil WHERE id_perfil = p_id_perfil AND id_familia_Familia = p_id_familia LIMIT 1;
END $$

-- 4.8. Actualizar estado del perfil
DROP PROCEDURE IF EXISTS sp_update_perfil_estado $$
CREATE PROCEDURE sp_update_perfil_estado(
    IN p_id_perfil INT,
    IN p_id_familia INT,
    IN p_estado VARCHAR(50),
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil SET estado = p_estado WHERE id_perfil = p_id_perfil AND id_familia_Familia = p_id_familia;
    SET p_result = ROW_COUNT();
END $$

-- 4.9. Contar admins en familia
DROP PROCEDURE IF EXISTS sp_count_admins_in_family $$
CREATE PROCEDURE sp_count_admins_in_family(IN p_id_familia INT)
READS SQL DATA
BEGIN
    SELECT COUNT(*) AS c FROM Perfil WHERE id_familia_Familia = p_id_familia AND LOWER(rol) IN ('admin','administrador') AND estado = 'Habilitado';
END $$

-- 4.10. Actualizar nombre de perfil (alias)
DROP PROCEDURE IF EXISTS sp_update_perfil_nombre $$
CREATE PROCEDURE sp_update_perfil_nombre(
    IN p_id_perfil INT,
    IN p_nombre VARCHAR(255),
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil SET nombre_perfil = p_nombre WHERE id_perfil = p_id_perfil;
    SET p_result = ROW_COUNT();
END $$

-- 4.11. Actualizar contraseña de perfil (alias)
DROP PROCEDURE IF EXISTS sp_update_perfil_password $$
CREATE PROCEDURE sp_update_perfil_password(
    IN p_id_perfil INT,
    IN p_hash VARCHAR(255),
    OUT p_result INT
)
MODIFIES SQL DATA
BEGIN
    UPDATE Perfil SET contraseña_perfil = p_hash WHERE id_perfil = p_id_perfil;
    SET p_result = ROW_COUNT();
END $$

-- 4.12. Obtener perfil por nombre en familia
DROP PROCEDURE IF EXISTS sp_get_perfil_por_nombre_en_familia $$
CREATE PROCEDURE sp_get_perfil_por_nombre_en_familia(IN p_id_familia INT, IN p_nombre VARCHAR(255))
READS SQL DATA
BEGIN
    SELECT id_perfil FROM Perfil WHERE id_familia_Familia = p_id_familia AND nombre_perfil = p_nombre LIMIT 1;
END $$

-- ================================================================================
-- 5. PROCEDIMIENTOS PARA GESTIÓN DE FAMILIA
-- ================================================================================

-- 5.1. Obtener familia por nombre
DROP PROCEDURE IF EXISTS sp_get_familia_by_name $$
CREATE PROCEDURE sp_get_familia_by_name(IN p_nombre VARCHAR(255))
READS SQL DATA
BEGIN
    SELECT id_familia, contraseña_familia FROM Familia WHERE nombre_familia = p_nombre LIMIT 1;
END $$

-- ================================================================================
-- 6. PROCEDIMIENTOS PARA RECORDATORIOS
-- ================================================================================

-- 6.1. Obtener recordatorios por perfil (alias)
DROP PROCEDURE IF EXISTS sp_get_recordatorios_por_perfil $$
CREATE PROCEDURE sp_get_recordatorios_por_perfil(IN p_id_perfil INT)
READS SQL DATA
BEGIN
    SELECT * FROM recordatorio WHERE id_perfil_Perfil = p_id_perfil ORDER BY fecha_inicio ASC;
END $$

-- 6.2. Obtener recordatorio por ID
DROP PROCEDURE IF EXISTS sp_get_recordatorio_por_id $$
CREATE PROCEDURE sp_get_recordatorio_por_id(IN p_id_recordatorio INT, IN p_id_perfil INT)
READS SQL DATA
BEGIN
    SELECT id_recordatorio FROM recordatorio WHERE id_recordatorio = p_id_recordatorio AND id_perfil_Perfil = p_id_perfil LIMIT 1;
END $$

-- 6.3. Insertar recordatorio
DROP PROCEDURE IF EXISTS sp_insert_recordatorio $$
CREATE PROCEDURE sp_insert_recordatorio(
    IN p_id_perfil INT,
    IN p_id_familia INT,
    IN p_nombre VARCHAR(255),
    IN p_fecha_inicio DATE,
    IN p_periodo VARCHAR(50)
)
MODIFIES SQL DATA
BEGIN
    INSERT INTO recordatorio (id_perfil_Perfil, id_familia_Familia_Perfil, nombre_recordatorio, fecha_creacion, fecha_inicio, periodo)
    VALUES (p_id_perfil, p_id_familia, p_nombre, NOW(), p_fecha_inicio, p_periodo);
    SELECT ROW_COUNT() AS affected_rows;
END $$

-- 6.4. Eliminar recordatorio (alias)
DROP PROCEDURE IF EXISTS sp_delete_recordatorio $$
CREATE PROCEDURE sp_delete_recordatorio(
    IN p_id_recordatorio INT,
    IN p_id_perfil INT
)
MODIFIES SQL DATA
BEGIN
    DELETE FROM recordatorio WHERE id_recordatorio = p_id_recordatorio AND id_perfil_Perfil = p_id_perfil;
    SELECT ROW_COUNT() AS affected_rows;
END $$

-- ================================================================================
-- 7. PROCEDIMIENTOS AUXILIARES
-- ================================================================================

-- 7.1. Obtener perfiles con transacciones en una fecha
DROP PROCEDURE IF EXISTS sp_get_perfiles_with_transactions_on_date $$
CREATE PROCEDURE sp_get_perfiles_with_transactions_on_date(IN p_fecha DATE)
READS SQL DATA
BEGIN
    SELECT DISTINCT t.id_perfil_Perfil AS id_perfil FROM Transaccion t WHERE DATE(t.fecha) = p_fecha;
END $$

-- 7.2. Verificar si columna estado existe en tabla Perfil
DROP PROCEDURE IF EXISTS sp_check_estado_column_in_Perfil $$
CREATE PROCEDURE sp_check_estado_column_in_Perfil()
READS SQL DATA
BEGIN
    SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Perfil' AND COLUMN_NAME = 'estado';
END $$

-- ================================================================================
-- FIN DE PROCEDIMIENTOS
-- ================================================================================

DELIMITER ;

-- Verificación: Listar todos los procedimientos creados
SHOW PROCEDURE STATUS WHERE Db = DATABASE();
