<?php
/**
 * conexion.php
 * ================================================================================
 * ARCHIVO DE CONEXIÓN A LA BASE DE DATOS
 * 
 * Este archivo configura la conexión a MySQL usando mysqli (extensión mejorada).
 * Se incluye al inicio de casi todos los scripts PHP para tener acceso a la BD.
 * 
 * VARIABLES GLOBALES:
 *  - $conexion (mysqli): Instancia de conexión a la BD. Si falla, termina la ejecución.
 * 
 * USO:
 *  - En cualquier script: include("conexion.php");
 *  - Luego usar: $conexion->prepare(), ->bind_param(), ->execute(), etc.
 * 
 * CONFIGURACIÓN:
 *  - Host: localhost (servidor local XAMPP)
 *  - Usuario: root (usuario por defecto de phpMyAdmin)
 *  - Contraseña: vacía (configuración local)
 *  - Base de datos: famcash_db (debe existir previamente)
 *  - Charset: UTF-8 (para caracteres especiales)
 * ================================================================================
 */

// Credenciales y parámetros de conexión
$host = "localhost";        // Dirección del servidor MySQL
$usuario = "root";          // Usuario de MySQL (por defecto en XAMPP)
$contrasena = "";           // Contraseña (vacía en entorno local)
$base_datos = "famcash_db"; // Nombre de la base de datos

/**
 * Crear conexión usando mysqli
 * mysqli es más seguro que mysql_* (deprecated) y permite prepared statements
 * que previenen inyección SQL.
 */
$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

/**
 * Verificar si la conexión fue exitosa.
 * Si hay error, mostrar mensaje y terminar la ejecución.
 */
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

/**
 * Establecer charset UTF-8 para la conexión.
 * Garantiza que caracteres especiales (acentos, ñ) se manejen correctamente.
 */
mysqli_set_charset($conexion, "utf8");
?>
