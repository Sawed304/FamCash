<?php
/**
 * conexion.php
 * ----------------
 * Configura y expone la conexión a la base de datos MySQL usando mysqli.
 * Variables de salida:
 *  - $conexion : instancia mysqli conectada o termina el script si falla.
 * Uso: include("conexion.php");
 */
$host = "localhost";
$usuario = "root"; // o tu usuario de phpMyAdmin
$contrasena = ""; // si no tienes contraseña, déjalo vacío
$base_datos = "famcash_db";

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

mysqli_set_charset($conexion, "utf8");
?>
