<?php
/**
 * balance.php
 * ----------------
 * Muestra balances por concepto y detalle de transacciones.
 * - Permite a administradores filtrar por perfil y ver la leyenda de perfiles.
 * - Los no-admin ven únicamente su propio balance (sin selector ni leyenda).
 * - Calcula resúmenes mensual y anual (suma separada de ingresos y egresos usando ABS(monto)).
 * Variables de sesión usadas: $_SESSION['perfil_id'], $_SESSION['perfil_nombre'], $_SESSION['id_familia'], $_SESSION['perfil_rol']
 */
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = $_SESSION["perfil_id"];
$nombrePerfil = $_SESSION["perfil_nombre"];

// perfil seleccionado (0 = todos)
$selectedPerfil = isset($_GET['perfil']) ? (int)$_GET['perfil'] : $idPerfil;

// obtener lista de perfiles para el filtro (perfiles pertenecientes a la familia en sesión)
$perfiles = [];
$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;

// Asumir columna estándar de familia en Perfil para evitar SELECT directo a INFORMATION_SCHEMA
// Si su instalación usa otro nombre, actualice este valor manualmente.
$perfilFamiliaCol = 'id_familia_Familia';

if ($idFamilia !== null) {
    // Usar procedimiento almacenado para obtener perfiles
    $stmtPer = $conexion->prepare("CALL sp_get_perfiles_familia(?)");
    if ($stmtPer) {
        $stmtPer->bind_param('i', $idFamilia);
        $stmtPer->execute();
        $resPerfiles = $stmtPer->get_result();
        if ($resPerfiles) {
            while ($p = $resPerfiles->fetch_assoc()) {
                $perfiles[] = array('idPerfil' => $p['id_perfil'], 'nombre' => $p['nombre_perfil']);
            }
        }
        $stmtPer->close();
    }
} else {
    // fallback: dejar $perfiles vacío si no hay id_familia en sesión
    $perfiles = [];
}

/**
 * Obtiene el tamaño del vector de perfiles existentes
 * Diccionario UML: obtenerTamaño(in colecciónPerfiles:int) : int
 */
function obtenerTamaño($coleccionPerfiles) {
    return count($coleccionPerfiles);
}

// Usar la función para obtener el tamaño real
$tamañoVectorPerfilesExistentes = obtenerTamaño($perfiles);

// idUsuario (si existe) — mantener compatibilidad con instalaciones que usan idUsuario
$idUsuario = isset($_SESSION['idUsuario']) ? (int)$_SESSION['idUsuario'] : null;

// comprobar rol del perfil en sesión (si es Administrador)
$isAdmin = false;
// Preferir el rol almacenado en la sesión si existe (más fiable y evita consultas extra)
if (isset($_SESSION['perfil_rol'])) {
    $isAdmin = in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin', 'administrador']);
} else {
    // Obtener rol vía procedimiento almacenado para evitar SELECT directo
    $stmtRol = $conexion->prepare("CALL sp_get_rol_by_perfil(?)");
    if ($stmtRol) {
        $stmtRol->bind_param('i', $idPerfil);
        $stmtRol->execute();
        $resRol = $stmtRol->get_result();
        if ($resRol && $rrole = $resRol->fetch_assoc()) {
            $isAdmin = in_array(strtolower(trim($rrole['rol'])), ['admin', 'administrador']);
        }
        $stmtRol->close();
    }
}

// Si no es admin, forzar que sólo vea su propio perfil
if (! $isAdmin) {
    $selectedPerfil = $idPerfil;
    // filtrar $perfiles para dejar sólo el actual
    $perfiles = array_values(array_filter($perfiles, function($pp) use ($idPerfil) { return (int)$pp['idPerfil'] === (int)$idPerfil; }));
}

// asignar colores a perfiles para la leyenda (rotar una paleta)
$perfilColors = [];
$palette = ['#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#46f0f0','#f032e6','#bcf60c','#fabebe'];
$idx = 0;
foreach ($perfiles as $p) {
    $perfilColors[(int)$p['idPerfil']] = $palette[$idx % count($palette)];
    $idx++;
}

// Fecha seleccionada para filtro (por GET o hoy)
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
$year = date('Y', strtotime($fechaSeleccionada));
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));
$startYear = $year . '-01-01';

// ================================================================================
// CONSULTA DE TRANSACCIONES DEL DÍA - CORREGIDA
// ================================================================================

// Obtener transacciones del día (para detalle por concepto)
$transactionsByConcept = [];
$profileNames = [];
$profileFilter = null;

// CORRECCIÓN: Permitir que "Todos" (0) funcione correctamente
if (!empty($isAdmin) && $isAdmin) {
    if ($selectedPerfil !== 0) $profileFilter = (int)$selectedPerfil;
    // Si selectedPerfil es 0, profileFilter permanece null para incluir todos
} else {
    $profileFilter = (int)$idPerfil;
}

// Usar stored procedure para obtener transacciones detalle
$stmtAllTrans = $conexion->prepare("CALL sp_get_transacciones_detalle(?, ?, ?)");
if ($stmtAllTrans) {
    // sp_get_transacciones_detalle(IN p_id_familia INT, IN p_id_perfil INT, IN p_fecha DATE)
    // Tipos: int, int, string
    $stmtAllTrans->bind_param('iis', $idFamilia, $profileFilter, $fechaSeleccionada);
    $stmtAllTrans->execute();
    $resAllTrans = $stmtAllTrans->get_result();
    while ($rt = $resAllTrans->fetch_assoc()) {
        $cid = (int)$rt['id_concepto'];
        if (!isset($transactionsByConcept[$cid])) $transactionsByConcept[$cid] = [];
        $transactionsByConcept[$cid][] = $rt;
        $pid = (int)$rt['perfil_id'];
        if (!isset($profileNames[$pid])) $profileNames[$pid] = $rt['nombre_perfil'];
    }
    $stmtAllTrans->close();
}

// Build or extend perfilColors using profiles found (fallback palette)
$palette = ['#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#46f0f0','#f032e6','#bcf60c','#fabebe'];
$idx = 0;
foreach ($profileNames as $pid => $pname) {
    if (!isset($perfilColors[$pid])) {
        $perfilColors[$pid] = $palette[$idx % count($palette)];
        $idx++;
    }
}

// ================================================================================
// CONSULTA DE CONCEPTOS Y TOTALES PARA LA FECHA - CORREGIDA
// ================================================================================

// Traer conceptos y totales para la fecha exacta usando stored procedure
// Usar sp_get_balance_por_concepto
$stmt = $conexion->prepare("CALL sp_get_balance_por_concepto(?, ?, ?)");
if ($stmt) {
    $selectedPerfilFilter = ($selectedPerfil !== 0) ? $selectedPerfil : NULL;
    // sp_get_balance_por_concepto(IN p_id_familia INT, IN p_id_perfil INT, IN p_fecha DATE)
    $stmt->bind_param('iis', $idFamilia, $selectedPerfilFilter, $fechaSeleccionada);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} else {
    $result = false;
    error_log("Error en la preparación del procedimiento de balance por concepto");
}

$ingresos = [];
$egresos = [];
$totalIngresos = 0;
$totalEgresos = 0;

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $conceptId = $row['idConcepto'];
        $nombre = $row['nombre'];
        $tipo = $row['tipo'];
        $total = (float)$row['total'];
        $contribuidor = isset($row['contribuidor']) ? (int)$row['contribuidor'] : null;

        // GARANTIZAR QUE LOS INGRESOS NUNCA SEAN NEGATIVOS
        if (strtolower($tipo) === 'ingreso') {
            $total = abs($total); // Valor absoluto para ingresos
        }

        $entry = ['idConcepto' => $conceptId, 'nombre' => $nombre, 'tipo' => $tipo, 'total' => $total, 'contribuidor' => $contribuidor];

        if (strtolower($tipo) === 'ingreso') {
            $ingresos[$conceptId][] = $entry;
            $totalIngresos += $total;
        } else {
            $egresos[$conceptId][] = $entry;
            $totalEgresos += $total;
        }
    }
}

// Asegurar que el total de ingresos no sea negativo
$totalIngresos = abs($totalIngresos);

// Reagrupar por concepto para renderizado: sumar totales por concepto y listar perfiles contribuyentes
$ingresos_list = [];
foreach ($ingresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        // GARANTIZAR VALORES POSITIVOS PARA INGRESOS
        $positiveAmount = abs((float)$e['total']);
        $sum += $positiveAmount;
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $ingresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

$egresos_list = [];
foreach ($egresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        $sum += abs((float)$e['total']); // Egresos también en valor absoluto para consistencia
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $egresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

// Detectar si hay transacciones en la fecha seleccionada que pertenecen a otros perfiles
$hasOtherProfiles = false;
$otherProfiles = [];
if ($selectedPerfil !== 0) {
    // Usar procedimiento almacenado que devuelve perfiles con transacciones en la fecha
    $stmtOther = $conexion->prepare("CALL sp_get_perfiles_with_transactions_on_date(?)");
    if ($stmtOther) {
        $stmtOther->bind_param('s', $fechaSeleccionada);
        $stmtOther->execute();
        $resOther = $stmtOther->get_result();
        if ($resOther) {
            while ($op = $resOther->fetch_assoc()) {
                $pid = (int)$op['id_perfil'];
                if ($pid !== $selectedPerfil) {
                    $hasOtherProfiles = true;
                    $otherProfiles[] = $pid;
                }
            }
        }
        $stmtOther->close();
    }
}

// ================================================================================
// CÁLCULO DE BALANCES MENSUAL Y ANUAL - PARA TODA LA FAMILIA
// ================================================================================

// Calcular totales mensuales y anuales usando procedimiento almacenado (evita concatenación dinámica)
$monthlyIncome = 0; $monthlyExpense = 0;
$annualIncome = 0; $annualExpense = 0;

// Mes
$stmtRange = $conexion->prepare("CALL sp_get_totals_range(?, ?, ?)");
if ($stmtRange) {
    $stmtRange->bind_param('iss', $idFamilia, $startMonth, $fechaSeleccionada);
    $stmtRange->execute();
    $resMonth = $stmtRange->get_result();
    if ($resMonth) {
        $r = $resMonth->fetch_assoc();
        $monthlyIncome = (float)($r['ingresos'] ?? 0);
        $monthlyExpense = (float)($r['egresos'] ?? 0);
    }
    $stmtRange->close();
}

// Año
$stmtRange = $conexion->prepare("CALL sp_get_totals_range(?, ?, ?)");
if ($stmtRange) {
    $stmtRange->bind_param('iss', $idFamilia, $startYear, $fechaSeleccionada);
    $stmtRange->execute();
    $resYear = $stmtRange->get_result();
    if ($resYear) {
        $r = $resYear->fetch_assoc();
        $annualIncome = (float)($r['ingresos'] ?? 0);
        $annualExpense = (float)($r['egresos'] ?? 0);
    }
    $stmtRange->close();
}

// Calcular resúmenes (igual que en entrada_diaria.php)
$year_sum = $annualIncome - $annualExpense;
$month_sum = $monthlyIncome - $monthlyExpense;
$month_display = max($month_sum, 0.0);

// Pasar datos a JS
$perfilColorsJSON = json_encode($perfilColors);
$perfilesJSON = json_encode($perfiles);
// Helper para mostrar fechas en formato legible en español
function fecha_legible($fecha) {
    if (empty($fecha)) return '';
    try {
        $dt = new DateTime($fecha);
    } catch (Exception $e) {
        return htmlspecialchars($fecha);
    }
    $meses = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    $dia = $dt->format('j');
    $mes = $meses[(int)$dt->format('n') - 1];
    $ano = $dt->format('Y');
    return $dia . ' de ' . $mes . ' de ' . $ano;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Balance</title>
    <link rel="stylesheet" href="css/balance.css">
  
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
            <button class="menu-btn active" >Balance</button>
            <div class="dropdown">
                <button class="menu-btn">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="gestionar_concepto.php">Config. de Conceptos</a>
                    <a href="configuracion_perfil.php">Config. Perfil</a>
                    <?php if ($isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php else: ?>
                        
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <div class="container">
        <h2>Balance - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

        <!-- Resumen superior destacado (FIJO) -->
        <div class="top-summary">
            <div class="box">
                <div class="title">Balance Mensual</div>
                <div class="value <?php echo ($month_sum < 0) ? 'negativo' : 'positivo'; ?>"><?php echo 'S/'.number_format($month_sum,2,'.',''); ?></div>
                <div class="small"><?php echo fecha_legible($startMonth); ?> — <?php echo fecha_legible($fechaSeleccionada); ?></div>
            </div>
            <div class="box">
                <div class="title">Balance Anual</div>
                <div class="value <?php echo ($year_sum < 0) ? 'negativo' : 'positivo'; ?>"><?php echo 'S/'.number_format($year_sum,2,'.',''); ?></div>
                <div class="small"><?php echo fecha_legible($startYear); ?> — <?php echo fecha_legible($fechaSeleccionada); ?></div>
            </div>
        </div>

    
        <?php if ($isAdmin): ?>
        <div class="filtro">
            <label for="perfil">Ver balance de: </label>
            <select id="perfil" name="perfil">
                <option value="0" <?php echo ($selectedPerfil === 0) ? 'selected' : ''; ?>>Todos</option>
                <?php foreach ($perfiles as $p): ?>
                    <option value="<?php echo (int)$p['idPerfil']; ?>" <?php echo ($selectedPerfil === (int)$p['idPerfil']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($p['nombre']); ?></option>
                <?php endforeach; ?>
            </select>
            <span class="dot" style="background: <?php echo $perfilColors[$selectedPerfil] ?? '#999'; ?>;" title="<?php echo ($selectedPerfil === 0) ? 'Todos los perfiles' : htmlspecialchars($profileNames[$selectedPerfil] ?? 'Perfil '.$selectedPerfil); ?>"></span>

            &nbsp;&nbsp;
            <label for="fechaFiltro">Fecha: </label>
            <input type="date" id="fechaFiltro" value="<?php echo $fechaSeleccionada; ?>">

            &nbsp;&nbsp;
        </div>
        <?php else: ?>
        <div class="filtro">
            <label>Ver balance de: </label>
            <strong><?php echo htmlspecialchars($nombrePerfil); ?></strong>
            &nbsp;&nbsp;
            <label for="fechaFiltro">Fecha: </label>
            <input type="date" id="fechaFiltro" value="<?php echo $fechaSeleccionada; ?>">
        </div>
        <?php endif; ?>

    

        <div class="balance-contenedor-results">
            <!-- INGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Ingresos</div>
                <div class="caja" id="ingresosCaja">
                    <?php if (empty($ingresos_list)): ?>
                        <div class="item" style="color:#666; font-style:italic;">
                            No hay ingresos registrados para esta fecha
                        </div>
                    <?php else: ?>
                        <?php foreach ($ingresos_list as $it): ?>
                            <div class="item">
                                <!-- CORRECCIÓN: Eliminado el bloque que mostraba nombres de perfiles entre paréntesis -->
                                <strong><?php echo htmlspecialchars($it['nombre']); ?></strong>
                                
                                <input type="text" value="<?php echo 'S/'.number_format($it['total'], 2, '.', ''); ?>" readonly>
                                
                                <?php $trans = $transactionsByConcept[$it['idConcepto']] ?? []; ?>
                                <?php if (!empty($trans)): ?>
                                    <details style="margin-top:6px;margin-left:22px;">
                                        <summary>Ver detalle (<?php echo count($trans); ?>)</summary>
                                        <ul style="list-style:none;padding-left:0;margin:8px 0;">
                                            <?php foreach ($trans as $t): ?>
                                                <li style="display:flex;align-items:center;gap:8px;padding:4px 0;">
                                                    <?php $ppid = (int)$t['perfil_id']; ?>
                                                    <span class="dot" style="background: <?php echo $perfilColors[$ppid] ?? '#999'; ?>;width:10px;height:10px;margin-right:6px;" title="<?php echo htmlspecialchars($profileNames[$ppid] ?? ('Perfil '.$ppid)); ?>"></span>
                                                    <span style="flex:1"><?php echo htmlspecialchars($t['detalle']); ?></span>
                                                    <span style="width:110px;text-align:right;">
                                                        <?php echo 'S/'.number_format(abs($t['monto']),2,'.',''); ?>
                                                    </span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </details>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo 'S/'.number_format($totalIngresos, 2, '.', ''); ?>" readonly></div>
            </div>

            <!-- EGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Egresos</div>
                <div class="caja" id="egresosCaja">
                    <?php if (empty($egresos_list)): ?>
                        <div class="item" style="color:#666; font-style:italic;">
                            No hay egresos registrados para esta fecha
                        </div>
                    <?php else: ?>
                        <?php foreach ($egresos_list as $it): ?>
                            <div class="item">
                                <!-- CORRECCIÓN: Eliminado el bloque que mostraba nombres de perfiles entre paréntesis -->
                                <strong><?php echo htmlspecialchars($it['nombre']); ?></strong>
                                
                                <input type="text" value="<?php echo 'S/'.number_format(abs($it['total']), 2, '.', ''); ?>" readonly>
                                
                                <?php $trans = $transactionsByConcept[$it['idConcepto']] ?? []; ?>
                                <?php if (!empty($trans)): ?>
                                    <details style="margin-top:6px;margin-left:22px;">
                                        <summary>Ver detalle (<?php echo count($trans); ?>)</summary>
                                        <ul style="list-style:none;padding-left:0;margin:8px 0;">
                                            <?php foreach ($trans as $t): ?>
                                                <li style="display:flex;align-items:center;gap:8px;padding:4px 0;">
                                                    <?php $ppid = (int)$t['perfil_id']; ?>
                                                    <span class="dot" style="background: <?php echo $perfilColors[$ppid] ?? '#999'; ?>;width:10px;height:10px;margin-right:6px;" title="<?php echo htmlspecialchars($profileNames[$ppid] ?? ('Perfil '.$ppid)); ?>"></span>
                                                    <span style="flex:1"><?php echo htmlspecialchars($t['detalle']); ?></span>
                                                    <span style="width:110px;text-align:right;"><?php echo 'S/'.number_format(abs($t['monto']),2,'.',''); ?></span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </details>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo 'S/'.number_format(abs($totalEgresos), 2, '.', ''); ?>" readonly></div>
            </div>
        </div>

        <!-- Resúmenes visibles arriba -->

        <!-- Leyenda Colapsable -->
        <?php if ($isAdmin): ?>
        <div class="leyenda-right" id="leyendaContainer">
            <div class="leyenda-header" id="leyendaHeader" style="cursor: pointer; user-select: none;" aria-expanded="true" onclick="toggleLeyenda()">
                <strong>▼ Perfiles (<?php echo $tamañoVectorPerfilesExistentes; ?>)</strong>
            </div>
            <div class="leyenda-list" id="leyendaList" style="display: block;">
                <?php foreach ($perfiles as $p): ?>
                    <?php $pid = (int)$p['idPerfil']; ?>
                    <div class="leyenda-item"><span class="dot" style="background: <?php echo $perfilColors[$pid]; ?>"></span> <?php echo htmlspecialchars($p['nombre']); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="js/balance.js"></script>
    <script>
        // Pasar datos PHP a JavaScript
        const balanceData = {
            perfilColors: <?php echo $perfilColorsJSON; ?>,
            perfilesList: <?php echo $perfilesJSON; ?>,
            sessionPerfilId: <?php echo (int)$idPerfil; ?>,
            selectedPerfilInitial: <?php echo (int)$selectedPerfil; ?>,
            fechaInicial: "<?php echo $fechaSeleccionada; ?>",
            isAdmin: <?php echo $isAdmin ? 'true' : 'false'; ?>
        };
    </script>
</body>
</html>