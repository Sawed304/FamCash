<?php
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

 $idPerfil = $_SESSION["perfil_id"];
 $nombrePerfil = $_SESSION["perfil_nombre"];

// perfil seleccionado (0 = todos)
$selectedPerfil = isset($_GET['perfil']) ? (int)$_GET['perfil'] : $idPerfil;

// obtener lista de perfiles para el filtro
$perfiles = [];
$resPerfiles = $conexion->query("SELECT idPerfil, nombrePerfil AS nombre FROM perfiles");
if ($resPerfiles) {
    while ($p = $resPerfiles->fetch_assoc()) {
        $perfiles[] = $p;
    }
}

// comprobar rol del perfil en sesión (si es Administrador)
$stmtRol = $conexion->prepare("SELECT rol FROM perfiles WHERE idPerfil = ? LIMIT 1");
$stmtRol->bind_param('i', $idPerfil);
$stmtRol->execute();
$resRol = $stmtRol->get_result();
$isAdmin = false;
if ($resRol && $rrole = $resRol->fetch_assoc()) {
    $isAdmin = (strtolower($rrole['rol']) === 'administrador');
}

// Si no es admin, forzar que sólo vea su propio perfil
if (! $isAdmin) {
    $selectedPerfil = $idPerfil;
    // filtrar $perfiles para dejar sólo el actual
    $perfiles = array_values(array_filter($perfiles, function($pp) use ($idPerfil) { return (int)$pp['idPerfil'] === (int)$idPerfil; }));
}

// asignar colores a perfiles para la leyenda (rotar una paleta)
$perfilColors = [];
$palette = ['#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#46f0f0','#f032e6','#bcf60c','#fabebe'];
$idx = 0;
foreach ($perfiles as $p) {
    $perfilColors[(int)$p['idPerfil']] = $palette[$idx % count($palette)];
    $idx++;
}

// Obtenemos todos los conceptos de este perfil
// Fecha seleccionada para filtro (por GET o hoy)
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
$year = date('Y', strtotime($fechaSeleccionada));
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

// Traer conceptos y totales para el rango mensual (desde primer día del mes hasta fecha seleccionada)
// Para balance: mostrar solo conceptos que tienen transacción en la fecha seleccionada
// (comportamiento igual a entrada_diaria.php) y en modo lectura.
$sql = "SELECT c.idConcepto, c.nombre, c.tipo, t.idPerfil AS contribuidor, SUM(t.monto) AS total
    FROM conceptos c
    INNER JOIN transacciones t ON c.idConcepto = t.idConcepto AND DATE(t.fecha) = ?
    WHERE c.estado = 'Habilitado'";
if ($selectedPerfil !== 0) {
    $sql .= " AND c.idPerfil = ?";
}
 $sql .= " GROUP BY c.idConcepto, c.nombre, c.tipo, t.idPerfil ORDER BY c.tipo DESC, c.nombre";

 $stmt = $conexion->prepare($sql);
 if ($selectedPerfil !== 0) {
     $stmt->bind_param('si', $fechaSeleccionada, $selectedPerfil);
 } else {
     $stmt->bind_param('s', $fechaSeleccionada);
 }
 $stmt->execute();
 $result = $stmt->get_result();

 $ingresos = [];
 $egresos = [];
 $totalIngresos = 0;
 $totalEgresos = 0;

 // Como ahora la query agrupa por idConcepto y por contribuidor, podemos reunir por concepto
 while ($row = $result->fetch_assoc()) {
     $conceptId = $row['idConcepto'];
     $nombre = $row['nombre'];
     $tipo = $row['tipo'];
     $total = (float)$row['total'];
     $contribuidor = isset($row['contribuidor']) ? (int)$row['contribuidor'] : null;

     $entry = ['idConcepto' => $conceptId, 'nombre' => $nombre, 'tipo' => $tipo, 'total' => $total, 'contribuidor' => $contribuidor];

     if (strtolower($tipo) === 'ingreso') {
         $ingresos[$conceptId][] = $entry;
         $totalIngresos += $total;
     } else {
         $egresos[$conceptId][] = $entry;
         $totalEgresos += $total;
     }
 }

 $balanceAnual = $totalIngresos - $totalEgresos; // fallback per-profile simple balance
 $balanceMensual = $totalIngresos - $totalEgresos; // monthly shown is same range here

// Reagrupar por concepto para renderizado: sumar totales por concepto y listar perfiles contribuyentes
$ingresos_list = [];
foreach ($ingresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        $sum += (float)$e['total'];
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $ingresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

$egresos_list = [];
foreach ($egresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        $sum += (float)$e['total'];
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $egresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

// Detectar si hay transacciones en la fecha seleccionada que pertenecen a otros perfiles
$hasOtherProfiles = false;
$otherProfiles = [];
if ($selectedPerfil !== 0) {
    $stmtOther = $conexion->prepare("SELECT DISTINCT t.idPerfil FROM transacciones t WHERE DATE(t.fecha) = ?");
    $stmtOther->bind_param('s', $fechaSeleccionada);
    $stmtOther->execute();
    $resOther = $stmtOther->get_result();
    if ($resOther) {
        while ($op = $resOther->fetch_assoc()) {
            $pid = (int)$op['idPerfil'];
            if ($pid !== $selectedPerfil) {
                $hasOtherProfiles = true;
                $otherProfiles[] = $pid;
            }
        }
    }
}

// Calcular balance anual y mensual (usar fecha seleccionada del input o hoy)
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
$year = date('Y', strtotime($fechaSeleccionada));
$startYear = $year . '-01-01';
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

$sqlRange = "SELECT
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN t.monto ELSE 0 END),0) AS ingresos,
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN t.monto ELSE 0 END),0) AS egresos
FROM transacciones t
JOIN conceptos c ON t.idConcepto = c.idConcepto
WHERE DATE(t.fecha) BETWEEN ? AND ?";

$stmtRange = $conexion->prepare($sqlRange);
$stmtRange->bind_param('ss', $startYear, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
$annualIncome = 0; $annualExpense = 0;
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $annualIncome = (float)$r['ingresos'];
    $annualExpense = (float)$r['egresos'];
}

$stmtRange->bind_param('ss', $startMonth, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
$monthlyIncome = 0; $monthlyExpense = 0;
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $monthlyIncome = (float)$r['ingresos'];
    $monthlyExpense = (float)$r['egresos'];
}

$balanceAnualResumen = $annualIncome - $annualExpense;
$balanceMensualResumen = $monthlyIncome - $monthlyExpense;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Balance</title>
    <link rel="stylesheet" href="css/balance.css">
    <style>
        .dot { display:inline-block; width:12px; height:12px; border-radius:50%; margin-right:6px; vertical-align:middle; }
        .perfil-leyenda { margin-left:8px; margin-right:8px; }
        .concepto-dots { margin-right:8px; }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
            <button class="menu-btn active" onclick="location.href='balance.php'">Balance</button>
            <div class="dropdown">
                <button class="menu-btn">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="#">Config. de Conceptos</a>
                    <a href="#">Config. Perfil</a>
                    <a href="#">Config. Perfiles Familiares</a>
                </div>
            </div>
        </nav>
    </header>


    <div class="container">
        <h2>Balance - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

        <!-- Filtro de perfiles -->
        <div class="filtro">
            <label for="perfil">Ver balance de: </label>
            <select id="perfil" name="perfil" onchange="location.href='balance.php?perfil=' + this.value + '&fecha=' + encodeURIComponent('<?php echo $fechaSeleccionada; ?>')">
                <option value="0" <?php echo ($selectedPerfil === 0) ? 'selected' : ''; ?>>Todos</option>
                <?php foreach ($perfiles as $p): ?>
                    <option value="<?php echo (int)$p['idPerfil']; ?>" <?php echo ($selectedPerfil === (int)$p['idPerfil']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($p['nombre']); ?></option>
                <?php endforeach; ?>
            </select>
            &nbsp;&nbsp;
            <label for="fechaFiltro">Fecha: </label>
            <input type="date" id="fechaFiltro" value="<?php echo $fechaSeleccionada; ?>" onchange="location.href='balance.php?perfil=' + <?php echo (int)$selectedPerfil; ?> + '&fecha=' + this.value">
        </div>

        
        
        <!-- RESULTADOS DINÁMICOS -->
        <?php if ($selectedPerfil !== 0 && empty($ingresos_list) && empty($egresos_list) && $hasOtherProfiles): ?>
            <div class="info-banner" style="background:#fff3cd;border:1px solid #ffeeba;padding:10px;margin-bottom:12px;border-radius:6px;">
                No se encontraron conceptos para el perfil seleccionado en esta fecha, pero hay transacciones de otros perfiles. <a href="balance.php?perfil=0&fecha=<?php echo urlencode($fechaSeleccionada); ?>">Ver todos</a>
            </div>
        <?php endif; ?>
        <div class="balance-contenedor-results">
            <!-- INGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Ingresos</div>
                <div class="caja">
                    <?php foreach ($ingresos_list as $it): ?>
                        <div class="item"><span class="concepto-dots">
                            <?php foreach ($it['contribuidores'] as $pc): ?>
                                <?php $pcid = (int)$pc; ?>
                                <span class="dot" style="background: <?php echo isset($perfilColors[$pcid]) ? $perfilColors[$pcid] : '#999'; ?>"></span>
                            <?php endforeach; ?>
                        </span><?php echo htmlspecialchars($it['nombre']); ?>: <input type="text" value="<?php echo number_format($it['total'], 2, '.', ''); ?>" readonly></div>
                    <?php endforeach; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo number_format($totalIngresos, 2, '.', ''); ?>" readonly></div>
            </div>

            <!-- EGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Egresos</div>
                <div class="caja">
                    <?php foreach ($egresos_list as $it): ?>
                        <div class="item"><span class="concepto-dots">
                            <?php foreach ($it['contribuidores'] as $pc): ?>
                                <?php $pcid = (int)$pc; ?>
                                <span class="dot" style="background: <?php echo isset($perfilColors[$pcid]) ? $perfilColors[$pcid] : '#999'; ?>"></span>
                            <?php endforeach; ?>
                        </span><?php echo htmlspecialchars($it['nombre']); ?>: <input type="text" value="<?php echo number_format($it['total'], 2, '.', ''); ?>" readonly></div>
                    <?php endforeach; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo number_format($totalEgresos, 2, '.', ''); ?>" readonly></div>
            </div>
        </div>

        <!-- RESUMEN -->
        <div class="resumen">
            <div>Resumen del balance ahorrado anual: <input type="text" value="<?php echo number_format($balanceAnualResumen, 2, '.', ''); ?>" readonly></div>
            <div>Resumen del balance restante mensual: <input type="text" value="<?php echo number_format($balanceMensualResumen, 2, '.', ''); ?>" readonly></div>
        </div>
        
        <!-- Leyenda movida a la parte inferior derecha -->
        <div class="leyenda-right">
            <strong>Perfiles</strong>
            <div class="leyenda-list">
                <?php foreach ($perfiles as $p): ?>
                    <?php $pid = (int)$p['idPerfil']; ?>
                    <div class="leyenda-item"><span class="dot" style="background: <?php echo $perfilColors[$pid]; ?>"></span> <?php echo htmlspecialchars($p['nombre']); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>
