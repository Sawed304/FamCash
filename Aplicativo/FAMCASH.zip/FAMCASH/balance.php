<?php
/**
 * balance.php
 * ----------------
 * Muestra balances por concepto y detalle de transacciones.
 * - Permite a administradores filtrar por perfil y ver la leyenda de perfiles.
 * - Los no-admin ven únicamente su propio balance (sin selector ni leyenda).
 * - Calcula resúmenes mensual y anual (suma separada de ingresos y egresos usando ABS(monto)).
 * Variables de sesión usadas: $_SESSION['perfil_id'], $_SESSION['perfil_nombre'], $_SESSION['id_familia'], $_SESSION['perfil_rol']
 */
session_start();
include("conexion.php");


//Dudas 
if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}
//Dudas 




$idPerfil = $_SESSION["perfil_id"];
$nombrePerfil = $_SESSION["perfil_nombre"];





// perfil seleccionado (0 = todos)
$selectedPerfil = isset($_GET['perfil']) ? (int)$_GET['perfil'] : $idPerfil;

// obtener lista de perfiles para el filtro (perfiles pertenecientes a la familia en sesión)
$perfiles = [];
$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;
// Intentar detectar si la tabla Perfil tiene una columna que vincule a la familia
$perfilFamiliaCol = null;
$stmtCol = $conexion->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('Perfil','perfil') AND (COLUMN_NAME = 'id_familia_Familia' OR COLUMN_NAME = 'id_familia') LIMIT 1");
if ($stmtCol) {
    $stmtCol->execute();
    $resCol = $stmtCol->get_result();
    if ($resCol && $rc = $resCol->fetch_assoc()) {
        $perfilFamiliaCol = $rc['COLUMN_NAME'];
    }
}

if ($idFamilia !== null) {
    // Usar tabla Perfil con columnas id_perfil y nombre_perfil; filtrar por la columna detectada si existe
    if ($perfilFamiliaCol !== null) {
        $sqlPer = "SELECT id_perfil AS idPerfil, nombre_perfil AS nombre FROM Perfil WHERE " . $perfilFamiliaCol . " = ?";
        $stmtPer = $conexion->prepare($sqlPer);
        if ($stmtPer) {
            $stmtPer->bind_param('i', $idFamilia);
            $stmtPer->execute();
            $resPerfiles = $stmtPer->get_result();
            if ($resPerfiles) {
                while ($p = $resPerfiles->fetch_assoc()) {
                    $perfiles[] = $p;
                }
            }
        }
    } else {
        // Si no existe la columna de familia, traer todos los perfiles como fallback
        $stmtPer = $conexion->prepare("SELECT id_perfil AS idPerfil, nombre_perfil AS nombre FROM Perfil");
        if ($stmtPer) {
            $stmtPer->execute();
            $resPerfiles = $stmtPer->get_result();
            if ($resPerfiles) {
                while ($p = $resPerfiles->fetch_assoc()) {
                    $perfiles[] = $p;
                }
            }
        }
    }
} else {
    // fallback: dejar $perfiles vacío si no hay id_familia en sesión
    $perfiles = [];
}
/**
 * Obtiene el tamaño del vector de perfiles existentes
 * Diccionario UML: obtenerTamaño(in colecciónPerfiles:int) : int
 */
function obtenerTamaño($coleccionPerfiles) {
    return count($coleccionPerfiles);
}

// Usar la función para obtener el tamaño real
$tamañoVectorPerfilesExistentes = obtenerTamaño($perfiles);

// idUsuario (si existe) — mantener compatibilidad con instalaciones que usan idUsuario
$idUsuario = isset($_SESSION['idUsuario']) ? (int)$_SESSION['idUsuario'] : null;

// comprobar rol del perfil en sesión (si es Administrador)
$isAdmin = false;
// Preferir el rol almacenado en la sesión si existe (más fiable y evita consultas extra)
if (isset($_SESSION['perfil_rol'])) {
    $isAdmin = in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin', 'administrador']);
} else {
    // Intentar consultar desde la BD; aceptar 'admin' o 'administrador' (distintos installations)
    $stmtRol = $conexion->prepare("SELECT rol FROM Perfil WHERE id_perfil = ? LIMIT 1");
    if (! $stmtRol) {
        // fallback a posible nombre de tabla en minúsculas
        $stmtRol = $conexion->prepare("SELECT rol FROM perfil WHERE id_perfil = ? LIMIT 1");
    }
    if ($stmtRol) {
        $stmtRol->bind_param('i', $idPerfil);
        $stmtRol->execute();
        $resRol = $stmtRol->get_result();
        if ($resRol && $rrole = $resRol->fetch_assoc()) {
            $isAdmin = in_array(strtolower(trim($rrole['rol'])), ['admin', 'administrador']);
        }
    }
}




// Si no es admin, forzar que sólo vea su propio perfil
if (! $isAdmin) {
    $selectedPerfil = $idPerfil;
    // filtrar $perfiles para dejar sólo el actual
    $perfiles = array_values(array_filter($perfiles, function($pp) use ($idPerfil) { return (int)$pp['idPerfil'] === (int)$idPerfil; }));
}

// asignar colores a perfiles para la leyenda (rotar una paleta)
$perfilColors = [];
$palette = ['#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#46f0f0','#f032e6','#bcf60c','#fabebe'];
$idx = 0;
foreach ($perfiles as $p) {
    $perfilColors[(int)$p['idPerfil']] = $palette[$idx % count($palette)];
    $idx++;
}

// Fecha seleccionada para filtro (por GET o hoy)
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
$year = date('Y', strtotime($fechaSeleccionada));
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

// Obtener transacciones del día (para detalle por concepto)
$transactionsByConcept = [];
$profileNames = [];
$profileFilter = null;
// si no es admin, forzar filtro por el perfil en sesión; si se seleccionó un perfil distinto a 0, usarlo
if (!empty($isAdmin) && $isAdmin) {
    if ($selectedPerfil !== 0) $profileFilter = (int)$selectedPerfil;
} else {
    $profileFilter = (int)$idPerfil;
}

$stmtAllTransSql = "SELECT t.id_transaccion, t.monto, t.detalle, t.id_perfil_Perfil AS perfil_id, p.nombre_perfil, c.id_concepto FROM Transaccion t JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil WHERE DATE(t.fecha) = ?";
// Si el admin pide ver "todos" (selectedPerfil === 0) y tenemos id_familia disponible,
// limitar las transacciones a los perfiles de la misma familia usando la columna detectada en Perfil.
$needProfileFamilyFilter = ($idFamilia !== null && $perfilFamiliaCol !== null && ($selectedPerfil === 0));
if ($profileFilter !== null) {
    // se filtra por perfil específico (no por familia)
    $stmtAllTransSql .= " AND t.id_perfil_Perfil = ?";
} elseif ($needProfileFamilyFilter) {
    // agregar condición para limitar por familia (perfil)
    $stmtAllTransSql .= " AND p." . $perfilFamiliaCol . " = ?";
}

$stmtAllTrans = $conexion->prepare($stmtAllTransSql);
if ($stmtAllTrans) {
    if ($profileFilter !== null) {
        $stmtAllTrans->bind_param('si', $fechaSeleccionada, $profileFilter);
    } elseif ($needProfileFamilyFilter) {
        $stmtAllTrans->bind_param('si', $fechaSeleccionada, $idFamilia);
    } else {
        $stmtAllTrans->bind_param('s', $fechaSeleccionada);
    }
    $stmtAllTrans->execute();
    $resAllTrans = $stmtAllTrans->get_result();
    while ($rt = $resAllTrans->fetch_assoc()) {
        $cid = (int)$rt['id_concepto'];
        if (!isset($transactionsByConcept[$cid])) $transactionsByConcept[$cid] = [];
        $transactionsByConcept[$cid][] = $rt;
        $pid = (int)$rt['perfil_id'];
        if (!isset($profileNames[$pid])) $profileNames[$pid] = $rt['nombre_perfil'];
    }
} else {
    // no transacciones
}

// Build or extend perfilColors using profiles found (fallback palette)
$palette = ['#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#46f0f0','#f032e6','#bcf60c','#fabebe'];
$idx = 0;
foreach ($profileNames as $pid => $pname) {
    if (!isset($perfilColors[$pid])) {
        $perfilColors[$pid] = $palette[$idx % count($palette)];
        $idx++;
    }
}

// Traer conceptos y totales para la fecha exacta (ajustado al esquema usando tablas Concepto y Transaccion)
// Detectar si la tabla Concepto tiene columna de familia para filtrar
$conceptoFamiliaCol = null;
$stmtCol2 = $conexion->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('Concepto','concepto') AND (COLUMN_NAME = 'id_familia_Familia' OR COLUMN_NAME = 'id_familia') LIMIT 1");
if ($stmtCol2) {
    $stmtCol2->execute();
    $resCol2 = $stmtCol2->get_result();
    if ($resCol2 && $rc2 = $resCol2->fetch_assoc()) {
        $conceptoFamiliaCol = $rc2['COLUMN_NAME'];
    }
}

// Traer totales por concepto para la fecha, limitado a la familia cuando corresponda.
// Nota: para evitar incluir transacciones de otras familias se prefiere filtrar
// por la columna de familia en la tabla Perfil (si existe). Además usamos ABS(t.monto)
// para sumar montos independientemente del signo.
$sql = "SELECT c.id_concepto AS idConcepto, c.nombre_concepto AS nombre, c.tipo, SUM(ABS(t.monto)) AS total
    FROM Concepto c
    INNER JOIN Transaccion t ON c.id_concepto = t.id_concepto_Concepto AND DATE(t.fecha) = ?
    INNER JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil
    WHERE 1=1";

// Preferir filtrar por la columna de familia en Perfil (asegura que solo se consideren
// transacciones hechas por perfiles de la misma familia que el usuario en sesión).
$needPerfilFamilyFilter = false;
if ($perfilFamiliaCol !== null && $idFamilia !== null) {
    $sql .= " AND p." . $perfilFamiliaCol . " = ?";
    $needPerfilFamilyFilter = true;
}

// Si el selector pide un perfil específico, filtrar por ese perfil.
if ($selectedPerfil !== 0) {
    $sql .= " AND t.id_perfil_Perfil = ?";
}

// Agrupar solo por concepto (sumamos todos los montos dentro del filtro)
$sql .= " GROUP BY c.id_concepto, c.nombre_concepto, c.tipo ORDER BY c.tipo DESC, c.nombre_concepto";

$stmt = $conexion->prepare($sql);
if ($stmt) {
    // Construir bind según parámetros disponibles
    if ($needPerfilFamilyFilter && $selectedPerfil !== 0) {
        // fecha, idFamilia, selectedPerfil
        $stmt->bind_param('sii', $fechaSeleccionada, $idFamilia, $selectedPerfil);
    } elseif ($needPerfilFamilyFilter) {
        // fecha, idFamilia
        $stmt->bind_param('ss', $fechaSeleccionada, $idFamilia);
        // Note: bind_param types corrected below if necessary (see fallback)
        // But to be safe we use 'ss' then correct to proper types by re-preparing if needed.
        // (mysqli will coerce strings to ints if DB expects int; alternative is to build an explicit
        // parameter type string depending on variables — keep simple and consistent.)
    } elseif ($selectedPerfil !== 0) {
        $stmt->bind_param('si', $fechaSeleccionada, $selectedPerfil);
    } else {
        $stmt->bind_param('s', $fechaSeleccionada);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = false;
}

$ingresos = [];
$egresos = [];
$totalIngresos = 0;
$totalEgresos = 0;

while ($row = $result->fetch_assoc()) {
    $conceptId = $row['idConcepto'];
    $nombre = $row['nombre'];
    $tipo = $row['tipo'];
    $total = (float)$row['total'];
    $contribuidor = isset($row['contribuidor']) ? (int)$row['contribuidor'] : null;

    $entry = ['idConcepto' => $conceptId, 'nombre' => $nombre, 'tipo' => $tipo, 'total' => $total, 'contribuidor' => $contribuidor];

    if (strtolower($tipo) === 'ingreso') {
        $ingresos[$conceptId][] = $entry;
        $totalIngresos += $total;
    } else {
        $egresos[$conceptId][] = $entry;
        $totalEgresos += $total;
    }
}

$balanceAnual = $totalIngresos - $totalEgresos; // fallback simple
$balanceMensual = $totalIngresos - $totalEgresos;

// Reagrupar por concepto para renderizado: sumar totales por concepto y listar perfiles contribuyentes
$ingresos_list = [];
foreach ($ingresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        $sum += (float)$e['total'];
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $ingresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

$egresos_list = [];
foreach ($egresos as $cid => $entries) {
    $sum = 0.0;
    $contributors = [];
    foreach ($entries as $e) {
        $sum += (float)$e['total'];
        if (!empty($e['contribuidor'])) $contributors[] = (int)$e['contribuidor'];
    }
    $contributors = array_values(array_unique($contributors));
    $egresos_list[] = ['idConcepto' => $cid, 'nombre' => $entries[0]['nombre'], 'total' => $sum, 'contribuidores' => $contributors];
}

// Detectar si hay transacciones en la fecha seleccionada que pertenecen a otros perfiles
$hasOtherProfiles = false;
$otherProfiles = [];
if ($selectedPerfil !== 0) {
    // Obtener perfiles que tienen transacciones en la fecha (usar nombres reales de tabla/columnas)
    // Buscar perfiles que tienen transacciones en la fecha pero limitar a la familia si es posible
    if ($perfilFamiliaCol !== null && $idFamilia !== null) {
        $stmtOther = $conexion->prepare("SELECT DISTINCT t.id_perfil_Perfil AS id_perfil FROM Transaccion t JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil WHERE DATE(t.fecha) = ? AND p." . $perfilFamiliaCol . " = ?");
        if ($stmtOther) {
            $stmtOther->bind_param('si', $fechaSeleccionada, $idFamilia);
            $stmtOther->execute();
            $resOther = $stmtOther->get_result();
            if ($resOther) {
                while ($op = $resOther->fetch_assoc()) {
                    $pid = (int)$op['id_perfil'];
                    if ($pid !== $selectedPerfil) {
                        $hasOtherProfiles = true;
                        $otherProfiles[] = $pid;
                    }
                }
            }
        }
    } else {
        // Sin columna de familia, caer a comportamiento previo (no ideal, pero mantiene compatibilidad)
        $stmtOther = $conexion->prepare("SELECT DISTINCT t.id_perfil_Perfil AS id_perfil FROM Transaccion t WHERE DATE(t.fecha) = ?");
        if ($stmtOther) {
            $stmtOther->bind_param('s', $fechaSeleccionada);
            $stmtOther->execute();
            $resOther = $stmtOther->get_result();
            if ($resOther) {
                while ($op = $resOther->fetch_assoc()) {
                    $pid = (int)$op['id_perfil'];
                    if ($pid !== $selectedPerfil) {
                        $hasOtherProfiles = true;
                        $otherProfiles[] = $pid;
                    }
                }
            }
        }
    }
}

// Calcular balance anual y mensual (resumen)
$year = date('Y', strtotime($fechaSeleccionada));
$startYear = $year . '-01-01';
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

// Ajustar a tablas Transaccion/Concepto y filtrar por familia si corresponde
// Calcular resúmenes anual/mensual: filtrar por perfiles de la misma familia
$sqlRange = "SELECT
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto) ELSE 0 END),0) AS ingresos,
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN ABS(t.monto) ELSE 0 END),0) AS egresos
FROM Transaccion t
JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto
JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil";

// añadir filtro por familia en Perfil si la columna existe y tenemos idFamilia
$needFamilyFilter = false;
if ($perfilFamiliaCol !== null && $idFamilia !== null) {
    $sqlRange .= "\nWHERE p." . $perfilFamiliaCol . " = ?"; // añadiremos el BETWEEN después
    $needFamilyFilter = true;
}
if ($needFamilyFilter) {
    $sqlRange .= " AND DATE(t.fecha) BETWEEN ? AND ?";
} else {
    $sqlRange .= " WHERE DATE(t.fecha) BETWEEN ? AND ?";
}

$stmtRange = $conexion->prepare($sqlRange);
if ($stmtRange) {
    if ($needFamilyFilter) {
        // params: id_familia, start, end
        $stmtRange->bind_param('iss', $idFamilia, $startYear, $fechaSeleccionada);
    } else {
        $stmtRange->bind_param('ss', $startYear, $fechaSeleccionada);
    }
    $stmtRange->execute();
    $resRange = $stmtRange->get_result();
} else {
    $resRange = false;
}
$annualIncome = 0; $annualExpense = 0;
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $annualIncome = (float)$r['ingresos'];
    $annualExpense = (float)$r['egresos'];
}

$stmtRange = $conexion->prepare($sqlRange);
if ($stmtRange) {
    if ($needFamilyFilter) {
        $stmtRange->bind_param('iss', $idFamilia, $startMonth, $fechaSeleccionada);
    } else {
        $stmtRange->bind_param('ss', $startMonth, $fechaSeleccionada);
    }
    $stmtRange->execute();
    $resRange = $stmtRange->get_result();
} else {
    $resRange = false;
}
$monthlyIncome = 0; $monthlyExpense = 0;
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $monthlyIncome = (float)$r['ingresos'];
    $monthlyExpense = (float)$r['egresos'];
}

$year_sum = $annualIncome - $annualExpense;
$month_sum = $monthlyIncome - $monthlyExpense;
$month_display = max($month_sum, 0.0);

// Pasar datos a JS
$perfilColorsJSON = json_encode($perfilColors);
$perfilesJSON = json_encode($perfiles);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Balance</title>
    <link rel="stylesheet" href="css/balance.css">
    <style>
        /* pequeños ajustes locales */
        .dot { display:inline-block; width:12px; height:12px; border-radius:50%; margin-right:6px; vertical-align:middle; }
        .perfil-leyenda { margin-left:8px; margin-right:8px; }
        .concepto-dots { margin-right:8px; }
        /* indicador pequeño cerca del selector */
        #perfilIndicator { display:inline-block; width:14px; height:14px; border-radius:50%; margin-left:8px; vertical-align:middle; border:1px solid rgba(0,0,0,0.08); }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
            <button class="menu-btn active" >Balance</button>
            <div class="dropdown">
                <button class="menu-btn">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="#">Config. de Conceptos</a>
                    <a href="configuracion_perfil.php">Config. Perfil</a>
                    <?php if ($isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php else: ?>
                        <span style="display:block;padding:8px 12px;color:#666;font-size:0.9em;">(Acceso sólo Administrador)</span>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <div class="container">
        <h2>Balance - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

        <!-- Filtro de perfiles -->
        <?php if ($isAdmin): ?>
        <div class="filtro">
            <label for="perfil">Ver balance de: </label>
            <select id="perfil" name="perfil" onchange="seleccionarPerfilEspecífico(this.value)">
                <option value="0" <?php echo ($selectedPerfil === 0) ? 'selected' : ''; ?>>Todos</option>
                <?php foreach ($perfiles as $p): ?>
                    <option value="<?php echo (int)$p['idPerfil']; ?>" <?php echo ($selectedPerfil === (int)$p['idPerfil']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($p['nombre']); ?></option>
                <?php endforeach; ?>
            </select>
            <span id="perfilIndicator" title="Color del perfil"></span>

            &nbsp;&nbsp;
            <label for="fechaFiltro">Fecha: </label>
            <input type="date" id="fechaFiltro" value="<?php echo $fechaSeleccionada; ?>" onchange="presionarCambiarFecha(true)">

            &nbsp;&nbsp;
            <button class="menu-btn" onclick="mostrarBalanceGeneral(document.getElementById('fechaFiltro').value, 0, <?php echo (int)$idPerfil; ?>)">Ver general</button>
        </div>
        <?php else: ?>
        <div class="filtro">
            <label>Ver balance de: </label>
            <strong><?php echo htmlspecialchars($nombrePerfil); ?></strong>
            &nbsp;&nbsp;
            <label for="fechaFiltro">Fecha: </label>
            <input type="date" id="fechaFiltro" value="<?php echo $fechaSeleccionada; ?>" onchange="presionarCambiarFecha(true)">
        </div>
        <?php endif; ?>

        <!-- Si no hay conceptos para el perfil seleccionado pero hay otros perfiles con transacciones -->
        <?php if ($isAdmin && $selectedPerfil !== 0 && empty($ingresos_list) && empty($egresos_list) && $hasOtherProfiles): ?>
            <div class="info-banner" style="background:#fff3cd;border:1px solid #ffeeba;padding:10px;margin-bottom:12px;border-radius:6px;">
                No se encontraron conceptos para el perfil seleccionado en esta fecha, pero hay transacciones de otros perfiles. <a href="balance.php?perfil=0&fecha=<?php echo urlencode($fechaSeleccionada); ?>">Ver todos</a>
            </div>
        <?php endif; ?>

        <div class="balance-contenedor-results">
            <!-- INGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Ingresos</div>
                <div class="caja" id="ingresosCaja">
                    <?php foreach ($ingresos_list as $it): ?>
                        <div class="item">
                            <?php echo htmlspecialchars($it['nombre']); ?>:
                            <input type="text" value="<?php echo number_format($it['total'], 2, '.', ''); ?>" readonly>
                            <?php $trans = $transactionsByConcept[$it['idConcepto']] ?? []; ?>
                            <?php if (!empty($trans)): ?>
                                <details style="margin-top:6px;margin-left:22px;">
                                    <summary>Ver detalle (<?php echo count($trans); ?>)</summary>
                                    <ul style="list-style:none;padding-left:0;margin:8px 0;">
                                        <?php foreach ($trans as $t): ?>
                                            <li style="display:flex;align-items:center;gap:8px;padding:4px 0;">
                                                <?php $ppid = (int)$t['perfil_id']; ?>
                                                <span class="dot" style="background: <?php echo $perfilColors[$ppid] ?? '#999'; ?>;width:10px;height:10px;margin-right:6px;" title="<?php echo htmlspecialchars($profileNames[$ppid] ?? ('Perfil '.$ppid)); ?>"></span>
                                                <span style="flex:1"><?php echo htmlspecialchars($t['detalle']); ?></span>
                                                <span style="width:110px;text-align:right;"><?php echo number_format($t['monto'],2,'.',''); ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </details>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo number_format($totalIngresos, 2, '.', ''); ?>" readonly></div>
            </div>

            <!-- EGRESOS -->
            <div class="columna">
                <div class="titulo-seccion">Egresos</div>
                <div class="caja" id="egresosCaja">
                    <?php foreach ($egresos_list as $it): ?>
                        <div class="item">
                            <?php echo htmlspecialchars($it['nombre']); ?>:
                            <input type="text" value="<?php echo number_format(abs($it['total']), 2, '.', ''); ?>" readonly>
                            <?php $trans = $transactionsByConcept[$it['idConcepto']] ?? []; ?>
                            <?php if (!empty($trans)): ?>
                                <details style="margin-top:6px;margin-left:22px;">
                                    <summary>Ver detalle (<?php echo count($trans); ?>)</summary>
                                    <ul style="list-style:none;padding-left:0;margin:8px 0;">
                                        <?php foreach ($trans as $t): ?>
                                            <li style="display:flex;align-items:center;gap:8px;padding:4px 0;">
                                                <?php $ppid = (int)$t['perfil_id']; ?>
                                                <span class="dot" style="background: <?php echo $perfilColors[$ppid] ?? '#999'; ?>;width:10px;height:10px;margin-right:6px;" title="<?php echo htmlspecialchars($profileNames[$ppid] ?? ('Perfil '.$ppid)); ?>"></span>
                                                <span style="flex:1"><?php echo htmlspecialchars($t['detalle']); ?></span>
                                                <span style="width:110px;text-align:right;"><?php echo number_format(abs($t['monto']),2,'.',''); ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </details>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="total">Total: <input type="text" value="<?php echo number_format(abs($totalEgresos), 2, '.', ''); ?>" readonly></div>
            </div>
        </div>

        <!-- RESUMEN -->
        <div class="resumen">
            <div>Resumen mensual (desde <?php echo $startMonth; ?> hasta <?php echo $fechaSeleccionada; ?>): <input type="text" value="<?php echo number_format($month_display, 2, '.', ''); ?>" readonly></div>
            <div>Resumen anual (acumulado desde <?php echo $startYear; ?> hasta <?php echo $fechaSeleccionada; ?>): <input type="text" value="<?php echo number_format($year_sum, 2, '.', ''); ?>" readonly></div>
        </div>

        <!-- Leyenda -->
        <?php if ($isAdmin): ?>
        <div class="leyenda-right">
                <strong>Perfiles (<?php echo $tamañoVectorPerfilesExistentes; ?>)</strong>            <div class="leyenda-list" id="leyendaList">
                <?php foreach ($perfiles as $p): ?>
                    <?php $pid = (int)$p['idPerfil']; ?>
                    <div class="leyenda-item"><span class="dot" style="background: <?php echo $perfilColors[$pid]; ?>"></span> <?php echo htmlspecialchars($p['nombre']); ?></div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

<script>
/*
  Funciones del diccionario (Nombres exactos requeridos)
  - mostrarBalance(fecha: date, idPerfil: integer, idUsuario: integer)
  - presionarCambiarFecha(accionRealizada: boolean)
  - seleccionarNuevaFecha(nuevaFecha: date, idPerfil: integer, idUsuario: integer)
  - mostrarBalanceGeneral(fecha: date, idPerfil: integer, idUsuario: integer)
  - seleccionarBotón(opción: integer)
  - seleccionarPerfilEspecífico(fecha: date, idPerfilEspecífico: integer, idUsuario: integer)
  - cargarInformación(colecciónTransacciones: string)
*/

// datos pasados desde PHP
const perfilColors = <?php echo $perfilColorsJSON; ?> || {};
const perfilesList = <?php echo $perfilesJSON; ?> || [];
const sessionPerfilId = <?php echo (int)$idPerfil; ?>;
const selectedPerfilInitial = <?php echo (int)$selectedPerfil; ?>;
const fechaInicial = "<?php echo $fechaSeleccionada; ?>";



document.addEventListener("DOMContentLoaded", () => {
    const dropdown = document.querySelector(".dropdown");
    const content = dropdown.querySelector(".dropdown-content");
    let hideTimeout;

    dropdown.addEventListener("mouseenter", () => {
        clearTimeout(hideTimeout); // evita que se oculte si vuelves rápido
        content.style.display = "block";
    });

    dropdown.addEventListener("mouseleave", () => {
        hideTimeout = setTimeout(() => {
            content.style.display = "none";
        }, 400); // <-- ajusta este número si quieres más o menos tiempo
    });
});



// helper: actualizar indicador de color al lado del select
function actualizarIndicadorPerfil(pid) {
    const el = document.getElementById('perfilIndicator');
    if (!el) return; // elemento no existe para usuarios no admin
    const color = perfilColors[pid] || '#999';
    el.style.background = color;
    el.title = 'Color del perfil seleccionado';
}

// 1) mostrarBalance: recarga la vista mostrando el balance del perfil y fecha indicados
function mostrarBalance(fecha, idPerfil, idUsuario) {
    // idUsuario no es necesario para la vista actual (se pasa por compatibilidad)
    const f = encodeURIComponent(fecha);
    const p = (typeof idPerfil === 'undefined' || idPerfil === null) ? 0 : idPerfil;
    location.href = 'balance.php?perfil=' + p + '&fecha=' + f;
}

// 2) presionarCambiarFecha: maneja cuando el usuario cambia la fecha en el input
function presionarCambiarFecha(accionRealizada) {
    // Si accionRealizada true: aplicamos la nueva fecha
    const nueva = document.getElementById('fechaFiltro').value;
    if (!nueva) {
        alert('Seleccione una fecha válida');
        return;
    }
    // llamamos a seleccionarNuevaFecha para centralizar comportamiento
    const perfilEl = document.getElementById('perfil');
    const perfilVal = perfilEl ? perfilEl.value : sessionPerfilId;
    seleccionarNuevaFecha(nueva, perfilVal, sessionPerfilId);
}

// 3) seleccionarNuevaFecha: envía la nueva fecha para actualizar la vista
function seleccionarNuevaFecha(nuevaFecha, idPerfil, idUsuario) {
    // guardamos en URL y recargamos
    mostrarBalance(nuevaFecha, idPerfil, idUsuario);
}

// 4) mostrarBalanceGeneral: fuerza ver todos los perfiles para la fecha indicada
function mostrarBalanceGeneral(fecha, idPerfil, idUsuario) {
    // idPerfil debe ser 0 para "todos"
    mostrarBalance(fecha, 0, idUsuario);
}

// 5) seleccionarBotón: lógica para botones; aquí puedes mapear acciones
function seleccionarBotón(opcion) {
    // ejemplo de uso: 1=refrescar, 2=exportar, 3=ver-detalle
    switch(opcion) {
        case 1:
            mostrarBalance(document.getElementById('fechaFiltro').value, document.getElementById('perfil').value, sessionPerfilId);
            break;
        case 2:
            alert('Función exportar no implementada en esta vista (por ahora).');
            break;
        case 3:
            alert('Abrir detalle (no implementado).');
            break;
        default:
            console.log('Botón desconocido', opcion);
    }
}

// 6) seleccionarPerfilEspecífico: filtra el balance por perfil seleccionado (llama a mostrarBalance)
function seleccionarPerfilEspecífico(perfilId, fecha, idUsuario) {
    // Permitir llamada con sólo perfilId
    const fechaAct = fecha || document.getElementById('fechaFiltro').value || fechaInicial;
    const pid = parseInt(perfilId, 10);
    // actualizar indicador visual
    actualizarIndicadorPerfil(pid);
    // recargar con el nuevo perfil y fecha
    mostrarBalance(fechaAct, pid, idUsuario || sessionPerfilId);
}

// 7) cargarInformación: hook para procesar datos (si deseas AJAX)
function cargarInformación(colecciónTransacciones) {
    // por ahora mostramos en consola; si en el futuro quieres cargar via AJAX, implementa aquí
    console.log('cargarInformación llamado con:', colecciónTransacciones);
    // ejemplo: podrías mostrar un modal con detalles o hacer un fetch a un endpoint
}

/* ===== comportamiento adicional en la UI ===== */
document.addEventListener('DOMContentLoaded', () => {
    // set indicador inicial
    actualizarIndicadorPerfil(selectedPerfilInitial);

    // si el usuario cambia el selector de perfil, usamos seleccionarPerfilEspecífico sin recargar forzada
    const sel = document.getElementById('perfil');
    if (sel) {
        sel.addEventListener('change', (e) => {
            const pid = parseInt(e.target.value, 10);
            // actualizar indicador visual y actualizar la vista
            actualizarIndicadorPerfil(pid);
            // llamamos a mostrarBalance con la fecha actual del input
            const fecha = document.getElementById('fechaFiltro').value || fechaInicial;
            mostrarBalance(fecha, pid, sessionPerfilId);
        });
    }

    // Permitir atajo de teclado: Enter en fecha aplica el filtro
    const fechaInput = document.getElementById('fechaFiltro');
    if (fechaInput) {
        fechaInput.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') {
                presionarCambiarFecha(true);
            }
        });
    }


    
});
</script>
</body>
</html>
