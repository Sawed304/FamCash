<?php
/**
 * configuracion_perfil.php
 * ----------------
 * Interfaz para que un perfil cambie su alias y contraseña.
 * - Requiere perfil seleccionado en sesión ($_SESSION['perfil_id']).
 * - Actualiza nombre_perfil y/o contraseña_perfil en la tabla Perfil tras validaciones.
 * - Actualiza $_SESSION['perfil_nombre'] cuando cambia el alias.
 */
$idInterfaz = 9; // UIConfiguraciónDePerfil
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    // Si no hay perfil seleccionado, pedir que se seleccione uno
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = (int)$_SESSION["perfil_id"];

// Obtener datos actuales del perfil mediante procedimiento
$stmtP = $conexion->prepare("CALL sp_get_perfil_credentials(?)");
if ($stmtP) {
    $stmtP->bind_param('i', $idPerfil);
    $stmtP->execute();
    $resP = $stmtP->get_result();
    $perfilActual = $resP ? $resP->fetch_assoc() : ['nombre_perfil' => '', 'contraseña_perfil' => ''];
    $stmtP->close();
} else {
    $perfilActual = ['nombre_perfil' => '', 'contraseña_perfil' => ''];
}

$mensajeJS = '';

// rol del perfil en sesión (si existe)
$isAdmin = isset($_SESSION['perfil_rol']) && in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin','administrador']);

if ($_SERVER["REQUEST_METHOD"] === 'POST') {
    // Recoger campos
    $nuevoNombre = trim($_POST['nombre_perfil'] ?? '');
    $conActual = $_POST['contrasena_actual'] ?? '';
    $conNueva = $_POST['contrasena_nueva'] ?? '';
    $confirmacion = $_POST['confirmar_contrasena'] ?? '';

    $errores = [];
    $exitoMsgs = [];

    // 1) Cambiar nombre (alias)
    if ($nuevoNombre !== '' && $nuevoNombre !== $perfilActual['nombre_perfil']) {
        // Actualizar nombre usando procedimiento
        $upd = $conexion->prepare("CALL sp_update_perfil_nombre(?, ?, @res)");
        if ($upd) {
            $upd->bind_param('is', $idPerfil, $nuevoNombre);
            $upd->execute();
            $upd->close();
            $r = $conexion->query("SELECT @res AS result")->fetch_assoc();
            if ($r && (int)$r['result'] > 0) {
                $exitoMsgs[] = 'Alias actualizado.';
                $_SESSION['perfil_nombre'] = $nuevoNombre;
                $perfilActual['nombre_perfil'] = $nuevoNombre;
            } else {
                $errores[] = 'No se pudo actualizar el alias.';
            }
        } else {
            $errores[] = 'Error al preparar la actualización del alias.';
        }
    }

    // 2) Cambiar contraseña (si se intentó)
    if ($conActual !== '' || $conNueva !== '' || $confirmacion !== '') {
        if ($conActual === '') {
            $errores[] = 'Ingrese la contraseña actual para cambiar la contraseña.';
        } else {
            // Verificar contraseña actual
            $hashActual = $perfilActual['contraseña_perfil'];
            if (!password_verify($conActual, $hashActual)) {
                $errores[] = 'La contraseña actual no es correcta.';
            } else {
                if ($conNueva === '') {
                    $errores[] = 'Ingrese la nueva contraseña.';
                } elseif ($conNueva !== $confirmacion) {
                    $errores[] = 'La nueva contraseña y su confirmación no coinciden.';
                } else {
                    // Opcional: validar longitud mínima
                    if (strlen($conNueva) < 6) {
                        $errores[] = 'La nueva contraseña debe tener al menos 6 caracteres.';
                    } else {
                        $hashNew = password_hash($conNueva, PASSWORD_DEFAULT);
                        // Actualizar contraseña mediante procedimiento
                        $upd2 = $conexion->prepare("CALL sp_update_perfil_password(?, ?, @res)");
                        if ($upd2) {
                            $upd2->bind_param('is', $idPerfil, $hashNew);
                            $upd2->execute();
                            $upd2->close();
                            $r2 = $conexion->query("SELECT @res AS result")->fetch_assoc();
                            if ($r2 && (int)$r2['result'] > 0) {
                                $exitoMsgs[] = 'Contraseña actualizada.';
                            } else {
                                $errores[] = 'No se pudo actualizar la contraseña.';
                            }
                        } else {
                            $errores[] = 'Error al preparar la actualización de la contraseña.';
                        }
                    }
                }
            }
        }
    }


    // Preparar mensaje JS para mostrar en la página
    if (count($errores) > 0) {
        $mensajeJS = "<script>window.addEventListener('load', function(){ func03_mostrarMensaje(false, '" . implode(' | ', array_map('addslashes', $errores)) . "'); });</script>";
    } elseif (count($exitoMsgs) > 0) {
        $mensajeJS = "<script>window.addEventListener('load', function(){ func03_mostrarMensaje(true, '" . addslashes(implode(' | ', $exitoMsgs)) . "'); });</script>";
    } else {
        // Nada para cambiar
        $mensajeJS = "<script>window.addEventListener('load', function(){ func03_mostrarMensaje(false, 'No hubo cambios.'); });</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestionar Perfiles - FamCash</title>
    <!-- Usar el mismo CSS que Balance para asegurar apariencia idéntica -->
    <link rel="stylesheet" href="css/configuracion_perfiles.css">
    <link rel="stylesheet" href="css/dialogs.css">
 
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
        
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
            <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
            <div class="dropdown">
                <button class="menu-btn active">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="gestionar_concepto.php">Config. de Conceptos</a>
                    <a href="#">Config. Perfil</a>
                    <?php if (isset($isAdmin) && $isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php else: ?>
                        <span style="display:block;padding:8px 12px;color:#666;font-size:0.9em;"></span>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

<main>

    <!-- Botón de cerrar sesión (a la izquierda) -->
    <!-- Botón de cerrar sesión -->
   


            <form action="configuracion_perfil.php" method="post" enctype="multipart/form-data" onsubmit="return func04_validarFormulario();">

            <div class="contenedor">

                <!-- Columna izquierda -->
                <section class="columna izquierda">
                    <h2>Tu perfil</h2>
                    <div class="form-group">
                        <label>Alias actual</label>
                        <input class="campo" type="text" name="nombre_perfil" placeholder="Alias del perfil"
                            value="<?php echo htmlspecialchars($perfilActual['nombre_perfil']); ?>">
                    </div>
                    <div class="status" id="statusMessage" style="display:none;"></div>
                </section>

                <!-- Columna derecha -->
                <section class="columna derecha">
                    <h2>Cambiar contraseña</h2>
                    <div class="form-group"><label>Contraseña actual</label><input class="campo" type="password" name="contrasena_actual" id="contrasena_actual"></div>
                    <div class="form-group"><label>Nueva contraseña</label><input class="campo" type="password" name="contrasena_nueva" id="contrasena_nueva"></div>
                    <div class="form-group"><label>Confirmar nueva contraseña</label><input class="campo" type="password" name="confirmar_contrasena" id="confirmar_contrasena"></div>

                    <div class="botones">
                        <button type="button" class="cancelar" onclick="func01_seleccionarBoton(2)">Cancelar</button>
                        <button type="submit" class="guardar" onclick="func01_seleccionarBoton(1)">Guardar cambios</button>
                    </div>
                </section>

            </div>

            <!-- Botón fuera del contenedor, pero alineado con la izquierda -->
            <div class="logout-container">
                    <button type="button" class="btn-logout" data-href="seleccionperfil.php" data-confirm="¿Cerrar sesión?">
                        Cerrar sesión
                    </button>
            </div>

        </form>

</main>



<script src="js/ui_dialogs.js"></script>
<script src="js/confirm_handler.js"></script>
<script src="js/configuracion_perfil.js"></script>

<?php echo $mensajeJS; ?>
</body>
</html>
</body>
</html>
