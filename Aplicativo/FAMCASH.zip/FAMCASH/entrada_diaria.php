<?php
/**
 * entrada_diaria.php
 * ------------------
 * Interfaz para ingresar transacciones diarias del perfil seleccionado.
 * - Muestra listas de Ingresos y Egresos del perfil en sesión (solo sus transacciones).
 * - Permite agregar filas en cliente y enviar arrays (concepto_id[], tipo[], detalle[], monto[]) a guardar_transaccion.php.
 * - Soporta eliminación vía AJAX (delete_id) y refresco dinámico de resúmenes (summary endpoint).
 * Variables de sesión esperadas: $_SESSION['perfil_id'], $_SESSION['perfil_nombre'], opcionalmente $_SESSION['id_familia'] y $_SESSION['perfil_rol'].
 */
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$nombrePerfil = $_SESSION['perfil_nombre'];
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
// familia en sesión (para resúmenes a nivel familiar)
$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;
// rol del perfil en sesión (si es Administrador)
$isAdmin = isset($_SESSION['perfil_rol']) && in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin','administrador']);

// --- Cargar categorías disponibles SOLO del perfil activo ---
$stmt = $conexion->prepare("CALL sp_get_conceptos_perfil(?)");
$stmt->bind_param("i", $idPerfil);
$stmt->execute();
$result = $stmt->get_result();

$ingresos = [];
$egresos = [];

while ($row = $result->fetch_assoc()) {
    $tipoLower = strtolower($row['tipo'] ?? '');
    if ($tipoLower === 'ingreso') {
        $ingresos[] = $row;
    } else {
        $egresos[] = $row;
    }
}
$stmt->close();

// --- Cargar transacciones del día ---
$stmtTrans = null;
// Usar stored procedure para obtener transacciones del día
$stmtTrans = $conexion->prepare("CALL sp_get_transacciones_dia(?, ?)");
$stmtTrans->bind_param('is', $idPerfil, $fechaSeleccionada);
$stmtTrans->execute();
$resTrans = $stmtTrans->get_result();

$transaccionesDia = [];
while ($row = $resTrans->fetch_assoc()) {
    $transaccionesDia[] = $row;
}
$stmtTrans->close();

$balances = [
    'annual' => ['ingresos' => 0.0, 'egresos' => 0.0],
    'monthly' => ['ingresos' => 0.0, 'egresos' => 0.0]
];

// === Resúmenes dinámicos (mensual y anual) hasta la fecha seleccionada ===
$monthStart = date('Y-m-01', strtotime($fechaSeleccionada));
$yearStart = date('Y-01-01', strtotime($fechaSeleccionada));

// === Obtener resúmenes por rango de fechas ===
// Calcular totales mensuales y anuales usando procedimiento almacenado (evita concatenación dinámica)
$monthlyIncome = 0; $monthlyExpense = 0;
$annualIncome = 0; $annualExpense = 0;

// Mes
$stmtRange = $conexion->prepare("CALL sp_get_totals_range(?, ?, ?)");
if ($stmtRange) {
    $stmtRange->bind_param('iss', $idFamilia, $monthStart, $fechaSeleccionada);
    $stmtRange->execute();
    $resMonth = $stmtRange->get_result();
    if ($resMonth) {
        $r = $resMonth->fetch_assoc();
        $monthlyIncome = (float)($r['ingresos'] ?? 0);
        $monthlyExpense = (float)($r['egresos'] ?? 0);
    }
    $stmtRange->close();
}

// Año
$stmtRange = $conexion->prepare("CALL sp_get_totals_range(?, ?, ?)");
if ($stmtRange) {
    $stmtRange->bind_param('iss', $idFamilia, $yearStart, $fechaSeleccionada);
    $stmtRange->execute();
    $resYear = $stmtRange->get_result();
    if ($resYear) {
        $r = $resYear->fetch_assoc();
        $annualIncome = (float)($r['ingresos'] ?? 0);
        $annualExpense = (float)($r['egresos'] ?? 0);
    }
    $stmtRange->close();
}

// Calcular resúmenes (igual que en balance.php)
$yearSum = $annualIncome - $annualExpense;
$monthSum = $monthlyIncome - $monthlyExpense;
$monthDisplay = $monthSum;

// Resto del código PHP existente para los balances...
// Helper para mostrar fechas en formato legible en español
function fecha_legible($fecha) {
    if (empty($fecha)) return '';
    try {
        $dt = new DateTime($fecha);
    } catch (Exception $e) {
        return htmlspecialchars($fecha);
    }
    $meses = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    $dia = $dt->format('j');
    $mes = $meses[(int)$dt->format('n') - 1];
    $ano = $dt->format('Y');
    return $dia . ' de ' . $mes . ' de ' . $ano;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Entrada Diaria</title>
    <link rel="stylesheet" href="css/entrada_diaria.css?v=<?php echo filemtime('css/entrada_diaria.css'); ?>">
    <link rel="stylesheet" href="css/dialogs.css?v=<?php echo filemtime('css/dialogs.css'); ?>">
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn active">Entrada diaria</button>
            <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
            <div class="dropdown">
                <button class="menu-btn">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="gestionar_concepto.php">Config. de Conceptos</a>
                    <a href="configuracion_perfil.php">Config. Perfil</a>
                    <?php if ($isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php else: ?>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <main class="contenido">
        <h2>Entrada diaria - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

        <!-- Resumen superior destacado (FIJO) -->
        <div class="top-summary">
            <div class="box">
                <div class="title">Balance Mensual</div>
                <div class="value <?php echo ($monthSum < 0) ? 'negativo' : 'positivo'; ?>" id="monthlyDisplayTop"><?php echo 'S/'.number_format($monthDisplay,2,'.',''); ?></div>
                <div class="small"><?php echo fecha_legible($monthStart); ?> — <?php echo fecha_legible($fechaSeleccionada); ?></div>
            </div>
            <div class="box">
                <div class="title">Balance Anual</div>
                <div class="value <?php echo ($yearSum < 0) ? 'negativo' : 'positivo'; ?>" id="annualDisplayTop"><?php echo 'S/'.number_format($yearSum,2,'.',''); ?></div>
                <div class="small"><?php echo fecha_legible($yearStart); ?> — <?php echo fecha_legible($fechaSeleccionada); ?></div>
            </div>
            <div class="date-picker">
                <input type="date" id="fechaSeleccionada" value="<?php echo $fechaSeleccionada; ?>" onchange="location.href='entrada_diaria.php?fecha=' + this.value">
            </div>
        </div>

        <!-- Sección de recordatorios -->
        <section class="recordatorios">
            <h3>Recordatorios del Día</h3>
            <div id="lista-recordatorios">
                <?php
                // Obtener recordatorios y filtrar en PHP para evitar SELECT directo con condiciones dinámicas
                $hoy = $fechaSeleccionada;
                $stmtRecordatorios = $conexion->prepare("CALL sp_get_recordatorios_por_perfil(?)");
                $recordatoriosHoy = [];
                if ($stmtRecordatorios) {
                    $stmtRecordatorios->bind_param('i', $idPerfil);
                    $stmtRecordatorios->execute();
                    $resRecordatorios = $stmtRecordatorios->get_result();
                    while ($row = $resRecordatorios->fetch_assoc()) {
                        // Filtrar por fecha_inicio y periodo en PHP
                        if ($row['fecha_inicio'] <= $hoy && (!isset($row['periodo']) || $row['periodo'] !== 'nunca')) {
                            if (debeMostrarRecordatorio($row, $hoy)) {
                                $recordatoriosHoy[] = $row;
                            }
                        }
                    }
                    $stmtRecordatorios->close();
                }
                
                if (count($recordatoriosHoy) > 0): 
                    foreach ($recordatoriosHoy as $recordatorio): ?>
                        <div class="recordatorio-alerta" data-id="<?php echo $recordatorio['id_recordatorio']; ?>">
                            <span class="recordatorio-texto"><?php echo htmlspecialchars($recordatorio['nombre_recordatorio']); ?></span>
                            <button class="cerrar-recordatorio" onclick="func05_cerrarRecordatorio(<?php echo $recordatorio['id_recordatorio']; ?>)">✖</button>
                        </div>
                    <?php endforeach; 
                else: ?>
                    <p style="color:#666;text-align:center;">No hay recordatorios para hoy.</p>
                <?php endif; ?>
            </div>
        </section>

        <?php
        /**
         * Determina si un recordatorio debe mostrarse en una fecha específica según su periodicidad.
         * 
         * @param array $recordatorio Datos del recordatorio desde la base de datos
         * @param string $fecha Fecha a verificar en formato Y-m-d
         * @return bool True si el recordatorio debe mostrarse, false en caso contrario
         */
        function debeMostrarRecordatorio($recordatorio, $fecha) {
            $fechaInicio = new DateTime($recordatorio['fecha_inicio']);
            $fechaActual = new DateTime($fecha);
            
            // Si la fecha actual es anterior a la fecha de inicio, no mostrar
            if ($fechaActual < $fechaInicio) {
                return false;
            }
            
            $diasDiferencia = $fechaInicio->diff($fechaActual)->days;
            
            switch ($recordatorio['periodo']) {
                case 'diario':
                    return true;
                    
                case 'semanal':
                    return $diasDiferencia % 7 === 0;
                    
                case 'quincenal':
                    return $diasDiferencia % 15 === 0;
                    
                case 'mensual':
                    // Para mensual, verificamos que sea el mismo día del mes
                    return $fechaInicio->format('d') === $fechaActual->format('d');
                    
                default:
                    return false;
            }
        }
        ?>

        <section class="paneles">
            <!-- INGRESOS -->
            <div class="panel ingresos">
                <h3>Ingresos</h3>
                <div class="lista">
                    <?php foreach ($transaccionesDia as $trans): 
                        if ($trans['tipo'] === 'Ingreso'): 
                            $nombreMostrar = !empty($trans['alias_concepto']) ? $trans['alias_concepto'] : $trans['nombre_concepto'];
                        ?>
                        <div class="fila" data-id="<?php echo $trans['id_transaccion']; ?>">
                            <input type="hidden" name="concepto_id[]" value="<?php echo (int)$trans['id_concepto_Concepto']; ?>">
                            <input type="hidden" name="tipo[]" value="Ingreso">
                            <span class="categoria"><?php echo htmlspecialchars($nombreMostrar); ?></span>
                            <input class="detalle" type="text" name="detalle[]" value="<?php echo htmlspecialchars($trans['detalle']); ?>">
                            <input class="monto" type="number" name="monto[]" step="0.01" value="<?php echo abs($trans['monto']); ?>" required>
                            <button class="borrar">✖</button>
                        </div>
                        <?php endif; 
                    endforeach; ?>
                </div>
                <div class="agregar">
                    <select id="selectIngreso">
                        <option value="">-- Seleccionar categoría --</option>
                        <?php foreach ($ingresos as $ingreso): ?>
                            <option value="<?php echo htmlspecialchars($ingreso['id_concepto']); ?>">
                                <?php echo htmlspecialchars($ingreso['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" id="nuevoIngreso" placeholder="Detalle" style="display: none;">
                    <button id="btnAgregarIngreso">Agregar</button>
                </div>
                <div class="total">
                    <label>Total ingresos:</label>
                    <input type="text" id="totalIngresos" readonly value="S/0.00">
                </div>
            </div>

            <!-- EGRESOS -->
            <div class="panel egresos">
                <h3>Egresos</h3>
                <div class="lista">
                    <?php foreach ($transaccionesDia as $trans): 
                        if ($trans['tipo'] === 'Egreso'): 
                            $nombreMostrar = !empty($trans['alias_concepto']) ? $trans['alias_concepto'] : $trans['nombre_concepto'];
                        ?>
                        <div class="fila" data-id="<?php echo $trans['id_transaccion']; ?>">
                            <input type="hidden" name="concepto_id[]" value="<?php echo (int)$trans['id_concepto_Concepto']; ?>">
                            <input type="hidden" name="tipo[]" value="Egreso">
                            <span class="categoria"><?php echo htmlspecialchars($nombreMostrar); ?></span>
                            <input class="detalle" type="text" name="detalle[]" value="<?php echo htmlspecialchars($trans['detalle']); ?>">
                            <input class="monto" type="number" name="monto[]" step="0.01" value="<?php echo abs($trans['monto']); ?>" required>
                            <button class="borrar">✖</button>
                        </div>
                        <?php endif; 
                    endforeach; ?>
                </div>
                <div class="agregar">
                    <select id="selectEgreso">
                        <option value="">-- Seleccionar categoría --</option>
                        <?php foreach ($egresos as $egreso): ?>
                            <option value="<?php echo htmlspecialchars($egreso['id_concepto']); ?>">
                                <?php echo htmlspecialchars($egreso['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" id="nuevoEgreso" placeholder="Detalle" style="display: none;">
                    <button id="btnAgregarEgreso">Agregar</button>
                </div>
                <div class="total">
                    <label>Total egresos:</label>
                    <input type="text" id="totalEgresos" readonly value="S/0.00">
                </div>
            </div>
        </section>

        <section class="acciones">
            <button class="guardar">Guardar</button>
        </section>

        <!-- (Resumen superior ya mostrado arriba) -->
    </main>

    <script src="js/ui_dialogs.js?v=<?php echo filemtime('js/ui_dialogs.js'); ?>"></script>
    <script src="js/entrada_diaria.js?v=<?php echo filemtime('js/entrada_diaria.js'); ?>"></script>
</body>
</html>