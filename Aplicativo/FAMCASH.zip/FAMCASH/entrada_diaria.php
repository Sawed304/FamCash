<?php
/**
 * entrada_diaria.php
 * ------------------
 * Interfaz para ingresar transacciones diarias del perfil seleccionado.
 * - Muestra listas de Ingresos y Egresos del perfil en sesión (solo sus transacciones).
 * - Permite agregar filas en cliente y enviar arrays (concepto_id[], tipo[], detalle[], monto[]) a guardar_transaccion.php.
 * - Soporta eliminación vía AJAX (delete_id) y refresco dinámico de resúmenes (summary endpoint).
 * Variables de sesión esperadas: $_SESSION['perfil_id'], $_SESSION['perfil_nombre'], opcionalmente $_SESSION['id_familia'] y $_SESSION['perfil_rol'].
 */
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = $_SESSION['perfil_id'];
$nombrePerfil = $_SESSION['perfil_nombre'];
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');
// familia en sesión (para resúmenes a nivel familiar)
$idFamilia = isset($_SESSION['id_familia']) ? (int)$_SESSION['id_familia'] : null;
// rol del perfil en sesión (si es Administrador)
$isAdmin = isset($_SESSION['perfil_rol']) && in_array(strtolower(trim($_SESSION['perfil_rol'])), ['admin','administrador']);

// --- Cargar todas las categorías disponibles ---
$sql = "SELECT id_concepto, nombre_concepto AS nombre, tipo 
        FROM Concepto 
        ORDER BY tipo DESC, nombre_concepto";
$stmt = $conexion->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$ingresos = [];
$egresos = [];

while ($row = $result->fetch_assoc()) {
    $tipoLower = strtolower($row['tipo'] ?? '');
    if ($tipoLower === 'ingreso') {
        $ingresos[] = $row;
    } else {
        $egresos[] = $row;
    }
}

// --- Cargar transacciones del día ---
$stmtTrans = null;
// Si el usuario NO es admin, solo traer sus propias transacciones; si es admin, traer todas las transacciones del día
$sqlTransacciones = "SELECT t.*, c.nombre_concepto, c.tipo 
                    FROM Transaccion t 
                    JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto 
                    WHERE t.id_perfil_Perfil = ? AND DATE(t.fecha) = ?
                    ORDER BY c.tipo DESC, t.detalle";
$stmtTrans = $conexion->prepare($sqlTransacciones);
$stmtTrans->bind_param('is', $idPerfil, $fechaSeleccionada);
$stmtTrans->execute();
$resTrans = $stmtTrans->get_result();

$transaccionesDia = [];
while ($row = $resTrans->fetch_assoc()) {
    $transaccionesDia[] = $row;
}

$balances = [
    'annual' => ['ingresos' => 0.0, 'egresos' => 0.0],
    'monthly' => ['ingresos' => 0.0, 'egresos' => 0.0]
];

// === Resúmenes dinámicos (mensual y anual) hasta la fecha seleccionada ===
$monthStart = date('Y-m-01', strtotime($fechaSeleccionada));
$yearStart = date('Y-01-01', strtotime($fechaSeleccionada));

// Detectar si la tabla Perfil tiene columna de familia para filtrar (usamos la familia
// del perfil en sesión para calcular resúmenes que correspondan sólo a esa cuenta)
$perfilFamiliaCol = null;
$stmtCol = $conexion->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('Perfil','perfil') AND (COLUMN_NAME = 'id_familia_Familia' OR COLUMN_NAME = 'id_familia') LIMIT 1");
if ($stmtCol) {
    $stmtCol->execute();
    $resCol = $stmtCol->get_result();
    if ($resCol && $rc = $resCol->fetch_assoc()) {
        $perfilFamiliaCol = $rc['COLUMN_NAME'];
    }
}

// Construir SQL para obtener ingresos/egresos en un rango (filtrando por perfiles de la misma familia)
$sqlRange = "SELECT
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN ABS(t.monto) ELSE 0 END),0) AS ingresos,
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN ABS(t.monto) ELSE 0 END),0) AS egresos
FROM Transaccion t
JOIN Concepto c ON t.id_concepto_Concepto = c.id_concepto
JOIN Perfil p ON t.id_perfil_Perfil = p.id_perfil";

$needPerfilFamilyFilter = false;
if ($perfilFamiliaCol !== null && $idFamilia !== null) {
    $sqlRange .= "\nWHERE p." . $perfilFamiliaCol . " = ?";
    $needPerfilFamilyFilter = true;
}

if ($needPerfilFamilyFilter) {
    $sqlRange .= " AND DATE(t.fecha) BETWEEN ? AND ?";
} else {
    $sqlRange .= " WHERE DATE(t.fecha) BETWEEN ? AND ?";
}

// Ejecutar para año: preparar SQL según si filtramos por familia de perfiles o no
$annualIncome = 0; $annualExpense = 0;
if ($needPerfilFamilyFilter) {
    $sqlYear = $sqlRange; // contains p.<col> = ? AND DATE(t.fecha) BETWEEN ? AND ?
    $stmtYear = $conexion->prepare($sqlYear);
    if ($stmtYear) {
        $stmtYear->bind_param('iss', $idFamilia, $yearStart, $fechaSeleccionada);
        $stmtYear->execute();
        $resYear = $stmtYear->get_result();
        if ($resYear) {
            $r = $resYear->fetch_assoc();
            $annualIncome = (float)$r['ingresos'];
            $annualExpense = (float)$r['egresos'];
        }
    }
} else {
    $sqlYear = $sqlRange; // contains DATE(t.fecha) BETWEEN ? AND ?
    $stmtYear = $conexion->prepare($sqlYear);
    if ($stmtYear) {
        $stmtYear->bind_param('ss', $yearStart, $fechaSeleccionada);
        $stmtYear->execute();
        $resYear = $stmtYear->get_result();
        if ($resYear) {
            $r = $resYear->fetch_assoc();
            $annualIncome = (float)$r['ingresos'];
            $annualExpense = (float)$r['egresos'];
        }
    }
}

// Ejecutar para mes
$monthlyIncome = 0; $monthlyExpense = 0;
if ($needPerfilFamilyFilter) {
    $sqlMonth = $sqlRange;
    $stmtMonth = $conexion->prepare($sqlMonth);
    if ($stmtMonth) {
        $stmtMonth->bind_param('iss', $idFamilia, $monthStart, $fechaSeleccionada);
        $stmtMonth->execute();
        $resMonth = $stmtMonth->get_result();
        if ($resMonth) {
            $r = $resMonth->fetch_assoc();
            $monthlyIncome = (float)$r['ingresos'];
            $monthlyExpense = (float)$r['egresos'];
        }
    }
} else {
    $sqlMonth = $sqlRange;
    $stmtMonth = $conexion->prepare($sqlMonth);
    if ($stmtMonth) {
        $stmtMonth->bind_param('ss', $monthStart, $fechaSeleccionada);
        $stmtMonth->execute();
        $resMonth = $stmtMonth->get_result();
        if ($resMonth) {
            $r = $resMonth->fetch_assoc();
            $monthlyIncome = (float)$r['ingresos'];
            $monthlyExpense = (float)$r['egresos'];
        }
    }
}

$yearSum = $annualIncome - $annualExpense;
$monthSum = $monthlyIncome - $monthlyExpense;
$monthDisplay = max($monthSum, 0.0);

// Resto del código PHP existente para los balances...
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Entrada Diaria</title>
    <link rel="stylesheet" href="css/daily.css">
</head>
<body>
    <header class="header">
        <div class="logo" onclick="location.href='entrada_diaria.php'">
            <h1>FamCash</h1>
        </div>

        <nav class="menu">
            <button class="menu-btn active">Entrada diaria</button>
            <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
            <div class="dropdown">
                <button class="menu-btn">Configuración ▼</button>
                <div class="dropdown-content">
                    <a href="#">Config. de Conceptos</a>
                    <a href="configuracion_perfil.php">Config. Perfil</a>
                    <?php if ($isAdmin): ?>
                        <a href="gestionar_perfiles.php">Config. Perfiles Familiares</a>
                    <?php else: ?>
                        <span style="display:block;padding:8px 12px;color:#666;font-size:0.9em;">(Acceso sólo Administrador)</span>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>




    <main class="contenido">
        <h2>Entrada diaria - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

        <section class="paneles">
            <!-- INGRESOS -->
            <div class="panel ingresos">
                <h3>Ingresos</h3>
                <div class="lista">
                        <?php foreach ($transaccionesDia as $trans): 
                            if ($trans['tipo'] === 'Ingreso'): ?>
                            <div class="fila" data-id="<?php echo $trans['id_transaccion']; ?>">
                                <input type="hidden" name="concepto_id[]" value="<?php echo (int)$trans['id_concepto_Concepto']; ?>">
                                <input type="hidden" name="tipo[]" value="Ingreso">
                                <span class="categoria"><?php echo htmlspecialchars($trans['nombre_concepto']); ?></span>
                                <input class="detalle" type="text" name="detalle[]" value="<?php echo htmlspecialchars($trans['detalle']); ?>">
                                <input class="monto" type="number" name="monto[]" step="0.01" value="<?php echo abs($trans['monto']); ?>" required>
                                <button class="borrar">✖</button>
                            </div>
                            <?php endif; 
                        endforeach; ?>
                </div>
                <div class="agregar">
                    <select id="selectIngreso">
                        <option value="">-- Seleccionar categoría --</option>
                        <?php foreach ($ingresos as $ingreso): ?>
                            <option value="<?php echo htmlspecialchars($ingreso['id_concepto']); ?>">
                                <?php echo htmlspecialchars($ingreso['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" id="nuevoIngreso" placeholder="Detalle" style="display: none;">
                    <button id="btnAgregarIngreso">Agregar</button>
                </div>
                <div class="total">
                    <label>Total ingresos:</label>
                    <input type="text" id="totalIngresos" readonly value="0.00">
                </div>
            </div>

            <!-- EGRESOS -->
            <div class="panel egresos">
                <h3>Egresos</h3>
                <div class="lista">
                        <?php foreach ($transaccionesDia as $trans): 
                        if ($trans['tipo'] === 'Egreso'): ?>
                        <div class="fila" data-id="<?php echo $trans['id_transaccion']; ?>">
                            <input type="hidden" name="concepto_id[]" value="<?php echo (int)$trans['id_concepto_Concepto']; ?>">
                            <input type="hidden" name="tipo[]" value="Egreso">
                            <span class="categoria"><?php echo htmlspecialchars($trans['nombre_concepto']); ?></span>
                            <input class="detalle" type="text" name="detalle[]" value="<?php echo htmlspecialchars($trans['detalle']); ?>">
                            <input class="monto" type="number" name="monto[]" step="0.01" value="<?php echo abs($trans['monto']); ?>" required>
                            <button class="borrar">✖</button>
                        </div>
                        <?php endif; 
                    endforeach; ?>
                </div>
                <div class="agregar">
                    <select id="selectEgreso">
                        <option value="">-- Seleccionar categoría --</option>
                        <?php foreach ($egresos as $egreso): ?>
                            <option value="<?php echo htmlspecialchars($egreso['id_concepto']); ?>">
                                <?php echo htmlspecialchars($egreso['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" id="nuevoEgreso" placeholder="Detalle" style="display: none;">
                    <button id="btnAgregarEgreso">Agregar</button>
                </div>
                <div class="total">
                    <label>Total egresos:</label>
                    <input type="text" id="totalEgresos" readonly value="0.00">
                </div>
            </div>
        </section>

        <section class="acciones">
            <input type="date" id="fechaSeleccionada" 
                   value="<?php echo $fechaSeleccionada; ?>" 
                   onchange="location.href='entrada_diaria.php?fecha=' + this.value">
            <button class="guardar">Guardar</button>
        </section>

        <!-- Resumen dinámico -->
        <section class="resumen">
            <h3>Resumen</h3>
            <div>Resumen mensual:
                <strong id="monthlyDisplay"><?php echo number_format($monthDisplay,2,'.',''); ?></strong>
            </div>
            <div>Resumen anual:
                <strong id="annualDisplay"><?php echo number_format($yearSum,2,'.',''); ?></strong>
            </div>
        </section>
    </main>

    <script>
        // Función para manejar la visibilidad del input de detalle
        function toggleDetalleInput(selectId, inputId) {
            const select = document.getElementById(selectId);
            const input = document.getElementById(inputId);
            
            select.addEventListener('change', e => {
                const val = e.target.value;
                if (val) {
                    input.style.display = 'block';
                    input.focus();
                } else {
                    input.style.display = 'none';
                    input.value = '';
                }
            });
        }

        // Configurar eventos para ingresos y egresos
        toggleDetalleInput('selectIngreso', 'nuevoIngreso');
        toggleDetalleInput('selectEgreso', 'nuevoEgreso');

        // Agrega una fila editable (detalle, monto) y campos ocultos (concepto_id, tipo)
        function addTransactionRow(tipo, detalle, conceptId, categoria) {
            const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
            const lista = panel.querySelector('.lista');

            const fila = document.createElement('div');
            fila.className = 'fila';

            // Detalle editable
            const detalleInput = document.createElement('input');
            detalleInput.type = 'text';
            detalleInput.name = 'detalle[]';
            detalleInput.className = 'detalle';
            detalleInput.value = detalle || '';

            // Monto editable
            const montoInput = document.createElement('input');
            montoInput.type = 'number';
            montoInput.name = 'monto[]';
            montoInput.className = 'monto';
            montoInput.step = '0.01';
            montoInput.placeholder = '0.00';
            montoInput.required = true;
            montoInput.value = '';

            // Mostrar categoría (solo informativo)
            const categoriaSpan = document.createElement('span');
            categoriaSpan.className = 'categoria';
            categoriaSpan.textContent = categoria;

            // Campos ocultos para enviar al servidor
            const conceptoHidden = document.createElement('input');
            conceptoHidden.type = 'hidden';
            conceptoHidden.name = 'concepto_id[]';
            conceptoHidden.value = conceptId;

            const tipoHidden = document.createElement('input');
            tipoHidden.type = 'hidden';
            tipoHidden.name = 'tipo[]';
            tipoHidden.value = (tipo === 'ingreso') ? 'Ingreso' : 'Egreso';

            const borrarBtn = document.createElement('button');
            borrarBtn.type = 'button';
            borrarBtn.className = 'borrar';
            borrarBtn.textContent = '✖';

            // Colocar categoría a la izquierda, luego detalle y monto
            fila.appendChild(categoriaSpan);
            fila.appendChild(detalleInput);
            fila.appendChild(montoInput);
            fila.appendChild(conceptoHidden);
            fila.appendChild(tipoHidden);
            fila.appendChild(borrarBtn);

            lista.appendChild(fila);
            montoInput.focus();
            calcularTotales();
        }

        document.addEventListener("DOMContentLoaded", () => {
            const dropdown = document.querySelector(".dropdown");
            const content = dropdown.querySelector(".dropdown-content");
            let hideTimeout;

            dropdown.addEventListener("mouseenter", () => {
                clearTimeout(hideTimeout); // cancela el temporizador si reingresa rápido
                content.style.display = "block";
            });

            dropdown.addEventListener("mouseleave", () => {
                hideTimeout = setTimeout(() => {
                    content.style.display = "none";
                }, 100); // <- aquí ajustas el tiempo (en milisegundos)
            });
        });

        // Eventos para agregar transacciones (ingreso/egreso)
        document.getElementById('btnAgregarIngreso').addEventListener('click', e => {
            e.preventDefault();
            const sel = document.getElementById('selectIngreso');
            const val = sel.value;
            const detalle = document.getElementById('nuevoIngreso').value.trim();

            if (!val || !detalle) return;

            const opt = sel.options[sel.selectedIndex];
            addTransactionRow('ingreso', detalle, val, opt.text);

            // Limpiar inputs
            document.getElementById('nuevoIngreso').value = '';
            document.getElementById('nuevoIngreso').style.display = 'none';
            sel.selectedIndex = 0;
        });

        document.getElementById('btnAgregarEgreso').addEventListener('click', e => {
            e.preventDefault();
            const sel = document.getElementById('selectEgreso');
            const val = sel.value;
            const detalle = document.getElementById('nuevoEgreso').value.trim();

            if (!val || !detalle) return;

            const opt = sel.options[sel.selectedIndex];
            addTransactionRow('egreso', detalle, val, opt.text);

            // Limpiar inputs
            document.getElementById('nuevoEgreso').value = '';
            document.getElementById('nuevoEgreso').style.display = 'none';
            sel.selectedIndex = 0;
        });

        // Eliminar fila: si tiene data-id (transacción guardada) borrar en DB, si no solo eliminar del DOM
        document.addEventListener('click', e => {
            if (!e.target.matches('.borrar')) return;
            const fila = e.target.closest('.fila');
            if (!fila) return;

            const transId = fila.getAttribute('data-id');
            if (transId) {
                // petición AJAX para eliminar
                fetch('guardar_transaccion.php', {
                    method: 'POST',
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    body: new URLSearchParams({ delete_id: transId })
                })
                .then(r => r.text())
                .then(txt => {
                    if (txt.trim() === 'ok') {
                        fila.remove();
                        calcularTotales();
                        // refrescar resúmenes desde el servidor para reflejar cambio
                        refreshSummaries();
                    } else {
                        alert('Error al eliminar en servidor: ' + txt);
                    }
                })
                .catch(err => alert('Error en la petición de eliminación: ' + err));
            } else {
                // fila no guardada aún
                fila.remove();
                calcularTotales();
            }
        });

        // Calcular totales
        function calcularTotales() {
            let totalIngresos = 0, totalEgresos = 0;

            document.querySelectorAll('.ingresos .fila .monto').forEach(input => {
                totalIngresos += parseFloat(input.value) || 0;
            });

            document.querySelectorAll('.egresos .fila .monto').forEach(input => {
                totalEgresos += parseFloat(input.value) || 0;
            });

            document.getElementById('totalIngresos').value = totalIngresos.toFixed(2);
            document.getElementById('totalEgresos').value = totalEgresos.toFixed(2);
        }

        // Recalcular totales cuando cambian los montos
        document.addEventListener('input', e => {
            if (e.target.matches('.monto')) calcularTotales();
        });

        // Calcular totales iniciales
        window.addEventListener('load', calcularTotales);

        // Guardar cambios: reunir arrays y enviarlos al servidor
        document.querySelector('.guardar').addEventListener('click', () => {
            const formData = new FormData();
            const fecha = document.querySelector('input[type="date"]').value;

            // Recolectar SOLO filas nuevas (sin data-id) para evitar duplicados
            let newCount = 0;
            document.querySelectorAll('.fila').forEach(fila => {
                const existingId = fila.getAttribute('data-id');
                if (existingId) return; // ya está guardada en servidor, no reenviar

                const concepto = fila.querySelector('input[name="concepto_id[]"]')?.value || '';
                const tipo = fila.querySelector('input[name="tipo[]"]')?.value || '';
                const detalle = fila.querySelector('input[name="detalle[]"]')?.value || '';
                const monto = fila.querySelector('input[name="monto[]"]')?.value || '';

                // Solo enviar filas con monto y concepto
                if (concepto && monto !== '') {
                    formData.append('concepto_id[]', concepto);
                    formData.append('tipo[]', tipo);
                    formData.append('detalle[]', detalle);
                    formData.append('monto[]', monto);
                    newCount++;
                }
            });

            if (newCount === 0) {
                alert('No hay transacciones nuevas para guardar.');
                return; // nada que enviar
            }

            formData.append('fecha', fecha);

            // Enviar datos al servidor
            fetch('guardar_transaccion.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                if (result.trim() === 'ok') {
                    alert('Cambios guardados correctamente');
                    // recargar para reflejar ids nuevos y resúmenes
                    location.reload();
                } else {
                    alert('Error al guardar los cambios: ' + result);
                }
            })
            .catch(err => alert('Error en la petición: ' + err));
        });



        // Refrescar los resúmenes (request al backend)
        function refreshSummaries() {
            const fecha = document.querySelector('input[type="date"]').value;
            fetch('guardar_transaccion.php?action=summary&fecha=' + encodeURIComponent(fecha))
                .then(r => r.json())
                .then(data => {
                    document.getElementById('monthlyDisplay').textContent = Number(data.month_display).toFixed(2);
                    document.getElementById('annualDisplay').textContent = Number(data.year_sum).toFixed(2);
                })
                .catch(err => console.error('No se pudo actualizar resumen:', err));
        }
    </script>
</body>
</html>