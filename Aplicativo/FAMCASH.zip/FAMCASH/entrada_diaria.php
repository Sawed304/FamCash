<?php
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = $_SESSION["perfil_id"];
$nombrePerfil = $_SESSION["perfil_nombre"];

// Fecha seleccionada (antes de usarla)
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');

// Traer solo conceptos que tienen transacciones en esa fecha (agregado: SUM por si hay más de 1)

$sql = "SELECT c.idConcepto, c.nombre, c.tipo, t.monto
FROM conceptos c
INNER JOIN transacciones t 
    ON c.idConcepto = t.idConcepto 
    AND t.idPerfil = ? 
    AND t.fecha = ?
WHERE c.idPerfil = ? AND c.estado = 'Habilitado'
ORDER BY c.tipo DESC, c.nombre";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("isi", $idPerfil, $fechaSeleccionada, $idPerfil);

$stmt->execute();
$result = $stmt->get_result();

$ingresos = [];
$egresos = [];

while ($row = $result->fetch_assoc()) {
    // monto puede venir como string -> convertir a float
    $row['monto'] = (float)$row['monto'];
    if (strtolower($row['tipo']) === 'ingreso') {
        $ingresos[] = $row;
    } else {
        $egresos[] = $row;
    }
}

// Calcular balances: anual (desde primer día del año hasta fecha seleccionada)
// y mensual (desde primer día del mes hasta fecha seleccionada), para todos los perfiles
$year = date('Y', strtotime($fechaSeleccionada));
$startYear = $year . '-01-01';
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

$balances = [
    'annual' => ['ingresos' => 0.0, 'egresos' => 0.0],
    'monthly' => ['ingresos' => 0.0, 'egresos' => 0.0]
];

$sqlRange = "SELECT
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN t.monto ELSE 0 END),0) AS ingresos,
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN t.monto ELSE 0 END),0) AS egresos
FROM transacciones t
JOIN conceptos c ON t.idConcepto = c.idConcepto
WHERE t.fecha BETWEEN ? AND ?";

$stmtRange = $conexion->prepare($sqlRange);
// anual
$stmtRange->bind_param('ss', $startYear, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $balances['annual']['ingresos'] = (float)$r['ingresos'];
    $balances['annual']['egresos'] = (float)$r['egresos'];
}
// mensual
$stmtRange->bind_param('ss', $startMonth, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $balances['monthly']['ingresos'] = (float)$r['ingresos'];
    $balances['monthly']['egresos'] = (float)$r['egresos'];
}

$balanceAnual = $balances['annual']['ingresos'] - $balances['annual']['egresos'];
$balanceMensual = $balances['monthly']['ingresos'] - $balances['monthly']['egresos'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Entrada Diaria</title>
    <link rel="stylesheet" href="css/daily.css">
</head>
<body>

<header class="header">
    <div class="logo" onclick="location.href='entrada_diaria.php'">
        <h1>FamCash</h1>
    </div>

    <nav class="menu">
        <button class="menu-btn active" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
        <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
        <div class="dropdown">
            <button class="menu-btn">Configuración ▼</button>
            <div class="dropdown-content">
                <a href="#">Config. de Conceptos</a>
                <a href="#">Config. Perfil</a>
                <a href="#">Config. Perfiles Familiares</a>
            </div>
        </div>
    </nav>
</header>

<main class="contenido">
    <h2>Entrada diaria - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

    <section class="paneles">
        <!-- PANEL INGRESOS -->
        <div class="panel ingresos">
            <h3>Ingresos</h3>
            <?php if (empty($ingresos)): ?>
                <p class="vacio">No hay conceptos de ingreso. Usa “Agregar” para crear uno.</p>
            <?php else: ?>
                <?php foreach ($ingresos as $i): ?>
                    <div class="fila">
                        <label><?php echo htmlspecialchars($i['nombre']); ?>:</label>
                        <?php
                        $valor = isset($montosGuardados[$i['idConcepto']]) ? $montosGuardados[$i['idConcepto']] : 0.00;
                        ?>
                        <input type="number" name="monto[<?php echo $i['idConcepto']; ?>]" value="<?php echo number_format($i['monto'], 2, '.', ''); ?>" step="0.01">

                        <button class="borrar">✖</button>
                    </div>
                <?php endforeach; ?>

               
            <?php endif; ?>

                    <div class="agregar">
                        <input type="text" id="nuevoIngreso" placeholder="Nuevo ingreso">
                        <button id="btnAgregarIngreso">Agregar</button>
                    </div>

             <div class="total">
                    <strong>Total ingresos:</strong>
                    <input type="number" id="totalIngresos" value="0.00" readonly>
            </div>
        </div>

        <!-- PANEL EGRESOS -->
        <div class="panel egresos">
            <h3>Egresos</h3>
            <?php if (empty($egresos)): ?>
                <p class="vacio">No hay conceptos de egreso. Usa “Agregar” para crear uno.</p>
            <?php else: ?>
                <?php foreach ($egresos as $e): ?>
                    <div class="fila">
                        <label><?php echo htmlspecialchars($e['nombre']); ?>:</label>
                        <?php
                        $valor = isset($montosGuardados[$e['idConcepto']]) ? $montosGuardados[$e['idConcepto']] : 0.00;
                        ?>
                            <input type="number" name="monto[<?php echo $e['idConcepto']; ?>]" value="<?php echo number_format($e['monto'], 2, '.', ''); ?>" step="0.01">


                        <button class="borrar">✖</button>
                    </div>
                <?php endforeach; ?>

            <?php endif; ?>

            <div class="agregar">
                <input type="text" id="nuevoEgreso" placeholder="Nuevo egreso">
                <button id="btnAgregarEgreso">Agregar</button>
            </div>
            <div class="total">
                    <strong>Total egresos:</strong>
                    <input type="number" id="totalEgresos" value="0.00" readonly>
            </div>
        </div>
    </section>

    <section class="resumen">
        <div>
            <label>Resumen del balance ahorrado anual:</label>
            <input type="number" value="<?php echo number_format($balanceAnual, 2, '.', ''); ?>" readonly>
        </div>
        <div>
            <label>Resumen del balance restante mensual:</label>
            <input type="number" value="<?php echo number_format($balanceMensual, 2, '.', ''); ?>" readonly>
        </div>
    </section>

    <section class="acciones">
        <input 
            type="date" 
            id="fechaSeleccionada" 
            value="<?php echo $fechaSeleccionada; ?>" 
            onchange="location.href='entrada_diaria.php?fecha=' + this.value">

        <button class="guardar">Guardar</button>
    </section>
</main>

<script>
// Manejo de agregar concepto como fila temporal (no se guarda en DB hasta presionar Guardar con monto)
let newConceptCounter = 0;

function addTemporaryConcept(tipo, nombre) {
    const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
    const listaAgregar = panel.querySelector('.agregar');

    const id = `new_${++newConceptCounter}`;

    const wrapper = document.createElement('div');
    wrapper.className = 'fila temporary';
    wrapper.dataset.tempId = id;

    wrapper.innerHTML = `
        <label>${escapeHtml(nombre)}:</label>
        <input type="hidden" name="new_nombre[${id}]" value="${escapeHtml(nombre)}">
        <input type="number" name="monto[${id}]" value="0.00" step="0.01">
        <button class="borrar">✖</button>
    `;

    listaAgregar.parentNode.insertBefore(wrapper, listaAgregar);

    // focus en el input monto recién creado
    wrapper.querySelector('input[name^="monto["]').focus();
}

function escapeHtml(text) {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

document.getElementById('btnAgregarIngreso').addEventListener('click', (e) => {
    e.preventDefault();
    const input = document.getElementById('nuevoIngreso');
    const nombre = input.value.trim();
    if (!nombre) { alert('Ingrese un nombre de concepto'); return; }
    checkAndAddConcept('ingreso', nombre);
    input.value = '';
});

document.getElementById('btnAgregarEgreso').addEventListener('click', (e) => {
    e.preventDefault();
    const input = document.getElementById('nuevoEgreso');
    const nombre = input.value.trim();
    if (!nombre) { alert('Ingrese un nombre de concepto'); return; }
    checkAndAddConcept('egreso', nombre);
    input.value = '';
});

// Antes de agregar, consultar al servidor si el concepto existe y/o ya tiene transacción en la fecha
function checkAndAddConcept(tipo, nombre) {
    const fecha = document.querySelector('input[type="date"]').value;
    const form = new FormData();
    form.append('nombre', nombre);
    form.append('tipo', tipo);
    form.append('check', '1');
    form.append('fecha', fecha);

    fetch('agregar_concepto.php', { method: 'POST', body: form })
        .then(res => res.json())
        .then(data => {
            if (data.exists_transaction) {
                alert('Ya existe una transacción para este concepto en la fecha seleccionada.');
                return;
            }

            if (data.exists_concept && data.concept_id) {
                // crear fila usando el id numérico del concepto existente
                addExistingConceptRow(tipo, nombre, data.concept_id);
                return;
            }

            // no existe el concepto -> crear fila temporal nueva
            addTemporaryConcept(tipo, nombre);
        })
        .catch(err => {
            console.error('Error al verificar concepto:', err);
            // fallback: crear fila temporal
            addTemporaryConcept(tipo, nombre);
        });
}

function addExistingConceptRow(tipo, nombre, conceptId) {
    const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
    const listaAgregar = panel.querySelector('.agregar');

    // si ya existe una fila con ese id en la UI, no duplicar
    if (document.querySelector(`input[name="monto[${conceptId}]"]`)) {
        alert('El concepto ya aparece en la lista para esta fecha.');
        return;
    }

    const wrapper = document.createElement('div');
    wrapper.className = 'fila existing';
    wrapper.innerHTML = `
        <label>${escapeHtml(nombre)}:</label>
        <input type="number" name="monto[${conceptId}]" value="0.00" step="0.01">
        <button class="borrar">✖</button>
    `;

    listaAgregar.parentNode.insertBefore(wrapper, listaAgregar);
    wrapper.querySelector('input[name^="monto["]').focus();
}

// Guardar: enviar montos existentes y nuevos (crear concepto + transacción en backend si monto != 0)
document.querySelector('.guardar').addEventListener('click', () => {
    const formData = new FormData();
    const montos = document.querySelectorAll('input[name^="monto["]');
    const fecha = document.querySelector('input[type="date"]').value;

    montos.forEach(input => {
        const match = input.name.match(/\[(.+)\]/);
        if (!match) return;
        const id = match[1];
        const val = parseFloat(input.value) || 0;

        // si el input es un hidden marcado como deleted, enviar explicitamente 0
        if (input.type === 'hidden' && input.dataset.deleted === '1') {
            formData.append(`monto[${id}]`, '0');
            return;
        }

        // sólo enviar montos distintos de 0
        if (val !== 0) {
            formData.append(`monto[${id}]`, val);

            // si es un id nuevo (empieza con new_) enviar también nombre y tipo
            if (id.startsWith('new_')) {
                const nombreInput = document.querySelector(`input[name="new_nombre[${id}]"]`);
                if (nombreInput) {
                    // determinar tipo (buscar si está en ingresos o egresos)
                    const tipo = (input.closest('.ingresos')) ? 'ingreso' : 'egreso';
                    formData.append(`new_nombre[${id}]`, nombreInput.value);
                    formData.append(`new_tipo[${id}]`, tipo);
                }
            }
        }
    });

    formData.append('fecha', fecha);

    fetch('guardar_transaccion.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(data => {
            if (data.trim() === 'ok') {
                alert('Entradas diarias guardadas correctamente');
                location.reload();
            } else {
                alert('Error al guardar: ' + data);
            }
        }).catch(err => alert('Error en la petición: ' + err));
});

// eliminar fila al presionar ✖
document.addEventListener('click', (e) => {
    if (!e.target.matches('.borrar')) return;

    const fila = e.target.closest('.fila');
    if (!fila) return;

    // Si es fila temporal (nueva), eliminarla del DOM inmediatamente
    if (fila.classList.contains('temporary')) {
        fila.remove();
        calcularTotales();
        return;
    }

    // Para filas existentes: marcar como eliminada visualmente y preparar monto[id]=0 (hidden)
    const montoInput = fila.querySelector('input[name^="monto["]');
    if (!montoInput) {
        // si no hay input de monto, simplemente ocultar
        fila.style.display = 'none';
        return;
    }

    // extraer id del input
    const m = montoInput.name.match(/\[(.+)\]/);
    const id = m ? m[1] : null;
    if (!id) {
        fila.style.display = 'none';
        return;
    }

    // ocultar la fila visualmente
    fila.style.display = 'none';
    fila.classList.add('marked-deleted');

    // Añadir/actualizar un input hidden con monto[id]=0 y marcarlo para envío
    let hidden = fila.querySelector(`input[type="hidden"][name="monto[${id}]"]`);
    if (!hidden) {
        hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = `monto[${id}]`;
        fila.appendChild(hidden);
    }
    hidden.value = '0';
    hidden.dataset.deleted = '1';

    // actualizar totales
    calcularTotales();
});


function calcularTotales() {
    let totalIngresos = 0;
    let totalEgresos = 0;

    document.querySelectorAll('.ingresos input[name^="monto["]').forEach(input => {
        const val = parseFloat(input.value) || 0;
        totalIngresos += val;
    });

    document.querySelectorAll('.egresos input[name^="monto["]').forEach(input => {
        const val = parseFloat(input.value) || 0;
        totalEgresos += val;
    });

    document.getElementById('totalIngresos').value = totalIngresos.toFixed(2);
    document.getElementById('totalEgresos').value = totalEgresos.toFixed(2);
}

// Recalcular cuando se modifiquen montos
document.addEventListener('input', (e) => {
    if (e.target.matches('input[name^="monto["]')) {
        calcularTotales();
    }
});

// Calcular totales iniciales al cargar
window.addEventListener('load', calcularTotales);
</script>

</body>
</html>

