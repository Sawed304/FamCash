<?php
session_start();
include("conexion.php");

if (!isset($_SESSION["perfil_id"])) {
    header("Location: seleccionperfil.php");
    exit;
}

$idPerfil = $_SESSION["perfil_id"];
$nombrePerfil = $_SESSION["perfil_nombre"];
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : date('Y-m-d');

// --- Cargar conceptos y montos existentes ---
$sql = "SELECT c.idConcepto, c.nombre, c.tipo, t.monto
        FROM conceptos c
        INNER JOIN transacciones t 
            ON c.idConcepto = t.idConcepto 
            AND t.idPerfil = ? 
            AND t.fecha = ?
        WHERE c.idPerfil = ? AND c.estado = 'Habilitado'
        ORDER BY c.tipo DESC, c.nombre";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("isi", $idPerfil, $fechaSeleccionada, $idPerfil);
$stmt->execute();
$result = $stmt->get_result();

$ingresos = [];
$egresos = [];

while ($row = $result->fetch_assoc()) {
    $row['monto'] = (float)$row['monto'];
    if (strtolower($row['tipo']) === 'ingreso') {
        $ingresos[] = $row;
    } else {
        $egresos[] = $row;
    }
}

// --- Calcular balances ---
$year = date('Y', strtotime($fechaSeleccionada));
$startYear = $year . '-01-01';
$startMonth = date('Y-m-01', strtotime($fechaSeleccionada));

$balances = [
    'annual' => ['ingresos' => 0.0, 'egresos' => 0.0],
    'monthly' => ['ingresos' => 0.0, 'egresos' => 0.0]
];

$sqlRange = "SELECT
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'ingreso' THEN t.monto ELSE 0 END),0) AS ingresos,
    IFNULL(SUM(CASE WHEN LOWER(c.tipo) = 'egreso' THEN t.monto ELSE 0 END),0) AS egresos
FROM transacciones t
JOIN conceptos c ON t.idConcepto = c.idConcepto
WHERE t.fecha BETWEEN ? AND ?";

$stmtRange = $conexion->prepare($sqlRange);
$stmtRange->bind_param('ss', $startYear, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $balances['annual']['ingresos'] = (float)$r['ingresos'];
    $balances['annual']['egresos'] = (float)$r['egresos'];
}

$stmtRange->bind_param('ss', $startMonth, $fechaSeleccionada);
$stmtRange->execute();
$resRange = $stmtRange->get_result();
if ($resRange) {
    $r = $resRange->fetch_assoc();
    $balances['monthly']['ingresos'] = (float)$r['ingresos'];
    $balances['monthly']['egresos'] = (float)$r['egresos'];
}

$balanceAnual = $balances['annual']['ingresos'] - $balances['annual']['egresos'];
$balanceMensual = $balances['monthly']['ingresos'] - $balances['monthly']['egresos'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>FamCash - Entrada Diaria</title>
    <link rel="stylesheet" href="css/daily.css">
</head>
<body>

<header class="header">
    <div class="logo" onclick="location.href='entrada_diaria.php'">
        <h1>FamCash</h1>
    </div>
    <nav class="menu">
        <button class="menu-btn active" onclick="location.href='entrada_diaria.php'">Entrada diaria</button>
        <button class="menu-btn" onclick="location.href='balance.php'">Balance</button>
        <div class="dropdown">
            <button class="menu-btn">Configuración ▼</button>
            <div class="dropdown-content">
                <a href="#">Config. de Conceptos</a>
                <a href="#">Config. Perfil</a>
                <a href="#">Config. Perfiles Familiares</a>
            </div>
        </div>
    </nav>
</header>

<main class="contenido">
    <h2>Entrada diaria - <?php echo htmlspecialchars($nombrePerfil); ?></h2>

    <section class="paneles">
        <!-- INGRESOS -->
        <div class="panel ingresos">
            <h3>Ingresos</h3>
            <?php if (empty($ingresos)): ?>
                <p class="vacio">No hay conceptos de ingreso. Usa “Agregar” para crear uno.</p>
            <?php else: ?>
                <?php foreach ($ingresos as $i): ?>
                    <div class="fila">
                        <label><?php echo htmlspecialchars($i['nombre']); ?>:</label>
                        <input type="number" name="monto[<?php echo $i['idConcepto']; ?>]" 
                            value="<?php echo number_format($i['monto'], 2, '.', ''); ?>" step="0.01">
                        <button class="borrar">✖</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="agregar">
                <input type="text" id="nuevoIngreso" placeholder="Nuevo ingreso">
                <button id="btnAgregarIngreso">Agregar</button>
            </div>

            <div class="total">
                <strong>Total ingresos:</strong>
                <input type="number" id="totalIngresos" value="0.00" readonly>
            </div>
        </div>

        <!-- EGRESOS -->
        <div class="panel egresos">
            <h3>Egresos</h3>
            <?php if (empty($egresos)): ?>
                <p class="vacio">No hay conceptos de egreso. Usa “Agregar” para crear uno.</p>
            <?php else: ?>
                <?php foreach ($egresos as $e): ?>
                    <div class="fila">
                        <label><?php echo htmlspecialchars($e['nombre']); ?>:</label>
                        <input type="number" name="monto[<?php echo $e['idConcepto']; ?>]" 
                            value="<?php echo number_format($e['monto'], 2, '.', ''); ?>" step="0.01">
                        <button class="borrar">✖</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div class="agregar">
                <input type="text" id="nuevoEgreso" placeholder="Nuevo egreso">
                <button id="btnAgregarEgreso">Agregar</button>
            </div>
            <div class="total">
                <strong>Total egresos:</strong>
                <input type="number" id="totalEgresos" value="0.00" readonly>
            </div>
        </div>
    </section>

    <section class="resumen">
        <div>
            <label>Balance ahorrado anual:</label>
            <input type="number" value="<?php echo number_format($balanceAnual, 2, '.', ''); ?>" readonly>
        </div>
        <div>
            <label>Balance restante mensual:</label>
            <input type="number" value="<?php echo number_format($balanceMensual, 2, '.', ''); ?>" readonly>
        </div>
    </section>

    <section class="acciones">
        <input type="date" id="fechaSeleccionada" 
               value="<?php echo $fechaSeleccionada; ?>" 
               onchange="location.href='entrada_diaria.php?fecha=' + this.value">
        <button class="guardar">Guardar</button>
    </section>
</main>

<script>
let newConceptCounter = 0;

// ========================= FUNCIONES =========================
function escapeHtml(text) {
    return text.replace(/&/g, "&amp;")
               .replace(/</g, "&lt;")
               .replace(/>/g, "&gt;")
               .replace(/"/g, "&quot;")
               .replace(/'/g, "&#039;");
}

// --- Añadir concepto temporal ---
function addTemporaryConcept(tipo, nombre) {
    const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
    const listaAgregar = panel.querySelector('.agregar');
    const id = `new_${++newConceptCounter}`;

    const fila = document.createElement('div');
    fila.className = 'fila temporary';
    fila.dataset.tempId = id;
    fila.innerHTML = `
        <label>${escapeHtml(nombre)}:</label>
        <input type="hidden" name="new_nombre[${id}]" value="${escapeHtml(nombre)}">
        <input type="number" name="monto[${id}]" value="0.00" step="0.01">
        <button class="borrar">✖</button>`;
    listaAgregar.parentNode.insertBefore(fila, listaAgregar);
    fila.querySelector('input[name^="monto["]').focus();
    calcularTotales();
}

// --- Añadir concepto existente ---
function addExistingConceptRow(tipo, nombre, conceptId) {
    const panel = tipo === 'ingreso' ? document.querySelector('.ingresos') : document.querySelector('.egresos');
    const listaAgregar = panel.querySelector('.agregar');

    if (document.querySelector(`input[name="monto[${conceptId}]"]`)) {
        alert('El concepto ya aparece en la lista para esta fecha.');
        return;
    }

    const fila = document.createElement('div');
    fila.className = 'fila existing';
    fila.innerHTML = `
        <label>${escapeHtml(nombre)}:</label>
        <input type="number" name="monto[${conceptId}]" value="0.00" step="0.01">
        <button class="borrar">✖</button>`;
    listaAgregar.parentNode.insertBefore(fila, listaAgregar);
    fila.querySelector('input[name^="monto["]').focus();
    calcularTotales();
}

// --- Verificar y agregar concepto ---
function checkAndAddConcept(tipo, nombre) {
    const fecha = document.querySelector('input[type="date"]').value;
    const nombreNormalizado = nombre.trim().toLowerCase();

    if (nombreNormalizado === "") {
        alert("Ingrese un nombre de concepto válido.");
        return;
    }

    // ✅ Evitar duplicados en toda la interfaz
    const todasLabels = document.querySelectorAll('.fila label');
    for (const lbl of todasLabels) {
        if (lbl.textContent.trim().toLowerCase() === nombreNormalizado) {
            alert('Ya has agregado este concepto en la lista.');
            return;
        }
    }

    // ✅ Consultar si existe en BD
    const form = new FormData();
    form.append('nombre', nombre);
    form.append('tipo', tipo);
    form.append('check', '1');
    form.append('fecha', fecha);

    fetch('agregar_concepto.php', { method: 'POST', body: form })
        .then(res => res.json())
        .then(data => {
            if (data.exists_transaction) {
                alert('Ya existe una transacción para este concepto en la fecha seleccionada.');
                return;
            }
            if (data.exists_concept && data.concept_id) {
                addExistingConceptRow(tipo, nombre, data.concept_id);
            } else {
                addTemporaryConcept(tipo, nombre);
            }
        })
        .catch(err => {
            console.error('Error al verificar concepto:', err);
            addTemporaryConcept(tipo, nombre);
        });
}

// ========================= EVENTOS =========================
document.getElementById('btnAgregarIngreso').addEventListener('click', e => {
    e.preventDefault();
    const input = document.getElementById('nuevoIngreso');
    const nombre = input.value.trim();
    if (!nombre) return alert('Ingrese un nombre de concepto');
    checkAndAddConcept('ingreso', nombre);
    input.value = '';
});

document.getElementById('btnAgregarEgreso').addEventListener('click', e => {
    e.preventDefault();
    const input = document.getElementById('nuevoEgreso');
    const nombre = input.value.trim();
    if (!nombre) return alert('Ingrese un nombre de concepto');
    checkAndAddConcept('egreso', nombre);
    input.value = '';
});

// --- Guardar ---
document.querySelector('.guardar').addEventListener('click', () => {
    const formData = new FormData();
    const montos = document.querySelectorAll('input[name^="monto["]');
    const fecha = document.querySelector('input[type="date"]').value;

    montos.forEach(input => {
        const match = input.name.match(/\[(.+)\]/);
        if (!match) return;
        const id = match[1];
        const val = parseFloat(input.value) || 0;

        if (input.dataset.deleted === '1') {
            formData.append(`monto[${id}]`, '0');
        } else {
            formData.append(`monto[${id}]`, val);
            if (id.startsWith('new_')) {
                const nombreInput = document.querySelector(`input[name="new_nombre[${id}]"]`);
                if (nombreInput) {
                    const tipo = input.closest('.ingresos') ? 'ingreso' : 'egreso';
                    formData.append(`new_nombre[${id}]`, nombreInput.value);
                    formData.append(`new_tipo[${id}]`, tipo);
                }
            }
        }
    });

    formData.append('fecha', fecha);

    fetch('guardar_transaccion.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(data => {
            if (data.trim() === 'ok') {
                alert('Entradas diarias guardadas correctamente');
                location.reload();
            } else {
                alert('Error al guardar: ' + data);
            }
        })
        .catch(err => alert('Error en la petición: ' + err));
});

// --- Eliminar fila ---
document.addEventListener('click', e => {
    if (!e.target.matches('.borrar')) return;
    const fila = e.target.closest('.fila');
    if (!fila) return;

    const montoInput = fila.querySelector('input[name^="monto["]');
    if (!montoInput) return;

    if (montoInput.name.includes('new_')) {
        // Si es un concepto nuevo, eliminar totalmente del DOM
        fila.remove();
    } else {
        // Si ya existía, marcar como eliminado
        montoInput.dataset.deleted = '1';
        montoInput.value = 0;
        fila.style.display = 'none';
    }

    calcularTotales();
});

// --- Calcular totales ---
function calcularTotales() {
    let totalIngresos = 0, totalEgresos = 0;

    document.querySelectorAll('.ingresos input[name^="monto["]:not([data-deleted="1"])')    
        .forEach(i => totalIngresos += parseFloat(i.value) || 0);

    document.querySelectorAll('.egresos input[name^="monto["]:not([data-deleted="1"])')
        .forEach(i => totalEgresos += parseFloat(i.value) || 0);

    document.getElementById('totalIngresos').value = totalIngresos.toFixed(2);
    document.getElementById('totalEgresos').value = totalEgresos.toFixed(2);
}

document.addEventListener('input', e => {
    if (e.target.matches('input[name^="monto["]')) calcularTotales();
});
window.addEventListener('load', calcularTotales);
</script>

</body>
</html>
